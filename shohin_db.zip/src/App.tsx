import { type ChangeEvent, type ClipboardEvent, type CSSProperties, type DragEvent, type MouseEvent as ReactMouseEvent, useEffect, useMemo, useRef, useState } from 'react'
import { supabase } from './lib/supabase'
import './App.css'

const PRODUCT_IMAGE_BUCKET = 'product-images'
const PRODUCT_IMAGE_EXTENSION = '.webp'
const PRODUCT_IMAGE_WEBP_QUALITY = 0.92
const IMAGE_UPLOAD_CONCURRENCY = 5
const PRODUCT_IMAGE_ACCEPT = '.jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp'
const PRODUCT_FETCH_BATCH_SIZE = 1000
const PRODUCT_PAGE_SIZE = 200
const COLUMN_WIDTH_STORAGE_KEY = 'shohin-db-column-widths-v4'
const APP_SETTINGS_TABLE = 'app_settings'
const COLUMN_WIDTH_SETTING_PREFIX = 'shohin-db:column-widths'
const MIN_COLUMN_WIDTH = 64
const MAX_COLUMN_WIDTH = 720
const NE_SYNC_WORKER_URL = 'https://ne-sync-worker.kaiyoshida0318.workers.dev'
const NE_SYNC_FIELDS_STORAGE_KEY = 'shohin-db-ne-sync-fields-v1'
// カスタムビューで表示する列（このPCのブラウザに保存）
const CUSTOM_COLUMNS_STORAGE_KEY = 'shohin-db-custom-columns-v1'
const DEFAULT_CUSTOM_COLUMN_KEYS = [
  'product_name',
  'free_stock',
  'reorder_point',
  'stock_constant',
  'monthly_sales',
  'orderboard_classification',
  'floor',
  'special_notes',
  'picking_advice',
  'delivery_line_4',
  'rack_number',
  'rack_level',
  'sticker_color',
  'shipping_floor',
  'paper_sort_sub',
  'order_memo_1',
  'updated_at',
]
const NE_SYNC_MONTHS_STORAGE_KEY = 'shohin-db-ne-sync-months-v1'
const NE_SYNC_MONTH_MIN_YEAR = 2025
const AUTH_API_BASE_URL = String(import.meta.env.VITE_AUTH_API_BASE_URL ?? '').replace(/\/+$/, '')
const DEFAULT_AUTH_QUESTION = '秘密の質問'



type Product = {
  product_code: string
  product_name: string | null
  floor: string | null
  shipping_floor: string | null

  free_stock: number | null
  reorder_point: number | null
  stock_constant: number | null
  monthly_sales: unknown | null
  monthly_by_year?: unknown | null
  monthlyByYear?: unknown | null
  orderboard_classification: string | null
  order_out: boolean | null
  no_1688_shop: boolean | null

  special_notes: string | null
  picking_advice: string | null
  delivery_line_4: string | null
  rack_number: string | null
  rack_level: string | null
  paper_sort_sub: boolean | null
  sticker_color: string | null

  order_url_1: string | null
  order_url_2: string | null
  order_url_3: string | null
  order_size: string | null
  order_color: string | null
  order_simple_instruction: string | null
  order_detail_instruction: string | null
  order_quantity_condition: string | null
  order_note: string | null

  order_memo_1: string | null
  rakumart_url_1: string | null
  order_memo_2: string | null
  rakumart_url_2: string | null
  order_memo_3: string | null
  rakumart_url_3: string | null
  order_memo_4: string | null
  rakumart_url_4: string | null
  order_memo_5: string | null
  rakumart_url_5: string | null

  product_info_synced_at: string | null
  order_status_synced_at: string | null
  created_at: string | null
  updated_at: string | null
}

type ProductImagePreview = {
  productCode: string
  productName: string | null
  url: string
}

type DeliverySlipPreviewData = {
  productCode: string
  productName: string
  specialNotes: string
  pickingAdvice: string
  deliveryLine4: string
  floor: string
  rackNumber: string
  rackLevel: string
  stickerColor: string
}

type RakumartRemarkMode = 'manual' | 'none' | 'template'

type RakumartOptionDraft = {
  id: string
  group: string
  value: string
}

type RakumartLineDraft = {
  id: string
  options: RakumartOptionDraft[]
  quantityMultiplier: string
  memo: string
}

type RakumartSourceDraft = {
  id: string
  sourceName: string
  url: string
  enabled: boolean
  memo: string
  lines: RakumartLineDraft[]
}

type RakumartItemDraft = {
  id: string
  itemName: string
  required: boolean
  memo: string
  sources: RakumartSourceDraft[]
}

type RakumartRecipeDraft = {
  enabled: boolean
  stopBeforeSubmit: boolean
  remarkMode: RakumartRemarkMode
  remarkTemplate: string
  items: RakumartItemDraft[]
}

type RakumartLegacyUrlRelation = 'separate' | 'alternatives' | 'manual'

type RakumartRecipeModalState = {
  product: Product
  draft: RakumartRecipeDraft
  exists: boolean
  legacySeeded: boolean
  legacyRelation: RakumartLegacyUrlRelation | null
}

type RakumartRecipeDbLine = {
  options?: unknown
  quantity_multiplier?: number | string | null
  sort_order?: number | null
  memo?: string | null
}

type RakumartRecipeDbSource = {
  source_name?: string | null
  url?: string | null
  priority?: number | null
  enabled?: boolean | null
  memo?: string | null
  rakumart_order_lines?: RakumartRecipeDbLine[] | null
}

type RakumartRecipeDbItem = {
  item_name?: string | null
  sort_order?: number | null
  required?: boolean | null
  memo?: string | null
  rakumart_order_sources?: RakumartRecipeDbSource[] | null
}

type RakumartRecipeDbRow = {
  enabled?: boolean | null
  stop_before_submit?: boolean | null
  remark_mode?: string | null
  remark_template?: string | null
  rakumart_order_items?: RakumartRecipeDbItem[] | null
}

type ProductImageDraft = {
  file: File
  previewUrl: string
  sourceName: string
}

type NeUsageResult = {
  ok: boolean
  month?: string
  callCount?: number
  estimatedGb?: number
  remainingCalls?: number
  callLimit?: number
  byEndpoint?: Array<{ endpoint: string; calls: number; estimatedBytes: number; success: number; errors: number }>
  error?: string
}

type NeOperationalSyncResult = {
  ok: boolean
  dryRun?: boolean
  selectedFields?: string[]
  stockFetched?: number
  goodsFetched?: number
  merged?: number
  matched?: number
  unmatched?: number
  updated?: number
  message?: string
  error?: string
}

type NeMonthlySalesSyncResult = {
  ok: boolean
  dryRun?: boolean
  months?: string[]
  rowFetched?: number
  activeRows?: number
  aggregatedProducts?: number
  matched?: number
  unmatched?: number
  updated?: number
  message?: string
  error?: string
}


type SecretQuestionResponse = {
  ok?: boolean
  question?: string
  displayName?: string
  error?: string
}

type SecretLoginResponse = {
  ok?: boolean
  email?: string
  sub?: string
  user?: {
    id?: string
    email?: string
  }
  session?: {
    access_token?: string
    refresh_token?: string
  }
  error?: string
}

type NeOperationalFieldKey = 'free_stock' | 'reorder_point' | 'stock_constant'

type NeSyncFieldState = {
  freeStock: boolean
  reorderPoint: boolean
  stockConstant: boolean
  monthlySales: boolean
}

const DEFAULT_NE_SYNC_FIELDS: NeSyncFieldState = {
  freeStock: true,
  reorderPoint: true,
  stockConstant: true,
  monthlySales: false,
}

type EditableProduct = {
  product_name: string
  floor: string
  shipping_floor: string

  special_notes: string
  picking_advice: string
  delivery_line_4: string
  rack_number: string
  rack_level: string
  paper_sort_sub: boolean
  sticker_color: string

  order_url_1: string
  order_url_2: string
  order_url_3: string
  order_size: string
  order_color: string
  order_simple_instruction: string
  order_detail_instruction: string
  order_quantity_condition: string
  order_note: string
  order_out: boolean
  no_1688_shop: boolean

  order_memo_1: string
  rakumart_url_1: string
  order_memo_2: string
  rakumart_url_2: string
  order_memo_3: string
  rakumart_url_3: string
  order_memo_4: string
  rakumart_url_4: string
  order_memo_5: string
  rakumart_url_5: string
}

type EditableProductKey = keyof EditableProduct
type EditableTextProductKey = Exclude<EditableProductKey, 'paper_sort_sub' | 'order_out' | 'no_1688_shop'>

type SessionUser = {
  email?: string
}

type BulkColumnEditKind = 'text' | 'multiline' | 'url' | 'boolean' | 'order_memo'

type BulkColumnEditConfig = {
  kind: BulkColumnEditKind
  key: EditableProductKey
  label: string
  urlKey?: EditableTextProductKey
}

type BulkColumnEditState = {
  config: BulkColumnEditConfig
  value: string
  boolValue: boolean
  urlValue: string
  applyMain: boolean
  applyUrl: boolean
}

const SELECT_COLUMN_WIDTH = 44

type BulkMode = 'insert' | 'upsert' | 'update'

const BULK_MODE_OPTIONS: Array<{ value: BulkMode; label: string; hint: string }> = [
  { value: 'insert', label: '追加のみ', hint: '未登録の商品だけ追加。既存の商品コードはスキップします。' },
  { value: 'upsert', label: '追加＋更新', hint: '未登録は追加、既存は選んだ列だけ上書きします。' },
  { value: 'update', label: '更新のみ', hint: '既存の商品だけ、選んだ列を上書き。未登録はスキップします。' },
]

// モーダルの背景（カードの外側）をダブルクリックしたときだけ閉じる
function closeOnBackdropDoubleClick(close: () => void) {
  return (event: ReactMouseEvent<HTMLElement>) => {
    if (event.target === event.currentTarget) {
      close()
    }
  }
}

const BULK_TEXT_COLUMN_KEYS = new Set<string>([
  'product_name',
  'floor',
  'shipping_floor',
  'rack_number',
  'rack_level',
  'sticker_color',
  'order_size',
  'order_color',
])

const BULK_MULTILINE_COLUMN_KEYS = new Set<string>([
  'special_notes',
  'picking_advice',
  'delivery_line_4',
  'order_simple_instruction',
  'order_detail_instruction',
  'order_quantity_condition',
  'order_note',
])

const BULK_URL_COLUMN_KEYS = new Set<string>(['order_url_1', 'order_url_2', 'order_url_3'])
const BULK_BOOLEAN_COLUMN_KEYS = new Set<string>(['paper_sort_sub', 'order_out', 'no_1688_shop'])
const BULK_ORDER_MEMO_URL_KEYS: Record<string, EditableTextProductKey> = {
  order_memo_1: 'rakumart_url_1',
  order_memo_2: 'rakumart_url_2',
  order_memo_3: 'rakumart_url_3',
  order_memo_4: 'rakumart_url_4',
  order_memo_5: 'rakumart_url_5',
}

// 編集モード中、列ヘッダーの「一括入力」で書き換えられる列の設定を返す。
// NE情報ビューの商品名は表示専用なので対象外。
function getBulkColumnEditConfig(column: ColumnSpec, tableView: TableView): BulkColumnEditConfig | null {
  const key = column.key

  if (tableView === 'ne' && key === 'product_name') {
    return null
  }

  if (BULK_TEXT_COLUMN_KEYS.has(key)) {
    return { kind: 'text', key: key as EditableProductKey, label: column.label }
  }

  if (BULK_MULTILINE_COLUMN_KEYS.has(key)) {
    return { kind: 'multiline', key: key as EditableProductKey, label: column.label }
  }

  if (BULK_URL_COLUMN_KEYS.has(key)) {
    return { kind: 'url', key: key as EditableProductKey, label: column.label }
  }

  if (BULK_BOOLEAN_COLUMN_KEYS.has(key)) {
    return { kind: 'boolean', key: key as EditableProductKey, label: column.label }
  }

  if (BULK_ORDER_MEMO_URL_KEYS[key]) {
    return {
      kind: 'order_memo',
      key: key as EditableProductKey,
      label: column.label,
      urlKey: BULK_ORDER_MEMO_URL_KEYS[key],
    }
  }

  return null
}

type TableView = 'all' | 'pick' | 'order' | 'purchase' | 'ne' | 'custom'

type ColumnSpec = {
  key: string
  label: string
  width: number
  className?: string
}

const SORTABLE_COLUMN_KEYS = [
  'product_code',
  'product_name',
  'free_stock',
  'reorder_point',
  'stock_constant',
  'orderboard_classification',
  'floor',
  'shipping_floor',
  'rack_number',
  'rack_level',
  'sticker_color',
  'paper_sort_sub',
  'order_out',
  'no_1688_shop',
  'order_memo_1',
  'order_memo_2',
  'order_memo_3',
  'order_memo_4',
  'order_memo_5',
] as const

type SortableColumnKey = (typeof SORTABLE_COLUMN_KEYS)[number]
type SortDirection = 'asc' | 'desc'
type SortConfig = { key: SortableColumnKey; direction: SortDirection } | null

const SORTABLE_COLUMN_SET = new Set<string>(SORTABLE_COLUMN_KEYS)

type ColumnWidthMap = Record<string, number>
type RecommendedColumnWidthsByView = Partial<Record<TableView, ColumnWidthMap>>

type ColumnResizeMouseEvent = {
  clientX: number
  preventDefault: () => void
  stopPropagation: () => void
}


type BulkProductRow = {
  id: string
  product_code: string
  product_name: string
  floor: string
  shipping_floor: string
  special_notes: string
  picking_advice: string
  delivery_line_4: string
  rack_number: string
  rack_level: string
  sticker_color: string
  order_url_1: string
  order_url_2: string
  order_url_3: string
  order_size: string
  order_color: string
  order_simple_instruction: string
  order_detail_instruction: string
  order_quantity_condition: string
  order_note: string
  order_out: boolean
  no_1688_shop: boolean
}

type CleanBulkProductRow = {
  product_code: string
  product_name: string
  floor: string
  shipping_floor: string
  special_notes: string
  picking_advice: string
  delivery_line_4: string
  rack_number: string
  rack_level: string
  sticker_color: string
  order_url_1: string
  order_url_2: string
  order_url_3: string
  order_size: string
  order_color: string
  order_simple_instruction: string
  order_detail_instruction: string
  order_quantity_condition: string
  order_note: string
  order_out: boolean
  no_1688_shop: boolean
}

type BulkFieldKey = Exclude<keyof CleanBulkProductRow, 'product_code'>

type BulkFieldColumn = {
  key: BulkFieldKey
  label: string
  placeholder: string
  inputType?: 'text' | 'checkbox'
}

const BULK_FIELD_COLUMNS: BulkFieldColumn[] = [
  { key: 'product_name', label: '商品名', placeholder: '商品名' },
  { key: 'floor', label: '階数', placeholder: '階数' },
  { key: 'rack_number', label: '棚番号-位置', placeholder: '棚番号-位置' },
  { key: 'rack_level', label: '棚番号-段', placeholder: '棚番号-段' },
  { key: 'sticker_color', label: 'シールカラー', placeholder: 'シールカラー' },
  { key: 'shipping_floor', label: '配送-階-特記', placeholder: '例: PKT2-3F RPR' },
  { key: 'special_notes', label: '2行目', placeholder: '2行目' },
  { key: 'picking_advice', label: '3行目', placeholder: '3行目' },
  { key: 'delivery_line_4', label: '4行目', placeholder: '4行目' },
  { key: 'order_url_1', label: '発注URL1', placeholder: '発注URL1' },
  { key: 'order_url_2', label: '発注URL2', placeholder: '発注URL2' },
  { key: 'order_url_3', label: '発注URL3', placeholder: '発注URL3' },
  { key: 'order_size', label: 'サイズ', placeholder: 'サイズ' },
  { key: 'order_color', label: 'カラー', placeholder: 'カラー' },
  { key: 'order_simple_instruction', label: '■簡潔指示', placeholder: '■簡潔指示' },
  { key: 'order_detail_instruction', label: '▲具体指示', placeholder: '▲具体指示' },
  { key: 'order_quantity_condition', label: '数量条件指定', placeholder: '数量条件指定' },
  { key: 'order_note', label: '補足情報', placeholder: '補足情報' },
  { key: 'order_out', label: 'out', placeholder: '', inputType: 'checkbox' },
  { key: 'no_1688_shop', label: '1688ショップなし', placeholder: '', inputType: 'checkbox' },
]

const DEFAULT_BULK_FIELD_KEYS = BULK_FIELD_COLUMNS
  .filter((column) => column.inputType !== 'checkbox')
  .map((column) => column.key)

const EDIT_FIELD_PLACEHOLDERS: Record<EditableTextProductKey, string> = {
  product_name: '商品名',
  floor: '階数',
  shipping_floor: '配送-階-特記',
  special_notes: '2行目',
  picking_advice: '3行目',
  delivery_line_4: '4行目',
  rack_number: '棚番号-位置',
  rack_level: '棚番号-段',
  sticker_color: 'シールカラー',
  order_url_1: '発注URL1',
  order_url_2: '発注URL2',
  order_url_3: '発注URL3',
  order_size: 'サイズ',
  order_color: 'カラー',
  order_simple_instruction: '■簡潔指示',
  order_detail_instruction: '▲具体指示',
  order_quantity_condition: '数量条件指定',
  order_note: '補足情報',
  order_memo_1: 'オーダー1',
  rakumart_url_1: 'RM1',
  order_memo_2: 'オーダー2',
  rakumart_url_2: 'RM2',
  order_memo_3: 'オーダー3',
  rakumart_url_3: 'RM3',
  order_memo_4: 'オーダー4',
  rakumart_url_4: 'RM4',
  order_memo_5: 'オーダー5',
  rakumart_url_5: 'RM5',
}


type CsvImportResult = {
  rows: CleanBulkProductRow[]
  fields: BulkFieldKey[]
}

type CsvColumnMapping = {
  filename: string
  headers: string[]
  dataRows: string[][]
  productCodeIndex: number | null
  fieldIndexes: Partial<Record<BulkFieldKey, number>>
}

type CsvMappingKey = BulkFieldKey | 'product_code'

const CSV_HEADER_ALIASES: Record<BulkFieldKey | 'product_code', string[]> = {
  product_code: [
    '商品コード',
    '商品番号',
    '商品管理番号',
    'SKUコード',
    'product_code',
    'productCode',
    'code',
    'sku',
  ],
  product_name: [
    '商品名',
    'product_name',
    'productName',
    'shipping_name',
    'shippingName',
    'name',
  ],
  floor: ['階数', 'フロア', 'floor'],
  shipping_floor: ['配送-階-特記', '配送方-階数', '配送方法-階数', '配送方階数', '配送方法階数', '配送階特記', 'shipping_floor', 'shippingFloor'],
  rack_number: [
    '棚番号-位置',
    '棚番号位置',
    '棚番号',
    'ラック番号',
    'rack_number',
    'rackNumber',
    'rack',
    'location',
  ],
  rack_level: [
    '棚番号-段',
    '棚番号段',
    '段',
    'ラック段',
    'rack_level',
    'rackLevel',
    'level',
  ],
  sticker_color: [
    'シールカラー',
    'シール色',
    'sticker_color',
    'stickerColor',
    'color',
  ],
  special_notes: ['特記事項', '2行目', '注意事項', 'special_notes', 'specialNotes', 'notes', 'note'],
  delivery_line_4: ['4行目', 'delivery_line_4', 'deliveryLine4', 'line4'],
  picking_advice: [
    'ピック時アドバイス',
    '3行目',
    'ピックアドバイス',
    'picking_advice',
    'pickingAdvice',
    'advice',
  ],
  order_url_1: ['発注URL1', '発注URL 1', 'order_url_1', 'orderUrl1', 'purchase_url_1', 'purchaseUrl1'],
  order_url_2: ['発注URL2', '発注URL 2', 'order_url_2', 'orderUrl2', 'purchase_url_2', 'purchaseUrl2'],
  order_url_3: ['発注URL3', '発注URL 3', 'order_url_3', 'orderUrl3', 'purchase_url_3', 'purchaseUrl3'],
  order_size: ['サイズ', 'order_size', 'orderSize', 'purchase_size', 'purchaseSize', 'size'],
  order_color: ['カラー', '色', 'order_color', 'orderColor', 'purchase_color', 'purchaseColor'],
  order_simple_instruction: [
    '■簡潔指示',
    '簡潔指示',
    'order_simple_instruction',
    'orderSimpleInstruction',
    'simple_instruction',
    'simpleInstruction',
  ],
  order_detail_instruction: [
    '▲具体指示',
    '具体指示',
    'order_detail_instruction',
    'orderDetailInstruction',
    'detail_instruction',
    'detailInstruction',
  ],
  order_quantity_condition: [
    '数量条件指定',
    '数量条件',
    'order_quantity_condition',
    'orderQuantityCondition',
    'quantity_condition',
    'quantityCondition',
  ],
  order_note: ['補足情報', '補足', 'order_note', 'orderNote', 'purchase_note', 'purchaseNote'],
  order_out: ['out', 'order_out', 'orderOut', '取扱終了', '廃番'],
  no_1688_shop: ['1688ショップなし', '1688ショップ無し', 'no_1688_shop', 'no1688shop'],
}

type BulkSummary = {
  filledCount: number
  uniqueRows: CleanBulkProductRow[]
  insertRows: CleanBulkProductRow[]
  updateRows: CleanBulkProductRow[]
  existingCount: number
  duplicateCodes: string[]
}

const INITIAL_BULK_ROW_COUNT = 10

function createEmptyCleanBulkProductRow(productCode = ''): CleanBulkProductRow {
  return {
    product_code: productCode,
    product_name: '',
    floor: '',
    shipping_floor: '',
    special_notes: '',
    picking_advice: '',
    delivery_line_4: '',
    rack_number: '',
    rack_level: '',
    sticker_color: '',
    order_url_1: '',
    order_url_2: '',
    order_url_3: '',
    order_size: '',
    order_color: '',
    order_simple_instruction: '',
    order_detail_instruction: '',
    order_quantity_condition: '',
    order_note: '',
    order_out: false,
    no_1688_shop: false,
  }
}

function getBulkFieldLabel(key: BulkFieldKey) {
  return BULK_FIELD_COLUMNS.find((column) => column.key === key)?.label ?? key
}

function createBulkRow(): BulkProductRow {
  return {
    id:
      typeof crypto !== 'undefined' && 'randomUUID' in crypto
        ? crypto.randomUUID()
        : `${Date.now()}-${Math.random()}`,
    product_code: '',
    product_name: '',
    floor: '',
    shipping_floor: '',
    special_notes: '',
    picking_advice: '',
    delivery_line_4: '',
    rack_number: '',
    rack_level: '',
    sticker_color: '',
    order_url_1: '',
    order_url_2: '',
    order_url_3: '',
    order_size: '',
    order_color: '',
    order_simple_instruction: '',
    order_detail_instruction: '',
    order_quantity_condition: '',
    order_note: '',
    order_out: false,
    no_1688_shop: false,
  }
}

function createBulkRows(count = INITIAL_BULK_ROW_COUNT): BulkProductRow[] {
  return Array.from({ length: count }, () => createBulkRow())
}


function createDraftId() {
  return typeof crypto !== 'undefined' && 'randomUUID' in crypto
    ? crypto.randomUUID()
    : `${Date.now()}-${Math.random()}`
}

function createRakumartOptionDraft(group = '', value = ''): RakumartOptionDraft {
  return {
    id: createDraftId(),
    group,
    value,
  }
}

function createRakumartLineDraft(): RakumartLineDraft {
  return {
    id: createDraftId(),
    options: [],
    quantityMultiplier: '1',
    memo: '',
  }
}

function createRakumartSourceDraft(): RakumartSourceDraft {
  return {
    id: createDraftId(),
    sourceName: '',
    url: '',
    enabled: true,
    memo: '',
    lines: [createRakumartLineDraft()],
  }
}

function createRakumartItemDraft(): RakumartItemDraft {
  return {
    id: createDraftId(),
    itemName: '',
    required: true,
    memo: '',
    sources: [createRakumartSourceDraft()],
  }
}

function createEmptyRakumartRecipeDraft(): RakumartRecipeDraft {
  return {
    enabled: true,
    stopBeforeSubmit: true,
    remarkMode: 'manual',
    remarkTemplate: '',
    items: [createRakumartItemDraft()],
  }
}

function getRakumartLegacyOrderUrls(product: Product) {
  return [product.order_url_1, product.order_url_2, product.order_url_3]
    .map((url) => String(url ?? '').trim())
    .filter(Boolean)
}

function createRakumartLegacyOptions(product: Product) {
  const values = [product.order_size, product.order_color]
    .map((value) => String(value ?? '').trim())
    .filter(Boolean)

  return [...new Set(values)].map((value) => createRakumartOptionDraft('', value))
}

function createRakumartLegacyLine(product: Product, includeLegacyOptions: boolean) {
  return {
    ...createRakumartLineDraft(),
    options: includeLegacyOptions ? createRakumartLegacyOptions(product) : [],
  }
}

function createRakumartRecipeDraftFromLegacy(
  product: Product,
  relation: Exclude<RakumartLegacyUrlRelation, 'manual'>,
): RakumartRecipeDraft {
  const urls = getRakumartLegacyOrderUrls(product)
  if (urls.length === 0) {
    return createEmptyRakumartRecipeDraft()
  }

  const base = createEmptyRakumartRecipeDraft()
  const itemName = product.product_name?.trim() || '商品本体'

  if (relation === 'alternatives') {
    return {
      ...base,
      items: [
        {
          id: createDraftId(),
          itemName,
          required: true,
          memo: '',
          sources: urls.map((url, index) => ({
            id: createDraftId(),
            sourceName: index === 0 ? 'メイン' : `代替${index}`,
            url,
            enabled: true,
            memo: '',
            lines: [createRakumartLegacyLine(product, true)],
          })),
        },
      ],
    }
  }

  return {
    ...base,
    items: urls.map((url, index) => ({
      id: createDraftId(),
      itemName: index === 0 ? itemName : `構成品${index + 1}`,
      required: true,
      memo: '',
      sources: [
        {
          id: createDraftId(),
          sourceName: '',
          url,
          enabled: true,
          memo: '',
          lines: [createRakumartLegacyLine(product, index === 0)],
        },
      ],
    })),
  }
}

function parseRakumartOptions(value: unknown): RakumartOptionDraft[] {
  if (!Array.isArray(value)) {
    return []
  }

  return value
    .map((option) => {
      if (!option || typeof option !== 'object') {
        return null
      }

      const row = option as Record<string, unknown>
      const group = String(row.group ?? '').trim()
      const optionValue = String(row.value ?? '').trim()

      if (!group && !optionValue) {
        return null
      }

      return createRakumartOptionDraft(group, optionValue)
    })
    .filter((option): option is RakumartOptionDraft => Boolean(option))
}

function rakumartRecipeDbRowToDraft(row: RakumartRecipeDbRow): RakumartRecipeDraft {
  const items = [...(row.rakumart_order_items ?? [])]
    .sort((a, b) => Number(a.sort_order ?? 0) - Number(b.sort_order ?? 0))
    .map((item) => ({
      id: createDraftId(),
      itemName: item.item_name ?? '',
      required: item.required ?? true,
      memo: item.memo ?? '',
      sources: [...(item.rakumart_order_sources ?? [])]
        .sort((a, b) => Number(a.priority ?? 0) - Number(b.priority ?? 0))
        .map((source) => ({
          id: createDraftId(),
          sourceName: source.source_name ?? '',
          url: source.url ?? '',
          enabled: source.enabled ?? true,
          memo: source.memo ?? '',
          lines: [...(source.rakumart_order_lines ?? [])]
            .sort((a, b) => Number(a.sort_order ?? 0) - Number(b.sort_order ?? 0))
            .map((line) => ({
              id: createDraftId(),
              options: parseRakumartOptions(line.options),
              quantityMultiplier: String(line.quantity_multiplier ?? 1),
              memo: line.memo ?? '',
            })),
        })),
    }))

  return {
    enabled: row.enabled ?? false,
    stopBeforeSubmit: row.stop_before_submit ?? true,
    remarkMode:
      row.remark_mode === 'none' || row.remark_mode === 'template'
        ? row.remark_mode
        : 'manual',
    remarkTemplate: row.remark_template ?? '',
    items: items.length ? items : [createRakumartItemDraft()],
  }
}

function serializeRakumartRecipeDraft(draft: RakumartRecipeDraft) {
  if (draft.items.length === 0) {
    throw new Error('構成品を1件以上追加してください。')
  }

  return {
    enabled: draft.enabled,
    stop_before_submit: draft.stopBeforeSubmit,
    remark_mode: draft.remarkMode,
    remark_template: draft.remarkTemplate.trim() || null,
    items: draft.items.map((item, itemIndex) => {
      const itemName = item.itemName.trim()
      if (!itemName) {
        throw new Error(`構成品${itemIndex + 1}の名前を入力してください。`)
      }
      if (item.sources.length === 0) {
        throw new Error(`${itemName} に仕入先を1件以上追加してください。`)
      }

      return {
        item_name: itemName,
        required: item.required,
        memo: item.memo.trim() || null,
        sources: item.sources.map((source, sourceIndex) => {
          const url = source.url.trim()
          if (!url) {
            throw new Error(`${itemName} の仕入先${sourceIndex + 1}にURLを入力してください。`)
          }
          if (source.lines.length === 0) {
            throw new Error(`${itemName} の仕入先${sourceIndex + 1}に発注明細を1件以上追加してください。`)
          }

          return {
            source_name: source.sourceName.trim() || null,
            url,
            enabled: source.enabled,
            memo: source.memo.trim() || null,
            lines: source.lines.map((line, lineIndex) => {
              const quantityMultiplier = Number(line.quantityMultiplier)
              if (!Number.isFinite(quantityMultiplier) || quantityMultiplier <= 0) {
                throw new Error(
                  `${itemName} の仕入先${sourceIndex + 1}・明細${lineIndex + 1}の数量倍率を確認してください。`,
                )
              }

              const options = line.options.reduce<Array<{ group?: string; value: string }>>(
                (result, option, optionIndex) => {
                  const group = option.group.trim()
                  const value = option.value.trim()
                  if (!group && !value) {
                    return result
                  }
                  if (!value) {
                    throw new Error(
                      `${itemName} の仕入先${sourceIndex + 1}・明細${lineIndex + 1}・規格${optionIndex + 1}の「規格値」を入力してください。`,
                    )
                  }

                  result.push(group ? { group, value } : { value })
                  return result
                },
                [],
              )

              return {
                options,
                quantity_multiplier: quantityMultiplier,
                memo: line.memo.trim() || null,
              }
            }),
          }
        }),
      }
    }),
  }
}

function splitBulkLine(line: string) {
  const cells = line.includes('\t') ? line.split('\t') : line.split(',')
  return cells.map((cell) => cell.trim())
}

function normalizeCsvHeader(value: string) {
  return value
    .replace(/^\uFEFF/, '')
    .trim()
    .toLowerCase()
    .replace(/[\s_＿\-－ー]/g, '')
}

function getCsvColumnIndex(headers: string[], key: BulkFieldKey | 'product_code') {
  const normalizedAliases = CSV_HEADER_ALIASES[key].map(normalizeCsvHeader)

  return headers.findIndex((header) =>
    normalizedAliases.includes(normalizeCsvHeader(header)),
  )
}

function parseDelimitedRows(text: string, delimiter: ',' | '\t' = ',') {
  const rows: string[][] = []
  let row: string[] = []
  let cell = ''
  let inQuotes = false

  for (let index = 0; index < text.length; index += 1) {
    const char = text[index]
    const nextChar = text[index + 1]

    if (char === '"') {
      if (inQuotes && nextChar === '"') {
        cell += '"'
        index += 1
      } else {
        inQuotes = !inQuotes
      }
      continue
    }

    if (char === delimiter && !inQuotes) {
      row.push(cell.trim())
      cell = ''
      continue
    }

    if ((char === '\n' || char === '\r') && !inQuotes) {
      if (char === '\r' && nextChar === '\n') {
        index += 1
      }

      row.push(cell.trim())
      if (row.some((value) => value)) {
        rows.push(row)
      }
      row = []
      cell = ''
      continue
    }

    cell += char
  }

  row.push(cell.trim())
  if (row.some((value) => value)) {
    rows.push(row)
  }

  return rows
}

function parseCsvRows(text: string) {
  const firstLine = text.split(/\r?\n/, 1)[0] ?? ''
  const delimiter =
    firstLine.split('\t').length > firstLine.split(',').length ? '\t' : ','

  return parseDelimitedRows(text, delimiter)
}


function getInitialCsvFieldIndexes(headers: string[]) {
  return BULK_FIELD_COLUMNS.reduce<Partial<Record<BulkFieldKey, number>>>(
    (indexes, column) => {
      const index = getCsvColumnIndex(headers, column.key)

      if (index >= 0) {
        indexes[column.key] = index
      }

      return indexes
    },
    {},
  )
}

function createCsvColumnMapping(text: string, filename: string): CsvColumnMapping {
  const rows = parseCsvRows(text)

  if (rows.length < 2) {
    throw new Error('CSVに取り込めるデータ行がありません。')
  }

  const headers = rows[0]
  const productCodeIndex = getCsvColumnIndex(headers, 'product_code')

  return {
    filename,
    headers,
    dataRows: rows.slice(1),
    productCodeIndex: productCodeIndex >= 0 ? productCodeIndex : null,
    fieldIndexes: getInitialCsvFieldIndexes(headers),
  }
}

function getMappedCsvFields(fieldIndexes: Partial<Record<BulkFieldKey, number>>) {
  return BULK_FIELD_COLUMNS.map((column) => ({
    key: column.key,
    index: fieldIndexes[column.key],
  })).filter(
    (column): column is { key: BulkFieldKey; index: number } =>
      typeof column.index === 'number' && column.index >= 0,
  )
}

function getCsvColumnAssignment(
  mapping: CsvColumnMapping,
  columnIndex: number,
): CsvMappingKey | '' {
  if (mapping.productCodeIndex === columnIndex) {
    return 'product_code'
  }

  const assignedField = BULK_FIELD_COLUMNS.find(
    (column) => mapping.fieldIndexes[column.key] === columnIndex,
  )

  return assignedField?.key ?? ''
}

function csvColumnHasData(dataRows: string[][], columnIndex: number) {
  return dataRows.some((row) => (row[columnIndex] ?? '').trim())
}

function getUnassignedCsvColumnIndexes(mapping: CsvColumnMapping) {
  return mapping.headers
    .map((header, index) => ({ header, index }))
    .filter(({ header, index }) => {
      const hasHeaderOrData = Boolean(header.trim()) || csvColumnHasData(mapping.dataRows, index)
      return hasHeaderOrData && !getCsvColumnAssignment(mapping, index)
    })
    .map(({ index }) => index)
}

function csvMappingNeedsManualCheck(mapping: CsvColumnMapping) {
  const mappedFields = getMappedCsvFields(mapping.fieldIndexes)

  return (
    mapping.productCodeIndex === null ||
    mappedFields.length === 0 ||
    getUnassignedCsvColumnIndexes(mapping).length > 0
  )
}

function getCsvMappingMessage(mapping: CsvColumnMapping) {
  if (mapping.productCodeIndex === null || getMappedCsvFields(mapping.fieldIndexes).length === 0) {
    return `${mapping.filename} の列名を自動識別できませんでした。下の列割り当てで指定してください。`
  }

  const unassignedCount = getUnassignedCsvColumnIndexes(mapping).length

  return `${mapping.filename} に未識別列が ${unassignedCount} 列あります。全CSV列を確認して、必要な列だけ割り当ててください。`
}

function isBulkBooleanField(key: BulkFieldKey): key is 'order_out' | 'no_1688_shop' {
  return key === 'order_out' || key === 'no_1688_shop'
}

function parseBulkBoolean(value: string) {
  const normalized = value.trim().toLowerCase()

  return ['1', 'true', 'yes', 'y', 'on', '✓', '○', '〇', 'あり', '有', '有り'].includes(normalized)
}

function buildCsvImportResult(
  dataRows: string[][],
  productCodeIndex: number | null,
  fieldIndexes: Partial<Record<BulkFieldKey, number>>,
): CsvImportResult {
  if (productCodeIndex === null || productCodeIndex < 0) {
    throw new Error('商品コードに使うCSV列を選択してください。')
  }

  const mappedFields = getMappedCsvFields(fieldIndexes)

  if (mappedFields.length === 0) {
    throw new Error('追加/更新する列を1つ以上選択してください。')
  }

  const importedRows = dataRows
    .map((cells) => {
      const row = createEmptyCleanBulkProductRow(
        cells[productCodeIndex]?.trim() ?? '',
      )

      mappedFields.forEach(({ key, index }) => {
        const value = cells[index]?.trim() ?? ''

        if (isBulkBooleanField(key)) {
          row[key] = parseBulkBoolean(value)
        } else {
          row[key] = value
        }
      })

      return row
    })
    .filter((row) => row.product_code)

  if (importedRows.length === 0) {
    throw new Error('商品コードが入っている行がありません。')
  }

  return {
    rows: importedRows,
    fields: mappedFields.map((field) => field.key),
  }
}


function cleanRowToBulkRow(row: CleanBulkProductRow): BulkProductRow {
  return {
    id:
      typeof crypto !== 'undefined' && 'randomUUID' in crypto
        ? crypto.randomUUID()
        : `${Date.now()}-${Math.random()}`,
    ...row,
  }
}

function decodeCsvBuffer(buffer: ArrayBuffer) {
  const utf8Text = new TextDecoder('utf-8').decode(buffer)

  try {
    const shiftJisText = new TextDecoder('shift_jis').decode(buffer)
    const utf8ReplacementCount = (utf8Text.match(/�/g) ?? []).length
    const shiftJisReplacementCount = (shiftJisText.match(/�/g) ?? []).length

    if (
      utf8ReplacementCount > shiftJisReplacementCount ||
      (!utf8Text.includes('商品コード') && shiftJisText.includes('商品コード'))
    ) {
      return shiftJisText
    }
  } catch {
    // ブラウザがshift_jisのTextDecoderに未対応の場合はUTF-8として扱う
  }

  return utf8Text
}

function parseClipboardRows(
  text: string,
  selectedFields: BulkFieldKey[],
): CleanBulkProductRow[] {
  const lines = text
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter(Boolean)

  return lines
    .map((line, index) => {
      const cells = splitBulkLine(line)
      const firstCell = normalizeCsvHeader(cells[0] ?? '')

      if (
        index === 0 &&
        CSV_HEADER_ALIASES.product_code
          .map(normalizeCsvHeader)
          .includes(firstCell)
      ) {
        return null
      }

      const row = createEmptyCleanBulkProductRow(cells[0]?.trim() ?? '')

      selectedFields.forEach((key, fieldIndex) => {
        const value = cells[fieldIndex + 1]?.trim() ?? ''

        if (isBulkBooleanField(key)) {
          row[key] = parseBulkBoolean(value)
        } else {
          row[key] = value
        }
      })

      return row
    })
    .filter((row): row is CleanBulkProductRow => {
      return Boolean(row?.product_code)
    })
}


function buildBulkSummary(
  rows: BulkProductRow[],
  existingProductCodes: Set<string>,
): BulkSummary {
  const filledRows = rows
    .map((row) => ({
      product_code: row.product_code.trim(),
      product_name: row.product_name.trim(),
      floor: row.floor.trim(),
      shipping_floor: row.shipping_floor.trim(),
      special_notes: row.special_notes.trim(),
      picking_advice: row.picking_advice.trim(),
      delivery_line_4: row.delivery_line_4.trim(),
      rack_number: row.rack_number.trim(),
      rack_level: row.rack_level.trim(),
      sticker_color: row.sticker_color.trim(),
      order_url_1: row.order_url_1.trim(),
      order_url_2: row.order_url_2.trim(),
      order_url_3: row.order_url_3.trim(),
      order_size: row.order_size.trim(),
      order_color: row.order_color.trim(),
      order_simple_instruction: row.order_simple_instruction.trim(),
      order_detail_instruction: row.order_detail_instruction.trim(),
      order_quantity_condition: row.order_quantity_condition.trim(),
      order_note: row.order_note.trim(),
      order_out: row.order_out,
      no_1688_shop: row.no_1688_shop,
    }))
    .filter((row) => row.product_code)

  const seenCodes = new Set<string>()
  const duplicateCodeSet = new Set<string>()
  const uniqueRows: CleanBulkProductRow[] = []

  filledRows.forEach((row) => {
    if (seenCodes.has(row.product_code)) {
      duplicateCodeSet.add(row.product_code)
      return
    }

    seenCodes.add(row.product_code)
    uniqueRows.push(row)
  })

  const updateRows = uniqueRows.filter((row) =>
    existingProductCodes.has(row.product_code),
  )

  const insertRows = uniqueRows.filter(
    (row) => !existingProductCodes.has(row.product_code),
  )

  return {
    filledCount: filledRows.length,
    uniqueRows,
    insertRows,
    updateRows,
    existingCount: updateRows.length,
    duplicateCodes: Array.from(duplicateCodeSet),
  }
}


function formatNumericValue(value: number | string | null | undefined) {
  if (value === null || value === undefined || value === '') {
    return '-'
  }

  const numericValue = typeof value === 'number' ? value : Number(value)

  if (Number.isFinite(numericValue)) {
    return numericValue.toLocaleString('ja-JP')
  }

  return String(value)
}

function formatClassification(value: string | null | undefined) {
  return value?.trim() || 'NOR'
}

type MonthlySalesEntry = {
  key: string
  label: string
  value: number
}

type MonthlySalesMonth = {
  key: string
  label: string
  value: number
}

type MonthlySalesYearGroup = {
  yearKey: string
  yearLabel: string
  months: MonthlySalesMonth[]
}

function normalizeMonthLabel(year: string, month: string) {
  const normalizedYear = year.replace(/[^0-9]/g, '')
  const normalizedMonth = month.replace(/[^0-9]/g, '').padStart(2, '0')

  if (normalizedYear.length < 4 || !normalizedMonth) {
    return `${year}/${month}`
  }

  return `${normalizedYear.slice(-2)}/${normalizedMonth}`
}

function pushMonthlySalesEntry(
  entries: MonthlySalesEntry[],
  key: string,
  label: string,
  rawValue: unknown,
) {
  if (rawValue === null || rawValue === undefined || rawValue === '') {
    return
  }

  const numericValue = typeof rawValue === 'number' ? rawValue : Number(rawValue)

  if (!Number.isFinite(numericValue)) {
    return
  }

  entries.push({ key, label, value: numericValue })
}

function parseMonthlySalesSource(monthlySales: unknown) {
  if (!monthlySales) {
    return null
  }

  if (typeof monthlySales === 'string') {
    try {
      return JSON.parse(monthlySales) as unknown
    } catch {
      return null
    }
  }

  return monthlySales
}

function getProductMonthlySales(product: Product) {
  return product.monthly_sales ?? product.monthly_by_year ?? product.monthlyByYear ?? null
}

function getMonthLabelByArrayIndex(index: number) {
  return String(index + 1).padStart(2, '0')
}

function getMonthlySalesEntries(monthlySales: unknown): MonthlySalesEntry[] {
  const source = parseMonthlySalesSource(monthlySales)

  if (!source || typeof source !== 'object' || Array.isArray(source)) {
    return []
  }

  const entries: MonthlySalesEntry[] = []
  const record = source as Record<string, unknown>

  Object.entries(record).forEach(([yearOrMonthKey, value]) => {
    if (Array.isArray(value)) {
      value.forEach((monthValue, index) => {
        const year = normalizeYearKey(yearOrMonthKey)
        const month = getMonthLabelByArrayIndex(index)
        pushMonthlySalesEntry(entries, `${year}${month}`, `${year.slice(-2)}/${month}`, monthValue)
      })
      return
    }

    if (value && typeof value === 'object') {
      Object.entries(value as Record<string, unknown>).forEach(([monthKey, monthValue]) => {
        const year = yearOrMonthKey.replace(/[^0-9]/g, '')
        const month = monthKey.replace(/[^0-9]/g, '').padStart(2, '0')
        const sortKey = `${year}${month}`
        pushMonthlySalesEntry(
          entries,
          sortKey,
          normalizeMonthLabel(yearOrMonthKey, monthKey),
          monthValue,
        )
      })
      return
    }

    const normalizedKey = yearOrMonthKey.replace(/[^0-9]/g, '')
    if (normalizedKey.length >= 6) {
      const year = normalizedKey.slice(0, 4)
      const month = normalizedKey.slice(4, 6)
      pushMonthlySalesEntry(entries, `${year}${month}`, `${year.slice(-2)}/${month}`, value)
      return
    }

    pushMonthlySalesEntry(entries, yearOrMonthKey, yearOrMonthKey, value)
  })

  return entries.sort((a, b) => a.key.localeCompare(b.key, 'ja-JP', { numeric: true }))
}

function formatMonthlySales(monthlySales: unknown) {
  const entries = getMonthlySalesEntries(monthlySales)

  if (entries.length === 0) {
    return '-'
  }

  return entries
    .slice(-6)
    .map((entry) => `${entry.label}:${entry.value.toLocaleString('ja-JP')}`)
    .join(' / ')
}

function normalizeYearKey(year: string) {
  const normalized = year.replace(/[^0-9]/g, '')
  if (normalized.length >= 4) {
    return normalized.slice(0, 4)
  }
  return normalized || year
}

function normalizeMonthKey(month: string) {
  const normalized = month.replace(/[^0-9]/g, '')
  return normalized ? normalized.padStart(2, '0') : month
}

function pushMonthlySalesMonth(
  groupsByYear: Map<string, MonthlySalesYearGroup>,
  year: string,
  month: string,
  rawValue: unknown,
) {
  if (rawValue === null || rawValue === undefined || rawValue === '') {
    return
  }

  const value = typeof rawValue === 'number' ? rawValue : Number(rawValue)

  if (!Number.isFinite(value)) {
    return
  }

  const yearKey = normalizeYearKey(year)
  const monthKey = normalizeMonthKey(month)
  const yearLabel = yearKey.length === 4 ? `${yearKey}年` : `${year}年`
  const monthLabel = monthKey.length === 2 ? `${monthKey}月` : month

  if (!groupsByYear.has(yearKey)) {
    groupsByYear.set(yearKey, { yearKey, yearLabel, months: [] })
  }

  groupsByYear.get(yearKey)?.months.push({
    key: `${yearKey}${monthKey}`,
    label: monthLabel,
    value,
  })
}

function getMonthlySalesYearGroups(monthlySales: unknown): MonthlySalesYearGroup[] {
  const source = parseMonthlySalesSource(monthlySales)

  if (!source || typeof source !== 'object' || Array.isArray(source)) {
    return []
  }

  const groupsByYear = new Map<string, MonthlySalesYearGroup>()
  const record = source as Record<string, unknown>

  Object.entries(record).forEach(([yearOrMonthKey, value]) => {
    if (Array.isArray(value)) {
      value.forEach((monthValue, index) => {
        pushMonthlySalesMonth(
          groupsByYear,
          yearOrMonthKey,
          getMonthLabelByArrayIndex(index),
          monthValue,
        )
      })
      return
    }

    if (value && typeof value === 'object') {
      Object.entries(value as Record<string, unknown>).forEach(([monthKey, monthValue]) => {
        pushMonthlySalesMonth(groupsByYear, yearOrMonthKey, monthKey, monthValue)
      })
      return
    }

    const normalizedKey = yearOrMonthKey.replace(/[^0-9]/g, '')
    if (normalizedKey.length >= 6) {
      pushMonthlySalesMonth(
        groupsByYear,
        normalizedKey.slice(0, 4),
        normalizedKey.slice(4, 6),
        value,
      )
    }
  })

  return Array.from(groupsByYear.values())
    .map((group) => ({
      ...group,
      months: group.months.sort((a, b) => a.key.localeCompare(b.key, 'ja-JP', { numeric: true })),
    }))
    .sort((a, b) => a.yearKey.localeCompare(b.yearKey, 'ja-JP', { numeric: true }))
}

function MonthlySalesByYear({ monthlySales }: { monthlySales: unknown }) {
  const groups = useMemo(() => getMonthlySalesYearGroups(monthlySales), [monthlySales])
  const [selectedYearKey, setSelectedYearKey] = useState<string | null>(null)

  if (groups.length === 0) {
    return <DisplayText value="-" className="monthly-sales-empty" />
  }

  const activeGroup = selectedYearKey
    ? groups.find((group) => group.yearKey === selectedYearKey) ?? null
    : null

  return (
    <div className="monthly-sales-panel">
      <div className="monthly-sales-year-buttons">
        {groups.map((group) => (
          <button
            key={group.yearKey}
            type="button"
            className={`monthly-sales-year-button${group.yearKey === selectedYearKey ? ' is-active' : ''}`}
            onClick={() =>
              setSelectedYearKey((currentYearKey) =>
                currentYearKey === group.yearKey ? null : group.yearKey,
              )
            }
          >
            {group.yearLabel}
          </button>
        ))}
      </div>
      {activeGroup && (
        <div className="monthly-sales-month-grid">
          {activeGroup.months.map((month) => (
            <span key={month.key} className="monthly-sales-month-chip">
              <span>{month.label}</span>
              <strong>{month.value.toLocaleString('ja-JP')}</strong>
            </span>
          ))}
        </div>
      )}
    </div>
  )
}

function formatDateTime(value: string | null) {
  if (!value) return ''

  const date = new Date(value)

  if (Number.isNaN(date.getTime())) {
    return ''
  }

  return date.toLocaleString('ja-JP')
}

function previewValue(value: string) {
  return value.trim() || '未入力'
}

function PreviewMissingText({ children }: { children: string }) {
  return <span className="delivery-preview-missing">{children}</span>
}

function renderPreviewValue(value: string, className?: string) {
  const text = previewValue(value)
  if (text === '未入力') {
    return <PreviewMissingText>{text}</PreviewMissingText>
  }

  return <span className={className}>{text}</span>
}

const DELIVERY_PREVIEW_NAME_CONTENT_WIDTH = 236
const DELIVERY_PREVIEW_CODE_CONTENT_WIDTH = 218
const DELIVERY_PREVIEW_NAME_CHAR_SCALE = 0.68
const DELIVERY_PREVIEW_CODE_CHAR_SCALE = 0.52

function normalizePreviewLineBreaks(value: string) {
  return String(value ?? '')
    .replace(/<br\s*\/?>/gi, '\n')
    .replace(/\\n/g, '\n')
}

function measurePreviewText(value: string, fontSizePx: number, fontWeight = 700, halfWidthScale = DELIVERY_PREVIEW_NAME_CHAR_SCALE) {
  const text = String(value ?? '')
  const weightBump = fontWeight >= 850 ? 1.02 : 1

  return Array.from(text).reduce((sum, ch) => {
    const code = ch.codePointAt(0) ?? 0

    if (/\s/.test(ch)) {
      return sum + fontSizePx * 0.35
    }

    const isJapanese = /[ぁ-んァ-ン一-龥]/.test(ch)
    const isWideSymbol = code >= 0x3000 && code <= 0xffef
    const unit = isJapanese || isWideSymbol ? fontSizePx : fontSizePx * halfWidthScale

    return sum + unit * weightBump
  }, 0)
}

function wrapPreviewText(value: string, maxWidthPx: number, fontSizePx: number, fontWeight = 700, halfWidthScale = DELIVERY_PREVIEW_NAME_CHAR_SCALE) {
  const normalized = normalizePreviewLineBreaks(value)
  const output: string[] = []

  for (const raw of normalized.split('\n')) {
    const line = raw.trim()

    if (!line) {
      if (output.length > 0) output.push('')
      continue
    }

    let current = ''
    for (const ch of Array.from(line)) {
      const candidate = current + ch

      if (!current || measurePreviewText(candidate, fontSizePx, fontWeight, halfWidthScale) <= maxWidthPx) {
        current = candidate
      } else {
        output.push(current)
        current = ch
      }
    }

    if (current) output.push(current)
  }

  while (output.length > 0 && output[0] === '') {
    output.shift()
  }

  return output
}

function wrapPreviewCode(value: string) {
  const code = String(value ?? '').trim()
  if (!code) return []
  if (measurePreviewText(code, 15, 700, DELIVERY_PREVIEW_CODE_CHAR_SCALE) <= DELIVERY_PREVIEW_CODE_CONTENT_WIDTH) return [code]

  const chunks = code.split('-')
  if (chunks.length <= 1) {
    return wrapPreviewText(code, DELIVERY_PREVIEW_CODE_CONTENT_WIDTH, 15, 700, DELIVERY_PREVIEW_CODE_CHAR_SCALE)
  }

  const lines: string[] = []
  let current = chunks[0] ?? ''

  for (const chunk of chunks.slice(1)) {
    const candidate = `${current}-${chunk}`
    if (!current || measurePreviewText(candidate, 15, 700, DELIVERY_PREVIEW_CODE_CHAR_SCALE) <= DELIVERY_PREVIEW_CODE_CONTENT_WIDTH) {
      current = candidate
    } else {
      lines.push(`${current}-`)
      current = chunk
    }
  }

  if (current || lines.length === 0) lines.push(current)
  return lines
}

function PreviewLines({
  lines,
  className,
}: {
  lines: string[]
  className?: string
}) {
  return (
    <>
      {lines.map((line, index) => (
        <span key={`${className ?? 'line'}-${index}`} className={className}>
          {line}
        </span>
      ))}
    </>
  )
}

function DeliverySlipPreview({ preview }: { preview: DeliverySlipPreviewData }) {
  const hasSticker = preview.stickerColor.trim().length > 0
  const productNameLines = wrapPreviewText(preview.productName, DELIVERY_PREVIEW_NAME_CONTENT_WIDTH, 16, 900, DELIVERY_PREVIEW_NAME_CHAR_SCALE)
  const specialNoteLines = wrapPreviewText(preview.specialNotes, DELIVERY_PREVIEW_NAME_CONTENT_WIDTH, 11.5, 800, DELIVERY_PREVIEW_NAME_CHAR_SCALE)
  const pickingAdviceLines = wrapPreviewText(preview.pickingAdvice, DELIVERY_PREVIEW_NAME_CONTENT_WIDTH, 11.5, 800, DELIVERY_PREVIEW_NAME_CHAR_SCALE)
  const deliveryLine4Lines = wrapPreviewText(preview.deliveryLine4, DELIVERY_PREVIEW_NAME_CONTENT_WIDTH, 11.5, 800, DELIVERY_PREVIEW_NAME_CHAR_SCALE)
  const productCodeLines = wrapPreviewCode(preview.productCode)

  return (
    <div className="delivery-preview-wrap">
      <table className="delivery-preview-table">
        <thead>
          <tr>
            <th>棚番号</th>
            <th>シール</th>
            <th>商品名</th>
            <th>商品コード</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td className="delivery-preview-shelf">
              <div className="delivery-preview-shelf-stack">
                <span className="delivery-preview-floor">
                  {renderPreviewValue(preview.floor)}
                </span>
                <span className="delivery-preview-rack">
                  {renderPreviewValue(preview.rackNumber)}
                </span>
                <span className="delivery-preview-level">
                  {renderPreviewValue(preview.rackLevel)}
                </span>
              </div>
            </td>
            <td className={hasSticker ? 'delivery-preview-sticker has-sticker' : 'delivery-preview-sticker'}>
              {hasSticker ? preview.stickerColor.trim() : ''}
            </td>
            <td className="delivery-preview-name">
              <div className="delivery-preview-name-stack">
                {productNameLines.length > 0 ? (
                  <PreviewLines lines={productNameLines} className="delivery-preview-name-main" />
                ) : (
                  <PreviewMissingText>未入力</PreviewMissingText>
                )}
                <PreviewLines lines={specialNoteLines} className="delivery-preview-name-sub" />
                <PreviewLines lines={pickingAdviceLines} className="delivery-preview-name-sub" />
                <PreviewLines lines={deliveryLine4Lines} className="delivery-preview-name-sub" />
              </div>
            </td>
            <td className="delivery-preview-code">
              {productCodeLines.length > 0 ? (
                <PreviewLines lines={productCodeLines} className="mono-text" />
              ) : (
                <PreviewMissingText>未入力</PreviewMissingText>
              )}
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  )
}

function productToDraft(product: Product): EditableProduct {
  return {
    product_name: product.product_name ?? '',
    floor: product.floor ?? '',
    shipping_floor: product.shipping_floor ?? '',
    special_notes: product.special_notes ?? '',
    picking_advice: product.picking_advice ?? '',
    delivery_line_4: product.delivery_line_4 ?? '',
    rack_number: product.rack_number ?? '',
    rack_level: product.rack_level ?? '',
    paper_sort_sub: Boolean(product.paper_sort_sub),
    sticker_color: product.sticker_color ?? '',
    order_url_1: product.order_url_1 ?? '',
    order_url_2: product.order_url_2 ?? '',
    order_url_3: product.order_url_3 ?? '',
    order_size: product.order_size ?? '',
    order_color: product.order_color ?? '',
    order_simple_instruction: product.order_simple_instruction ?? '',
    order_detail_instruction: product.order_detail_instruction ?? '',
    order_quantity_condition: product.order_quantity_condition ?? '',
    order_note: product.order_note ?? '',
    order_out: Boolean(product.order_out),
    no_1688_shop: Boolean(product.no_1688_shop),
    order_memo_1: product.order_memo_1 ?? '',
    rakumart_url_1: product.rakumart_url_1 ?? '',
    order_memo_2: product.order_memo_2 ?? '',
    rakumart_url_2: product.rakumart_url_2 ?? '',
    order_memo_3: product.order_memo_3 ?? '',
    rakumart_url_3: product.rakumart_url_3 ?? '',
    order_memo_4: product.order_memo_4 ?? '',
    rakumart_url_4: product.rakumart_url_4 ?? '',
    order_memo_5: product.order_memo_5 ?? '',
    rakumart_url_5: product.rakumart_url_5 ?? '',
  }
}


function buildProductSearchText(product: Product) {
  return [
    product.product_code,
    product.product_name,
    product.floor,
    product.shipping_floor,
    formatClassification(product.orderboard_classification),
    formatNumericValue(product.free_stock),
    formatNumericValue(product.reorder_point),
    formatNumericValue(product.stock_constant),
    formatMonthlySales(getProductMonthlySales(product)),
    product.special_notes,
    product.picking_advice,
    product.delivery_line_4,
    product.rack_number,
    product.rack_level,
    product.sticker_color,
    product.order_url_1,
    product.order_url_2,
    product.order_url_3,
    product.order_size,
    product.order_color,
    product.order_simple_instruction,
    product.order_detail_instruction,
    product.order_quantity_condition,
    product.order_note,
    product.order_memo_1,
    product.rakumart_url_1,
    product.order_memo_2,
    product.rakumart_url_2,
    product.order_memo_3,
    product.rakumart_url_3,
    product.order_memo_4,
    product.rakumart_url_4,
    product.order_memo_5,
    product.rakumart_url_5,
  ]
    .filter(Boolean)
    .join('\n')
    .toLowerCase()
}

function normalizeDraft(draft: EditableProduct) {
  return {
    product_name: draft.product_name.trim() || null,
    floor: draft.floor.trim() || null,
    shipping_floor: draft.shipping_floor.trim() || null,
    special_notes: draft.special_notes.trim() || null,
    picking_advice: draft.picking_advice.trim() || null,
    delivery_line_4: draft.delivery_line_4.trim() || null,
    rack_number: draft.rack_number.trim() || null,
    rack_level: draft.rack_level.trim() || null,
    paper_sort_sub: Boolean(draft.paper_sort_sub),
    sticker_color: draft.sticker_color.trim() || null,
    order_url_1: draft.order_url_1.trim() || null,
    order_url_2: draft.order_url_2.trim() || null,
    order_url_3: draft.order_url_3.trim() || null,
    order_size: draft.order_size.trim() || null,
    order_color: draft.order_color.trim() || null,
    order_simple_instruction: draft.order_simple_instruction.trim() || null,
    order_detail_instruction: draft.order_detail_instruction.trim() || null,
    order_quantity_condition: draft.order_quantity_condition.trim() || null,
    order_note: draft.order_note.trim() || null,
    order_out: Boolean(draft.order_out),
    no_1688_shop: Boolean(draft.no_1688_shop),
    order_memo_1: draft.order_memo_1.trim() || null,
    rakumart_url_1: draft.rakumart_url_1.trim() || null,
    order_memo_2: draft.order_memo_2.trim() || null,
    rakumart_url_2: draft.rakumart_url_2.trim() || null,
    order_memo_3: draft.order_memo_3.trim() || null,
    rakumart_url_3: draft.rakumart_url_3.trim() || null,
    order_memo_4: draft.order_memo_4.trim() || null,
    rakumart_url_4: draft.rakumart_url_4.trim() || null,
    order_memo_5: draft.order_memo_5.trim() || null,
    rakumart_url_5: draft.rakumart_url_5.trim() || null,
  }
}

function isDraftDirty(product: Product, draft: EditableProduct) {
  const original = productToDraft(product)

  return (Object.keys(original) as EditableProductKey[]).some(
    (key) => original[key] !== draft[key],
  )
}


function getProductImagePath(productCode: string) {
  return `${productCode.trim()}${PRODUCT_IMAGE_EXTENSION}`
}

function getProductImageUrl(productCode: string, version: number) {
  if (!productCode.trim()) {
    return ''
  }

  const { data } = supabase.storage
    .from(PRODUCT_IMAGE_BUCKET)
    .getPublicUrl(getProductImagePath(productCode))

  if (!data.publicUrl) {
    return ''
  }

  return version ? `${data.publicUrl}?v=${version}` : data.publicUrl
}

function getProductCodeFromImageFile(file: File) {
  return file.name.replace(/\.[^.]+$/, '').trim()
}

function isSupportedProductImageFile(file: File) {
  const fileName = file.name.toLowerCase()
  const fileType = file.type.toLowerCase()

  return (
    fileType === 'image/jpeg' ||
    fileType === 'image/png' ||
    fileType === 'image/webp' ||
    fileName.endsWith('.jpg') ||
    fileName.endsWith('.jpeg') ||
    fileName.endsWith('.png') ||
    fileName.endsWith('.webp')
  )
}

async function convertImageFileToWebp(file: File) {
  const imageBitmap = await createImageBitmap(file)

  try {
    const canvas = document.createElement('canvas')
    canvas.width = imageBitmap.width
    canvas.height = imageBitmap.height

    const context = canvas.getContext('2d')

    if (!context) {
      throw new Error('画像変換用のCanvasを作成できませんでした。')
    }

    context.drawImage(imageBitmap, 0, 0)

    return await new Promise<Blob>((resolve, reject) => {
      canvas.toBlob(
        (blob) => {
          if (blob) {
            resolve(blob)
          } else {
            reject(new Error('WebP変換に失敗しました。'))
          }
        },
        'image/webp',
        PRODUCT_IMAGE_WEBP_QUALITY,
      )
    })
  } finally {
    imageBitmap.close()
  }
}

async function uploadProductImageFile(productCode: string, file: File) {
  const webpBlob = await convertImageFileToWebp(file)
  const { error } = await supabase.storage
    .from(PRODUCT_IMAGE_BUCKET)
    .upload(getProductImagePath(productCode), webpBlob, {
      cacheControl: '3600',
      contentType: 'image/webp',
      upsert: true,
    })

  if (error) {
    throw new Error(error.message)
  }
}

async function runWithConcurrency<T>(
  items: T[],
  concurrency: number,
  worker: (item: T) => Promise<void>,
) {
  const queue = [...items]
  const workers = Array.from({ length: Math.min(concurrency, queue.length) }, async () => {
    while (queue.length > 0) {
      const item = queue.shift()
      if (item) {
        await worker(item)
      }
    }
  })

  await Promise.all(workers)
}

function ProductImageCell({
  product,
  version,
  isEditing,
  draftImage,
  onPreview,
  onImageFilesDrop,
}: {
  product: Product
  version: number
  isEditing: boolean
  draftImage?: ProductImageDraft
  onPreview: (preview: ProductImagePreview) => void
  onImageFilesDrop: (product: Product, files: File[]) => void
}) {
  const [failedImageUrl, setFailedImageUrl] = useState<string | null>(null)
  const [isDragOver, setIsDragOver] = useState(false)

  const imageUrl = getProductImageUrl(product.product_code, version)
  const displayUrl = draftImage?.previewUrl ?? imageUrl
  const hasError = Boolean(displayUrl && failedImageUrl === displayUrl)
  const shouldShowImage = Boolean(displayUrl) && !hasError

  function handleDragOver(event: DragEvent<HTMLDivElement>) {
    if (!isEditing) {
      return
    }

    event.preventDefault()
    event.stopPropagation()
    event.dataTransfer.dropEffect = 'copy'
    setIsDragOver(true)
  }

  function handleDragLeave(event: DragEvent<HTMLDivElement>) {
    const nextTarget = event.relatedTarget as Node | null

    if (!nextTarget || !event.currentTarget.contains(nextTarget)) {
      setIsDragOver(false)
    }
  }

  function handleDrop(event: DragEvent<HTMLDivElement>) {
    if (!isEditing) {
      return
    }

    event.preventDefault()
    event.stopPropagation()
    setIsDragOver(false)
    onImageFilesDrop(product, Array.from(event.dataTransfer.files ?? []))
  }

  const dropClassName = [
    'product-image-drop-target',
    isEditing ? 'is-editing' : '',
    isDragOver ? 'is-drag-over' : '',
    draftImage ? 'is-pending' : '',
  ]
    .filter(Boolean)
    .join(' ')

  return (
    <div
      className={dropClassName}
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
      title={isEditing ? '画像をドロップして保存待ちにする' : undefined}
    >
      {shouldShowImage ? (
        <button
          type="button"
          className="product-image-button"
          onClick={() =>
            onPreview({
              productCode: product.product_code,
              productName: product.product_name,
              url: displayUrl,
            })
          }
          title={draftImage ? '保存待ち画像をプレビュー' : '画像をプレビュー'}
        >
          <img
            src={displayUrl}
            alt={product.product_name || product.product_code}
            loading="lazy"
            onError={() => setFailedImageUrl(displayUrl)}
          />
        </button>
      ) : (
        <span
          className={isEditing ? 'product-image-placeholder is-editing' : 'product-image-placeholder'}
          role="img"
          aria-label={isEditing ? '画像をドロップ' : '画像なし'}
          title={isEditing ? undefined : '画像なし'}
        >
          {isEditing ? '画像\nドロップ' : ''}
        </span>
      )}

      {draftImage && <span className="product-image-pending-badge">未保存</span>}
    </div>
  )
}

function UrlEditCell({
  value,
  onChange,
  placeholder = 'URL',
}: {
  value: string
  onChange: (value: string) => void
  placeholder?: string
}) {
  return (
    <div className="url-edit-cell">
      <input
        className="table-input url-input"
        value={value}
        onChange={(event) => onChange(event.target.value)}
        placeholder={placeholder}
      />

      {value.trim() ? (
        <a className="url-button" href={value.trim()} target="_blank" rel="noreferrer">
          開く
        </a>
      ) : (
        <span className="empty-url">-</span>
      )}
    </div>
  )
}

function DisplayText({ value, className = '' }: { value: string | null; className?: string }) {
  return <span className={`cell-text ${className}`}>{value || '-'}</span>
}

function safeParseJson<T>(value: string | null, fallback: T): T {
  if (!value) {
    return fallback
  }

  try {
    return JSON.parse(value) as T
  } catch {
    return fallback
  }
}

function currentJstYearMonth(): { year: number; month: number } {
  const [year, month] = new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Asia/Tokyo',
    year: 'numeric',
    month: '2-digit',
  })
    .format(new Date())
    .split('-')
    .map(Number)

  return { year, month }
}

function addMonths(year: number, month: number, delta: number): { year: number; month: number } {
  const zeroBased = year * 12 + (month - 1) + delta
  const normalizedMonth = ((zeroBased % 12) + 12) % 12

  return { year: Math.floor(zeroBased / 12), month: normalizedMonth + 1 }
}

function makeYearMonthKey(year: number, month: number) {
  return `${year}-${String(month).padStart(2, '0')}`
}

function buildSelectableNeMonths(range = 24) {
  const end = currentJstYearMonth()
  const result: string[] = []

  for (let index = range - 1; index >= 0; index -= 1) {
    const value = addMonths(end.year, end.month, -index)
    if (value.year >= NE_SYNC_MONTH_MIN_YEAR) {
      result.push(makeYearMonthKey(value.year, value.month))
    }
  }

  return result
}

function groupYearMonths(yearMonths: string[]) {
  const map = new Map<string, string[]>()

  yearMonths.forEach((key) => {
    const [year] = key.split('-')
    if (!year) {
      return
    }
    map.set(year, [...(map.get(year) ?? []), key])
  })

  return Array.from(map.entries()).map(([year, months]) => ({ year, months }))
}

function selectedNeOperationalFieldKeys(fields: NeSyncFieldState): NeOperationalFieldKey[] {
  const result: NeOperationalFieldKey[] = []

  if (fields.freeStock) {
    result.push('free_stock')
  }
  if (fields.reorderPoint) {
    result.push('reorder_point')
  }
  if (fields.stockConstant) {
    result.push('stock_constant')
  }

  return result
}


function normalizeColumnWidths(value: unknown): ColumnWidthMap {
  if (!value || typeof value !== 'object' || Array.isArray(value)) {
    return {}
  }

  return Object.fromEntries(
    Object.entries(value as Record<string, unknown>)
      .filter(([, width]) => typeof width === 'number' && Number.isFinite(width))
      .map(([key, width]) => [key, clampColumnWidth(width as number)]),
  )
}

function safeParseColumnWidths(raw: string | null): ColumnWidthMap {
  if (!raw) {
    return {}
  }

  try {
    return normalizeColumnWidths(JSON.parse(raw) as unknown)
  } catch {
    return {}
  }
}

function getColumnWidthSettingKey(view: TableView) {
  return `${COLUMN_WIDTH_SETTING_PREFIX}:${view}`
}

function clampColumnWidth(width: number) {
  return Math.max(MIN_COLUMN_WIDTH, Math.min(MAX_COLUMN_WIDTH, Math.round(width)))
}

function isSortableColumn(key: string): key is SortableColumnKey {
  return SORTABLE_COLUMN_SET.has(key)
}

function getProductSortValue(product: Product, key: SortableColumnKey): string | number | null {
  switch (key) {
    case 'free_stock':
    case 'reorder_point':
    case 'stock_constant':
      return product[key]
    case 'orderboard_classification':
      return formatClassification(product.orderboard_classification)
    case 'product_code':
      return product.product_code
    case 'product_name':
      return product.product_name
    case 'floor':
      return product.floor
    case 'shipping_floor':
      return product.shipping_floor
    case 'rack_number':
      return product.rack_number
    case 'rack_level':
      return product.rack_level
    case 'sticker_color':
      return product.sticker_color
    case 'paper_sort_sub':
      return product.paper_sort_sub ? 1 : 0
    case 'order_out':
      return product.order_out ? 1 : 0
    case 'no_1688_shop':
      return product.no_1688_shop ? 1 : 0
    case 'order_memo_1':
      return product.order_memo_1
    case 'order_memo_2':
      return product.order_memo_2
    case 'order_memo_3':
      return product.order_memo_3
    case 'order_memo_4':
      return product.order_memo_4
    case 'order_memo_5':
      return product.order_memo_5
    default:
      return null
  }
}

function isBlankSortValue(value: string | number | null) {
  return value === null || value === undefined || String(value).trim() === ''
}

function compareProductsBySort(productA: Product, productB: Product, config: Exclude<SortConfig, null>) {
  const valueA = getProductSortValue(productA, config.key)
  const valueB = getProductSortValue(productB, config.key)
  const isBlankA = isBlankSortValue(valueA)
  const isBlankB = isBlankSortValue(valueB)

  if (isBlankA && isBlankB) {
    return productA.product_code.localeCompare(productB.product_code, 'ja', { numeric: true, sensitivity: 'base' })
  }

  if (isBlankA) {
    return 1
  }

  if (isBlankB) {
    return -1
  }

  const numericColumns: SortableColumnKey[] = ['free_stock', 'reorder_point', 'stock_constant', 'paper_sort_sub', 'order_out', 'no_1688_shop']
  const baseResult = numericColumns.includes(config.key)
    ? Number(valueA) - Number(valueB)
    : String(valueA).localeCompare(String(valueB), 'ja', { numeric: true, sensitivity: 'base' })

  const result = baseResult === 0
    ? productA.product_code.localeCompare(productB.product_code, 'ja', { numeric: true, sensitivity: 'base' })
    : baseResult

  return config.direction === 'asc' ? result : -result
}

function getNeColumnSpecs(): ColumnSpec[] {
  return [
    { key: 'free_stock', label: 'フリー在庫', width: 110 },
    { key: 'reorder_point', label: '発注点', width: 98 },
    { key: 'stock_constant', label: '在庫定数', width: 109 },
    { key: 'monthly_sales', label: '月別受注数', width: 253 },
    { key: 'orderboard_classification', label: '分類', width: 85 },
  ]
}

// 「すべて」ビューの列。カスタムビューはここからチェックした列だけを同じ順番で表示する
function getAllViewColumnSpecs(): ColumnSpec[] {
  return [
    { key: 'product_name', label: '商品名', width: 219 },
    ...getNeColumnSpecs(),
    { key: 'floor', label: '階数', width: 87 },
    { key: 'special_notes', label: '2行目', width: 171 },
    { key: 'picking_advice', label: '3行目', width: 175 },
    { key: 'delivery_line_4', label: '4行目', width: 175 },
    { key: 'rack_number', label: '棚番号-位置', width: 126 },
    { key: 'rack_level', label: '棚番号-段', width: 114 },
    { key: 'sticker_color', label: 'シールカラー', width: 116 },
    { key: 'shipping_floor', label: '配送-階-特記', width: 138 },
    { key: 'paper_sort_sub', label: 'サブ商品', width: 104 },
    { key: 'delivery_preview', label: '納品書プレビュー', width: 120 },
    { key: 'order_memo_1', label: 'オーダー1', width: 145 },
    { key: 'order_memo_2', label: 'オーダー2', width: 145 },
    { key: 'order_memo_3', label: 'オーダー3', width: 145 },
    { key: 'order_memo_4', label: 'オーダー4', width: 145 },
    { key: 'order_memo_5', label: 'オーダー5', width: 145 },
    { key: 'order_url_1', label: '発注URL1', width: 113 },
    { key: 'order_url_2', label: '発注URL2', width: 113 },
    { key: 'order_url_3', label: '発注URL3', width: 113 },
    { key: 'order_size', label: 'サイズ', width: 110 },
    { key: 'order_color', label: 'カラー', width: 110 },
    { key: 'order_simple_instruction', label: '■簡潔指示', width: 120 },
    { key: 'order_detail_instruction', label: '▲具体指示', width: 120 },
    { key: 'order_quantity_condition', label: '数量条件指定', width: 121 },
    { key: 'order_note', label: '補足情報', width: 121 },
    { key: 'order_out', label: 'out', width: 78 },
    { key: 'no_1688_shop', label: '1688ショップなし', width: 138 },
    { key: 'product_info_synced_at', label: '商品同期', width: 134 },
    { key: 'order_status_synced_at', label: 'オーダー同期', width: 134 },
    { key: 'updated_at', label: '更新日', width: 134 },
  ]
}

// カスタム列の候補は「すべて」ビューの全列
function getCustomColumnCandidateSpecs(): ColumnSpec[] {
  return getAllViewColumnSpecs()
}

function normalizeCustomColumnKeys(value: unknown): string[] {
  if (!Array.isArray(value)) {
    return DEFAULT_CUSTOM_COLUMN_KEYS
  }

  const validKeys = new Set(getCustomColumnCandidateSpecs().map((column) => column.key))
  return value.filter((key): key is string => typeof key === 'string' && validKeys.has(key))
}

// 操作列は編集モード中（保存/元に戻す）と、発注用ビュー（レシピ）のときだけ表示する
function shouldShowActionsColumn(tableView: TableView, isEditMode: boolean) {
  return isEditMode || tableView === 'purchase'
}

function getViewColumnSpecs(
  tableView: TableView,
  isEditMode = false,
  customColumnKeys: string[] = DEFAULT_CUSTOM_COLUMN_KEYS,
): ColumnSpec[] {
  const baseColumns: ColumnSpec[] = [
    { key: 'image', label: '画像', width: 72, className: 'image-cell sticky-image-cell' },
    { key: 'product_code', label: '商品コード', width: 240, className: 'sticky-code-cell' },
  ]
  const actionColumn: ColumnSpec = isEditMode
    ? { key: 'actions_recipe', label: '操作', width: 238, className: 'sticky-actions-cell' }
    : { key: 'actions_recipe_view', label: '操作', width: 104, className: 'sticky-actions-cell' }
  const showActions = shouldShowActionsColumn(tableView, isEditMode)
  const neColumns = getNeColumnSpecs()
  const customColumnKeySet = new Set(customColumnKeys)

  const viewColumns: Record<TableView, ColumnSpec[]> = {
    all: getAllViewColumnSpecs(),
    pick: [
      { key: 'product_name', label: '商品名', width: 219 },
      { key: 'special_notes', label: '2行目', width: 171 },
      { key: 'picking_advice', label: '3行目', width: 175 },
      { key: 'delivery_line_4', label: '4行目', width: 175 },
      { key: 'floor', label: '階数', width: 87 },
      { key: 'rack_number', label: '棚番号-位置', width: 126 },
      { key: 'rack_level', label: '棚番号-段', width: 114 },
      { key: 'sticker_color', label: 'シールカラー', width: 116 },
      { key: 'shipping_floor', label: '配送-階-特記', width: 138 },
      { key: 'paper_sort_sub', label: 'サブ商品', width: 104 },
      { key: 'delivery_preview', label: '納品書プレビュー', width: 120 },
    ],
    order: [
      { key: 'product_name', label: '商品名', width: 219 },
      { key: 'order_memo_1', label: 'オーダー1', width: 145 },
      { key: 'order_memo_2', label: 'オーダー2', width: 145 },
      { key: 'order_memo_3', label: 'オーダー3', width: 145 },
      { key: 'order_memo_4', label: 'オーダー4', width: 145 },
      { key: 'order_memo_5', label: 'オーダー5', width: 145 },
    ],
    purchase: [
      { key: 'product_name', label: '商品名', width: 219 },
      { key: 'order_url_1', label: '発注URL1', width: 113 },
      { key: 'order_url_2', label: '発注URL2', width: 113 },
      { key: 'order_url_3', label: '発注URL3', width: 113 },
      { key: 'order_size', label: 'サイズ', width: 110 },
      { key: 'order_color', label: 'カラー', width: 110 },
      { key: 'order_simple_instruction', label: '■簡潔指示', width: 120 },
      { key: 'order_detail_instruction', label: '▲具体指示', width: 120 },
      { key: 'order_quantity_condition', label: '数量条件指定', width: 121 },
      // 発注除外フラグは「補足情報」の直後にだけ表示する。
      { key: 'order_note', label: '補足情報', width: 121 },
      { key: 'order_out', label: 'out', width: 78 },
      { key: 'no_1688_shop', label: '1688ショップなし', width: 138 },
    ],
    ne: [
      { key: 'product_name', label: '商品名', width: 219 },
      { key: 'shipping_floor', label: '配送-階-特記', width: 138 },
      ...neColumns,
    ],
    custom: getCustomColumnCandidateSpecs().filter((column) => customColumnKeySet.has(column.key)),
  }

  return showActions
    ? [...baseColumns, ...viewColumns[tableView], actionColumn]
    : [...baseColumns, ...viewColumns[tableView]]
}

const VIEW_LABELS: Record<TableView, string> = {
  order: 'オーダー状況',
  purchase: 'オーダー用',
  pick: '紙出し用',
  ne: 'NE情報',
  custom: 'カスタム',
  all: 'すべて',
}

function ViewButton({
  active,
  children,
  onClick,
}: {
  active: boolean
  children: string
  onClick: () => void
}) {
  return (
    <button
      type="button"
      className={active ? 'view-button active' : 'view-button'}
      onClick={onClick}
    >
      {children}
    </button>
  )
}

function App() {
  const [user, setUser] = useState<SessionUser | null>(null)
  const [secretAnswer, setSecretAnswer] = useState('')
  const [authQuestion, setAuthQuestion] = useState(DEFAULT_AUTH_QUESTION)
  const [authDisplayName, setAuthDisplayName] = useState('秘密の質問ログイン')

  const [products, setProducts] = useState<Product[]>([])
  const [rowDrafts, setRowDrafts] = useState<Record<string, EditableProduct>>({})
  const [editingCodes, setEditingCodes] = useState<Set<string>>(() => new Set())
  const [keyword, setKeyword] = useState('')
  const [debouncedKeyword, setDebouncedKeyword] = useState('')
  const [suffixKeyword, setSuffixKeyword] = useState('')
  const [debouncedSuffixKeyword, setDebouncedSuffixKeyword] = useState('')
  const [isEditMode, setIsEditMode] = useState(false)
  const [bulkColumnEdit, setBulkColumnEdit] = useState<BulkColumnEditState | null>(null)
  const [tableView, setTableView] = useState<TableView>('order')
  const [currentPage, setCurrentPage] = useState(1)
  const [sortConfig, setSortConfig] = useState<SortConfig>(null)
  const [columnWidths, setColumnWidths] = useState<ColumnWidthMap>(() =>
    safeParseColumnWidths(window.localStorage.getItem(COLUMN_WIDTH_STORAGE_KEY)),
  )
  const [recommendedColumnWidthsByView, setRecommendedColumnWidthsByView] =
    useState<RecommendedColumnWidthsByView>({})
  const [sharedColumnWidthsLoading, setSharedColumnWidthsLoading] = useState(false)
  const [sharedColumnWidthsSaving, setSharedColumnWidthsSaving] = useState(false)
  const [sharedColumnWidthsDirty, setSharedColumnWidthsDirty] = useState(false)
  const [recommendedColumnWidthInputs, setRecommendedColumnWidthInputs] = useState<Record<string, string>>({})

  const [loading, setLoading] = useState(false)
  const [savingCode, setSavingCode] = useState<string | null>(null)
  const [message, setMessage] = useState('')

  const [neSyncLoading, setNeSyncLoading] = useState(false)
  const [neSyncMessage, setNeSyncMessage] = useState('')
  const [neUsage, setNeUsage] = useState<NeUsageResult | null>(null)
  const [neSyncResult, setNeSyncResult] = useState<NeOperationalSyncResult | null>(null)
  const [neMonthlyResult, setNeMonthlyResult] = useState<NeMonthlySalesSyncResult | null>(null)
  const [neSyncFields, setNeSyncFields] = useState<NeSyncFieldState>(() =>
    safeParseJson<NeSyncFieldState>(
      window.localStorage.getItem(NE_SYNC_FIELDS_STORAGE_KEY),
      DEFAULT_NE_SYNC_FIELDS,
    ),
  )
  const [selectedNeMonths, setSelectedNeMonths] = useState<string[]>(() => {
    const monthOptions = buildSelectableNeMonths(24)
    const storedMonths = safeParseJson<string[]>(window.localStorage.getItem(NE_SYNC_MONTHS_STORAGE_KEY), [])
      .filter((month) => monthOptions.includes(month))

    return storedMonths.length ? storedMonths : monthOptions.slice(-1)
  })
  const [isNeSyncPanelOpen, setIsNeSyncPanelOpen] = useState(false)
  const [isColumnWidthMenuOpen, setIsColumnWidthMenuOpen] = useState(false)
  const [columnSettingsTab, setColumnSettingsTab] = useState<'width' | 'custom'>('width')
  const [customColumnKeys, setCustomColumnKeys] = useState<string[]>(() =>
    normalizeCustomColumnKeys(
      safeParseJson<unknown>(window.localStorage.getItem(CUSTOM_COLUMNS_STORAGE_KEY), DEFAULT_CUSTOM_COLUMN_KEYS),
    ),
  )

  useEffect(() => {
    try {
      window.localStorage.setItem(CUSTOM_COLUMNS_STORAGE_KEY, JSON.stringify(customColumnKeys))
    } catch {
      // 保存できない環境（プライベートモード等）では、このセッション中だけ有効
    }
  }, [customColumnKeys])
  const columnWidthMenuRef = useRef<HTMLDivElement | null>(null)
  const columnWidthMenuButtonRef = useRef<HTMLButtonElement | null>(null)

  // 推奨幅の設定：メニューの外側をダブルクリックしたら閉じる
  // （背景で覆うと開いたまま列幅を調整できなくなるため、画面は操作可能なまま）
  useEffect(() => {
    if (!isColumnWidthMenuOpen) {
      return
    }

    function handleDocumentDoubleClick(event: MouseEvent) {
      const target = event.target as Node | null

      if (
        target &&
        (columnWidthMenuRef.current?.contains(target) ||
          columnWidthMenuButtonRef.current?.contains(target))
      ) {
        return
      }

      setIsColumnWidthMenuOpen(false)
    }

    document.addEventListener('dblclick', handleDocumentDoubleClick)
    return () => document.removeEventListener('dblclick', handleDocumentDoubleClick)
  }, [isColumnWidthMenuOpen])

  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false)
  const [bulkRows, setBulkRows] = useState<BulkProductRow[]>(() =>
    createBulkRows(),
  )
  const [bulkImageDrafts, setBulkImageDrafts] = useState<Record<string, ProductImageDraft>>({})
  const bulkImageDraftsRef = useRef<Record<string, ProductImageDraft>>({})
  const [bulkShouldUpdateExisting, setBulkShouldUpdateExisting] = useState(false)
  const [bulkUpdateOnly, setBulkUpdateOnly] = useState(false)
  const [selectedBulkFields, setSelectedBulkFields] = useState<BulkFieldKey[]>(
    DEFAULT_BULK_FIELD_KEYS,
  )
  const [csvColumnMapping, setCsvColumnMapping] = useState<CsvColumnMapping | null>(null)
  const [isCsvDragOver, setIsCsvDragOver] = useState(false)
  const [isBulkFieldPanelOpen, setIsBulkFieldPanelOpen] = useState(false)
  const [modalMessage, setModalMessage] = useState('')

  const [isImageImportModalOpen, setIsImageImportModalOpen] = useState(false)
  const [imageFiles, setImageFiles] = useState<File[]>([])
  const [isImageDragOver, setIsImageDragOver] = useState(false)
  const [imageImporting, setImageImporting] = useState(false)
  const [imageImportMessage, setImageImportMessage] = useState('')
  const [imageCacheVersion, setImageCacheVersion] = useState(() => Date.now())
  const [imagePreview, setImagePreview] = useState<ProductImagePreview | null>(null)
  const [deliverySlipPreview, setDeliverySlipPreview] = useState<DeliverySlipPreviewData | null>(null)
  const [rakumartRecipeModal, setRakumartRecipeModal] = useState<RakumartRecipeModalState | null>(null)
  const [rakumartRecipeLoading, setRakumartRecipeLoading] = useState(false)
  const [rakumartRecipeSaving, setRakumartRecipeSaving] = useState(false)
  const [rakumartRecipeMessage, setRakumartRecipeMessage] = useState('')
  const [imageDrafts, setImageDrafts] = useState<Record<string, ProductImageDraft>>({})
  const imageDraftsRef = useRef<Record<string, ProductImageDraft>>({})

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      setUser(data.session?.user ?? null)
    })

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user ?? null)
    })

    return () => subscription.unsubscribe()
  }, [])

  useEffect(() => {
    imageDraftsRef.current = imageDrafts
  }, [imageDrafts])

  useEffect(() => {
    bulkImageDraftsRef.current = bulkImageDrafts
  }, [bulkImageDrafts])

  useEffect(() => () => {
    Object.values(imageDraftsRef.current).forEach((draft) => {
      URL.revokeObjectURL(draft.previewUrl)
    })
    Object.values(bulkImageDraftsRef.current).forEach((draft) => {
      URL.revokeObjectURL(draft.previewUrl)
    })
  }, [])

  useEffect(() => {
    let isMounted = true

    async function fetchAuthQuestion() {
      if (!AUTH_API_BASE_URL) {
        setAuthQuestion(DEFAULT_AUTH_QUESTION)
        return
      }

      try {
        const response = await fetch(`${AUTH_API_BASE_URL}/api/auth/question`, {
          method: 'GET',
          cache: 'no-store',
        })
        const payload = (await response.json().catch(() => ({}))) as SecretQuestionResponse
        if (!isMounted) return
        if (response.ok && payload.ok) {
          setAuthQuestion(payload.question || DEFAULT_AUTH_QUESTION)
          setAuthDisplayName(payload.displayName || '秘密の質問ログイン')
        }
      } catch {
        if (isMounted) setAuthQuestion(DEFAULT_AUTH_QUESTION)
      }
    }

    fetchAuthQuestion()

    return () => {
      isMounted = false
    }
  }, [])

  useEffect(() => {
    if (user) {
      fetchProducts()
    }
  }, [user])

  useEffect(() => {
    if (!user || !message) {
      return
    }

    const timer = window.setTimeout(() => {
      setMessage('')
    }, 3200)

    return () => window.clearTimeout(timer)
  }, [message, user])

  useEffect(() => {
    window.localStorage.setItem(COLUMN_WIDTH_STORAGE_KEY, JSON.stringify(columnWidths))
  }, [columnWidths])

  useEffect(() => {
    if (!user || !isColumnWidthMenuOpen) {
      return
    }

    let isActive = true

    async function fetchSharedColumnWidths() {
      setSharedColumnWidthsLoading(true)

      const { data, error } = await supabase
        .from(APP_SETTINGS_TABLE)
        .select('setting_value')
        .eq('setting_key', getColumnWidthSettingKey(tableView))
        .maybeSingle()

      if (!isActive) {
        return
      }

      if (error) {
        setSharedColumnWidthsLoading(false)
        setMessage(`共有推奨幅の取得失敗: ${error.message}`)
        return
      }

      setRecommendedColumnWidthsByView((prev) => ({
        ...prev,
        [tableView]: normalizeColumnWidths(data?.setting_value),
      }))
      setRecommendedColumnWidthInputs({})
      setSharedColumnWidthsDirty(false)
      setSharedColumnWidthsLoading(false)
    }

    fetchSharedColumnWidths()

    return () => {
      isActive = false
    }
  }, [isColumnWidthMenuOpen, tableView, user])

  useEffect(() => {
    window.localStorage.setItem(NE_SYNC_FIELDS_STORAGE_KEY, JSON.stringify(neSyncFields))
  }, [neSyncFields])


  const neMonthOptions = useMemo(() => buildSelectableNeMonths(24), [])
  const neMonthGroups = useMemo(() => groupYearMonths(neMonthOptions), [neMonthOptions])

  useEffect(() => {
    const validSelectedMonths = selectedNeMonths.filter((month) => neMonthOptions.includes(month))
    if (validSelectedMonths.length !== selectedNeMonths.length) {
      setSelectedNeMonths(validSelectedMonths.length ? validSelectedMonths : neMonthOptions.slice(-1))
      return
    }

    window.localStorage.setItem(NE_SYNC_MONTHS_STORAGE_KEY, JSON.stringify(validSelectedMonths))
  }, [neMonthOptions, selectedNeMonths])


  useEffect(() => {
    const timer = window.setTimeout(() => {
      setDebouncedKeyword(keyword)
      setDebouncedSuffixKeyword(suffixKeyword)
    }, 220)

    return () => window.clearTimeout(timer)
  }, [keyword, suffixKeyword])

  useEffect(() => {
    setCurrentPage(1)
  }, [debouncedKeyword, debouncedSuffixKeyword, tableView, sortConfig])

  useEffect(() => {
    setRowDrafts((prev) => {
      const nextDrafts: Record<string, EditableProduct> = {}

      products.forEach((product) => {
        nextDrafts[product.product_code] =
          editingCodes.has(product.product_code) && prev[product.product_code]
            ? prev[product.product_code]
            : productToDraft(product)
      })

      return nextDrafts
    })
  }, [products, editingCodes])

  const existingProductCodes = useMemo(() => {
    return new Set(products.map((product) => product.product_code))
  }, [products])

  const productCodeLookup = useMemo(() => {
    return new Map(
      products.map((product) => [product.product_code.toLowerCase(), product.product_code]),
    )
  }, [products])

  const productByCode = useMemo(() => {
    return new Map(products.map((product) => [product.product_code, product]))
  }, [products])

  const productSearchTextByCode = useMemo(() => {
    return new Map(
      products.map((product) => [product.product_code, buildProductSearchText(product)]),
    )
  }, [products])

  const bulkSummary = useMemo(() => {
    return buildBulkSummary(bulkRows, existingProductCodes)
  }, [bulkRows, existingProductCodes])

  const selectedBulkColumns = useMemo(() => {
    return BULK_FIELD_COLUMNS.filter((column) =>
      selectedBulkFields.includes(column.key),
    )
  }, [selectedBulkFields])

  const bulkImageDraftCount = Object.keys(bulkImageDrafts).length


  const bulkInsertableCount = bulkSummary.insertRows.length
  const bulkUpdateableCount = bulkSummary.updateRows.length
  const bulkExistingCount = bulkSummary.existingCount
  const bulkActionableCount = bulkUpdateOnly
    ? bulkUpdateableCount
    : bulkShouldUpdateExisting
      ? bulkSummary.uniqueRows.length
      : bulkInsertableCount

  const filteredProducts = useMemo(() => {
    // 左：全項目の部分一致検索
    // 右：商品コードと商品名だけの部分一致で、左の結果をさらに絞り込む（AND条件）
    //     ※ 全項目を対象にすると「20」が在庫数などにも当たって絞り込めないため
    const q = debouncedKeyword.trim().toLowerCase()
    const narrowQuery = debouncedSuffixKeyword.trim().toLowerCase()

    if (!q && !narrowQuery) {
      return products
    }

    return products.filter((product) => {
      if (q && !(productSearchTextByCode.get(product.product_code) ?? '').includes(q)) {
        return false
      }

      if (
        narrowQuery &&
        !product.product_code.toLowerCase().includes(narrowQuery) &&
        !(product.product_name ?? '').toLowerCase().includes(narrowQuery)
      ) {
        return false
      }

      return true
    })
  }, [products, productSearchTextByCode, debouncedKeyword, debouncedSuffixKeyword])

  const filteredSelectedCount = useMemo(() => {
    if (editingCodes.size === 0) {
      return 0
    }

    return filteredProducts.reduce(
      (count, product) => count + (editingCodes.has(product.product_code) ? 1 : 0),
      0,
    )
  }, [filteredProducts, editingCodes])

  const allFilteredSelected =
    filteredProducts.length > 0 && filteredSelectedCount === filteredProducts.length
  const someFilteredSelected = filteredSelectedCount > 0 && !allFilteredSelected



  const sortedProducts = useMemo(() => {
    if (!sortConfig) {
      return filteredProducts
    }

    return [...filteredProducts].sort((productA, productB) =>
      compareProductsBySort(productA, productB, sortConfig),
    )
  }, [filteredProducts, sortConfig])

  const totalProductCount = sortedProducts.length
  const totalPages = Math.max(1, Math.ceil(totalProductCount / PRODUCT_PAGE_SIZE))
  const currentPageNumber = Math.min(currentPage, totalPages)
  const pageStartIndex = (currentPageNumber - 1) * PRODUCT_PAGE_SIZE
  const pageEndIndex = Math.min(pageStartIndex + PRODUCT_PAGE_SIZE, totalProductCount)
  const pagerRangeText =
    totalProductCount === 0
      ? '0件 / 全0件'
      : `${pageStartIndex + 1}〜${pageEndIndex}件目 / 全${totalProductCount}件`

  const pagedProducts = useMemo(() => {
    return sortedProducts.slice(pageStartIndex, pageEndIndex)
  }, [sortedProducts, pageStartIndex, pageEndIndex])

  useEffect(() => {
    if (currentPage > totalPages) {
      setCurrentPage(totalPages)
    }
  }, [currentPage, totalPages])

  async function login() {
    setLoading(true)
    setMessage('')

    if (!AUTH_API_BASE_URL) {
      setMessage('ログインAPIが未設定です。VITE_AUTH_API_BASE_URLを設定してください。')
      setLoading(false)
      return
    }

    if (!secretAnswer.trim()) {
      setMessage('回答を入力してください。')
      setLoading(false)
      return
    }

    try {
      const response = await fetch(`${AUTH_API_BASE_URL}/api/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ answer: secretAnswer.trim() }),
      })
      const payload = (await response.json().catch(() => ({}))) as SecretLoginResponse

      if (!response.ok || !payload.ok || !payload.session?.access_token || !payload.session.refresh_token) {
        throw new Error(payload.error || 'ログインに失敗しました。')
      }

      const { error } = await supabase.auth.setSession({
        access_token: payload.session.access_token,
        refresh_token: payload.session.refresh_token,
      })

      if (error) throw error

      setSecretAnswer('')
      setUser({ email: payload.email || payload.user?.email || authDisplayName })
    } catch (error) {
      setMessage(`ログイン失敗: ${error instanceof Error ? error.message : 'ログインに失敗しました。'}`)
    } finally {
      setLoading(false)
    }
  }

  async function logout() {
    await supabase.auth.signOut()
    setProducts([])
    setRowDrafts({})
    setEditingCodes(new Set())
    setIsEditMode(false)
    setBulkColumnEdit(null)
    setUser(null)
  }

  async function fetchProducts() {
    setLoading(true)
    setMessage('')

    const allProducts: Product[] = []
    let from = 0

    while (true) {
      const to = from + PRODUCT_FETCH_BATCH_SIZE - 1
      const { data, error } = await supabase
        .from('products')
        .select('*')
        .order('product_code', { ascending: true })
        .range(from, to)

      if (error) {
        setMessage(`取得失敗: ${error.message}`)
        setLoading(false)
        return
      }

      const batch = (data ?? []) as Product[]
      allProducts.push(...batch)

      if (batch.length < PRODUCT_FETCH_BATCH_SIZE) {
        break
      }

      from += PRODUCT_FETCH_BATCH_SIZE
    }

    setProducts(allProducts)
    setCurrentPage(1)
    setLoading(false)
  }

  async function callNeWorker<T>(path: string, params: Record<string, string> = {}) {
    const { data: sessionData, error: sessionError } = await supabase.auth.getSession()
    const accessToken = sessionData.session?.access_token

    if (sessionError || !accessToken) {
      throw new Error('ログインセッションが切れています。再ログインしてください。')
    }

    const url = new URL(path, NE_SYNC_WORKER_URL)
    Object.entries(params).forEach(([key, value]) => {
      if (value) {
        url.searchParams.set(key, value)
      }
    })

    const response = await fetch(url.toString(), {
      method: 'GET',
      headers: { Authorization: `Bearer ${accessToken}` },
    })

    const data = (await response.json().catch(() => null)) as T | null

    if (!response.ok || !data) {
      const detail = data && typeof data === 'object' && 'error' in data ? String((data as { error?: unknown }).error ?? '') : response.statusText
      throw new Error(detail || `NE連携Workerでエラーが発生しました。status=${response.status}`)
    }

    return data
  }

  async function fetchNeUsage() {
    setNeSyncLoading(true)
    setNeSyncMessage('NE API利用状況を取得しています...')

    try {
      const usage = await callNeWorker<NeUsageResult>('/api/ne/usage')
      setNeUsage(usage)
      setNeSyncMessage(`今月のNE API利用回数：${usage.callCount ?? 0}回 / 残り${usage.remainingCalls ?? '-'}回`)
    } catch (error) {
      setNeSyncMessage(`利用状況取得失敗：${error instanceof Error ? error.message : String(error)}`)
    } finally {
      setNeSyncLoading(false)
    }
  }

  function updateNeSyncField(key: keyof NeSyncFieldState, checked: boolean) {
    setNeSyncFields((current) => ({ ...current, [key]: checked }))
  }

  function toggleNeSyncMonth(key: string, checked: boolean) {
    setSelectedNeMonths((current) => {
      const next = checked ? Array.from(new Set([...current, key])) : current.filter((month) => month !== key)
      return next.sort()
    })
  }

  function selectRecentNeMonths(count: number) {
    setSelectedNeMonths(neMonthOptions.slice(Math.max(0, neMonthOptions.length - count)))
    setNeSyncFields((current) => ({ ...current, monthlySales: true }))
  }

  async function syncNeOperationalFields(dryRun: boolean) {
    const operationalFields = selectedNeOperationalFieldKeys(neSyncFields)
    const shouldSyncOperational = operationalFields.length > 0
    const shouldSyncMonthly = neSyncFields.monthlySales

    if (!shouldSyncOperational && !shouldSyncMonthly) {
      setNeSyncMessage('取得項目を1つ以上選択してください。')
      return
    }

    if (shouldSyncMonthly && selectedNeMonths.length === 0) {
      setNeSyncMessage('月別受注数を取得する年月を1つ以上選択してください。')
      return
    }

    setNeSyncLoading(true)
    setNeSyncMessage(dryRun ? 'NE取得のdry-runを実行しています...' : 'NEから選択項目を取得してSupabaseへ反映しています...')
    setNeSyncResult(null)
    setNeMonthlyResult(null)

    try {
      let operationalResult: NeOperationalSyncResult | null = null
      let monthlyResult: NeMonthlySalesSyncResult | null = null

      if (shouldSyncOperational) {
        operationalResult = await callNeWorker<NeOperationalSyncResult>('/api/ne/sync-operational-fields', {
          ...(dryRun ? { dryRun: '1' } : {}),
          fields: operationalFields.join(','),
        })
        setNeSyncResult(operationalResult)
      }

      if (shouldSyncMonthly) {
        monthlyResult = await callNeWorker<NeMonthlySalesSyncResult>('/api/ne/sync-monthly-sales', {
          ...(dryRun ? { dryRun: '1' } : {}),
          yearMonths: selectedNeMonths.join(','),
        })
        setNeMonthlyResult(monthlyResult)
      }

      const messageParts: string[] = []
      if (operationalResult) {
        messageParts.push(`NE情報：一致 ${operationalResult.matched ?? 0}件 / 更新 ${operationalResult.updated ?? 0}件`)
      }
      if (monthlyResult) {
        messageParts.push(`月別：${monthlyResult.months?.join('・') || '-'} / 一致 ${monthlyResult.matched ?? 0}件 / 更新 ${monthlyResult.updated ?? 0}件`)
      }

      setNeSyncMessage(`${dryRun ? 'dry-run完了' : 'NE取得完了'}：${messageParts.join(' / ')}`)

      if (!dryRun && ((operationalResult && operationalResult.ok) || (monthlyResult && monthlyResult.ok))) {
        await fetchProducts()
      }
    } catch (error) {
      setNeSyncMessage(`NE取得失敗：${error instanceof Error ? error.message : String(error)}`)
    } finally {
      setNeSyncLoading(false)
    }
  }

  async function copyProductCode(productCode: string) {
    try {
      await navigator.clipboard.writeText(productCode)
      setMessage(`商品コードをコピーしました：${productCode}`)
    } catch {
      setMessage('コピーに失敗しました。')
    }
  }

  function clearBulkImageDrafts(rowIds?: string[]) {
    setBulkImageDrafts((prev) => {
      const next = { ...prev }
      const targetRowIds = rowIds ?? Object.keys(next)
      let changed = false

      targetRowIds.forEach((rowId) => {
        const draft = next[rowId]

        if (draft) {
          URL.revokeObjectURL(draft.previewUrl)
          delete next[rowId]
          changed = true
        }
      })

      return changed ? next : prev
    })
  }

  function setBulkRowImageDraft(rowId: string, files: File[]) {
    const imageFile = files.find(isSupportedProductImageFile)

    if (!imageFile) {
      setModalMessage('jpg / png / webp 形式の画像をドロップしてください。')
      return
    }

    const previewUrl = URL.createObjectURL(imageFile)

    setBulkImageDrafts((prev) => {
      const previousDraft = prev[rowId]

      if (previousDraft) {
        URL.revokeObjectURL(previousDraft.previewUrl)
      }

      return {
        ...prev,
        [rowId]: {
          file: imageFile,
          previewUrl,
          sourceName: imageFile.name,
        },
      }
    })

    setModalMessage('画像を保存待ちにしました。商品コード入力後、一括追加/更新で反映します。')
  }

  function handleBulkImageDragOver(event: DragEvent<HTMLDivElement>) {
    event.preventDefault()
    event.stopPropagation()
    event.dataTransfer.dropEffect = 'copy'
    setIsCsvDragOver(false)
  }

  function handleBulkImageDrop(event: DragEvent<HTMLDivElement>, rowId: string) {
    event.preventDefault()
    event.stopPropagation()
    setIsCsvDragOver(false)
    const files = Array.from(event.dataTransfer.files ?? [])

    if (files.length === 0) {
      setModalMessage('画像ファイルをドロップしてください。')
      return
    }

    setBulkRowImageDraft(rowId, files)
  }

  function handleBulkImageFileSelect(event: ChangeEvent<HTMLInputElement>, rowId: string) {
    const files = Array.from(event.currentTarget.files ?? [])
    event.currentTarget.value = ''

    if (files.length > 0) {
      setBulkRowImageDraft(rowId, files)
    }
  }

  function openCreateModal() {
    clearBulkImageDrafts()
    setBulkRows(createBulkRows())
    setBulkShouldUpdateExisting(false)
    setBulkUpdateOnly(false)
    setSelectedBulkFields(DEFAULT_BULK_FIELD_KEYS)
    setCsvColumnMapping(null)
    setIsCsvDragOver(false)
    setIsBulkFieldPanelOpen(false)
    setModalMessage('')
    setIsCreateModalOpen(true)
  }

  function closeCreateModal() {
    setIsCreateModalOpen(false)
    clearBulkImageDrafts()
    setBulkRows(createBulkRows())
    setBulkShouldUpdateExisting(false)
    setBulkUpdateOnly(false)
    setSelectedBulkFields(DEFAULT_BULK_FIELD_KEYS)
    setCsvColumnMapping(null)
    setIsCsvDragOver(false)
    setModalMessage('')
  }


  function openImageImportModal() {
    setImageFiles([])
    setIsImageDragOver(false)
    setImageImportMessage('')
    setIsImageImportModalOpen(true)
  }

  function closeImageImportModal() {
    if (imageImporting) {
      return
    }

    setIsImageImportModalOpen(false)
    setImageFiles([])
    setIsImageDragOver(false)
    setImageImportMessage('')
  }

  function removeImageDrafts(productCodes: string[]) {
    if (productCodes.length === 0) {
      return
    }

    const productCodeSet = new Set(productCodes)

    setImageDrafts((prev) => {
      let changed = false
      const next = { ...prev }

      productCodeSet.forEach((productCode) => {
        const draft = next[productCode]

        if (draft) {
          URL.revokeObjectURL(draft.previewUrl)
          delete next[productCode]
          changed = true
        }
      })

      return changed ? next : prev
    })
  }

  function setRowImageDraft(product: Product, files: File[]) {
    if (!editingCodes.has(product.product_code)) {
      setMessage('画像更新は編集モード中のみ受付できます。')
      return
    }

    const imageFile = files.find(isSupportedProductImageFile)

    if (!imageFile) {
      setMessage('jpg / png / webp 形式の画像をドロップしてください。')
      return
    }

    const previewUrl = URL.createObjectURL(imageFile)

    setImageDrafts((prev) => {
      const previousDraft = prev[product.product_code]

      if (previousDraft) {
        URL.revokeObjectURL(previousDraft.previewUrl)
      }

      return {
        ...prev,
        [product.product_code]: {
          file: imageFile,
          previewUrl,
          sourceName: imageFile.name,
        },
      }
    })

    setMessage(`${product.product_code} の画像を保存待ちにしました。保存で反映します。`)
  }

  function setProductImageFiles(files: File[]) {
    const supportedFiles = files.filter(isSupportedProductImageFile)
    const skippedCount = files.length - supportedFiles.length

    setImageFiles(supportedFiles)

    if (supportedFiles.length === 0) {
      setImageImportMessage('商品コード付きの jpg / png / webp 画像を選択してください。')
      return
    }

    setImageImportMessage(
      skippedCount > 0
        ? `${supportedFiles.length}件の画像を選択しました。非対応ファイルは${skippedCount}件スキップします。保存時はWebPに変換します。`
        : `${supportedFiles.length}件の画像を選択しました。保存時はWebPに変換します。`,
    )
  }

  function handleImageFileSelect(event: ChangeEvent<HTMLInputElement>) {
    const files = Array.from(event.currentTarget.files ?? [])
    event.currentTarget.value = ''

    if (files.length > 0) {
      setProductImageFiles(files)
    }
  }

  function handleImageDragOver(event: DragEvent<HTMLDivElement>) {
    event.preventDefault()
    event.dataTransfer.dropEffect = 'copy'
    setIsImageDragOver(true)
  }

  function handleImageDragLeave(event: DragEvent<HTMLDivElement>) {
    const nextTarget = event.relatedTarget as Node | null

    if (!nextTarget || !event.currentTarget.contains(nextTarget)) {
      setIsImageDragOver(false)
    }
  }

  function handleImageDrop(event: DragEvent<HTMLDivElement>) {
    event.preventDefault()
    setIsImageDragOver(false)

    const files = Array.from(event.dataTransfer.files ?? [])

    if (files.length === 0) {
      setImageImportMessage('商品コード付きの jpg / png / webp 画像をドロップしてください。')
      return
    }

    setProductImageFiles(files)
  }

  async function uploadProductImages() {
    if (imageFiles.length === 0) {
      setImageImportMessage('アップロードする画像を選択してください。')
      return
    }

    setImageImporting(true)
    setImageImportMessage('画像をアップロードしています...')

    let uploadedCount = 0
    let skippedCount = 0
    let failedCount = 0
    const failedNames: string[] = []

    await runWithConcurrency(imageFiles, IMAGE_UPLOAD_CONCURRENCY, async (file) => {
      const rawProductCode = getProductCodeFromImageFile(file)
      const productCode = productCodeLookup.get(rawProductCode.toLowerCase())

      if (!productCode) {
        skippedCount += 1
        return
      }

      try {
        await uploadProductImageFile(productCode, file)
        uploadedCount += 1
      } catch {
        failedCount += 1
        failedNames.push(file.name)
      }
    })

    setImageImporting(false)
    setImageCacheVersion(Date.now())

    const resultMessage = `画像アップロード完了：${uploadedCount}件 / 未登録スキップ：${skippedCount}件 / 失敗：${failedCount}件`
    setImageImportMessage(
      failedNames.length > 0
        ? `${resultMessage}（例：${failedNames.slice(0, 3).join('、')}）`
        : resultMessage,
    )
    setMessage(resultMessage)
  }

  function toggleBulkField(fieldKey: BulkFieldKey) {
    setSelectedBulkFields((prev) => {
      if (prev.includes(fieldKey)) {
        return prev.length > 1 ? prev.filter((key) => key !== fieldKey) : prev
      }

      return BULK_FIELD_COLUMNS.filter(
        (column) => column.key === fieldKey || prev.includes(column.key),
      ).map((column) => column.key)
    })
  }

  function updateBulkRow(
    rowId: string,
    key: keyof Omit<BulkProductRow, 'id'>,
    value: string | boolean,
  ) {
    setBulkRows((prev) =>
      prev.map((row) =>
        row.id === rowId
          ? {
              ...row,
              [key]: value,
            }
          : row,
      ),
    )
  }

  function addBulkRows(count = 5) {
    setBulkRows((prev) => [...prev, ...createBulkRows(count)])
  }

  function removeBulkRow(rowId: string) {
    clearBulkImageDrafts([rowId])
    setBulkRows((prev) => {
      const next = prev.filter((row) => row.id !== rowId)
      return next.length > 0 ? next : createBulkRows(1)
    })
  }

  function clearBulkRows() {
    clearBulkImageDrafts()
    setBulkRows(createBulkRows())
    setCsvColumnMapping(null)
    setModalMessage('')
  }

  function handleBulkPaste(
    event: ClipboardEvent<HTMLInputElement>,
    startIndex: number,
  ) {
    const text = event.clipboardData.getData('text')

    if (!text.includes('\n') && !text.includes('\t')) {
      return
    }

    const pastedRows = parseClipboardRows(text, selectedBulkFields)

    if (pastedRows.length === 0) {
      return
    }

    event.preventDefault()

    setBulkRows((prev) => {
      const next = [...prev]
      const requiredLength = startIndex + pastedRows.length

      while (next.length < requiredLength) {
        next.push(createBulkRow())
      }

      pastedRows.forEach((pastedRow, offset) => {
        const targetIndex = startIndex + offset

        next[targetIndex] = {
          ...next[targetIndex],
          product_code: pastedRow.product_code,
        }

        selectedBulkFields.forEach((key) => {
          if (isBulkBooleanField(key)) {
            next[targetIndex][key] = Boolean(pastedRow[key])
          } else {
            next[targetIndex][key] = pastedRow[key]
          }
        })
      })

      return next
    })
  }


  function applyCsvImportResult(result: CsvImportResult, filename: string) {
    const blankRows = createBulkRows(3)

    clearBulkImageDrafts()
    setSelectedBulkFields(result.fields)
    setBulkRows([...result.rows.map(cleanRowToBulkRow), ...blankRows])
    setCsvColumnMapping(null)
    setModalMessage(
      `${filename} を読み込みました。対象列：${result.fields
        .map(getBulkFieldLabel)
        .join('・')}`,
    )
  }

  async function importCsvFile(file: File) {
    try {
      const buffer = await file.arrayBuffer()
      const text = decodeCsvBuffer(buffer)
      const mapping = createCsvColumnMapping(text, file.name)
      if (csvMappingNeedsManualCheck(mapping)) {
        setCsvColumnMapping(mapping)
        setModalMessage(getCsvMappingMessage(mapping))
        return
      }

      applyCsvImportResult(
        buildCsvImportResult(
          mapping.dataRows,
          mapping.productCodeIndex,
          mapping.fieldIndexes,
        ),
        file.name,
      )
    } catch (error) {
      setCsvColumnMapping(null)
      setModalMessage(
        error instanceof Error
          ? `CSV読み込み失敗: ${error.message}`
          : 'CSV読み込みに失敗しました。',
      )
    }
  }

  async function handleBulkCsvImport(event: ChangeEvent<HTMLInputElement>) {
    const file = event.currentTarget.files?.[0]
    event.currentTarget.value = ''

    if (!file) {
      return
    }

    await importCsvFile(file)
  }

  function handleCsvDragOver(event: DragEvent<HTMLDivElement>) {
    event.preventDefault()
    event.dataTransfer.dropEffect = 'copy'
    setIsCsvDragOver(true)
  }

  function handleCsvDragLeave(event: DragEvent<HTMLDivElement>) {
    const nextTarget = event.relatedTarget as Node | null

    if (!nextTarget || !event.currentTarget.contains(nextTarget)) {
      setIsCsvDragOver(false)
    }
  }

  async function handleCsvDrop(event: DragEvent<HTMLDivElement>) {
    event.preventDefault()
    setIsCsvDragOver(false)

    const droppedFiles = Array.from(event.dataTransfer.files)
    const csvFile = droppedFiles.find(
      (file) =>
        file.name.toLowerCase().endsWith('.csv') ||
        file.type.includes('csv') ||
        file.type === 'text/plain',
    )

    if (!csvFile) {
      setModalMessage(
        droppedFiles.some(isSupportedProductImageFile)
          ? '画像は各行の「画像」欄にドロップしてください。'
          : 'CSVファイルをドロップしてください。',
      )
      return
    }

    await importCsvFile(csvFile)
  }

  function setBulkMode(mode: BulkMode) {
    setBulkUpdateOnly(mode === 'update')
    setBulkShouldUpdateExisting(mode === 'upsert')
  }

  function updateCsvSourceColumnMapping(columnIndex: number, value: string) {
    const key = value as CsvMappingKey | ''

    setCsvColumnMapping((prev) => {
      if (!prev) {
        return prev
      }

      const nextFieldIndexes = { ...prev.fieldIndexes }

      BULK_FIELD_COLUMNS.forEach((column) => {
        if (nextFieldIndexes[column.key] === columnIndex || column.key === key) {
          delete nextFieldIndexes[column.key]
        }
      })

      const next: CsvColumnMapping = {
        ...prev,
        productCodeIndex:
          prev.productCodeIndex === columnIndex || key === 'product_code'
            ? null
            : prev.productCodeIndex,
        fieldIndexes: nextFieldIndexes,
      }

      if (key === 'product_code') {
        next.productCodeIndex = columnIndex
      } else if (key) {
        next.fieldIndexes[key] = columnIndex
      }

      return next
    })
  }

  function applyManualCsvMapping() {
    if (!csvColumnMapping) {
      return
    }

    try {
      const result = buildCsvImportResult(
        csvColumnMapping.dataRows,
        csvColumnMapping.productCodeIndex,
        csvColumnMapping.fieldIndexes,
      )

      applyCsvImportResult(result, csvColumnMapping.filename)
    } catch (error) {
      setModalMessage(
        error instanceof Error
          ? `CSV列割り当て失敗: ${error.message}`
          : 'CSV列割り当てに失敗しました。',
      )
    }
  }



  function startEdit(product: Product) {
    // 行のダブルクリック / 編集ボタン：編集モードに入り、その行を編集可能にする
    setIsEditMode(true)
    setEditingCodes((prev) => {
      if (prev.has(product.product_code)) {
        return prev
      }

      const next = new Set(prev)
      next.add(product.product_code)
      return next
    })
    setRowDrafts((prev) => ({
      ...prev,
      [product.product_code]: prev[product.product_code] ?? productToDraft(product),
    }))
    setMessage('')
  }

  function enterEditMode() {
    setIsEditMode(true)
    setMessage('編集モードにしました。左端のチェックで編集する商品を選んでください。')
  }

  function startBulkEdit() {
    if (filteredProducts.length === 0 || savingCode) {
      return
    }

    setIsEditMode(true)
    setRowsSelected(filteredProducts, true)
    setMessage(`検索結果の${filteredProducts.length}件を選択して編集モードにしました。`)
  }

  function getDirtyCodes(codes: Iterable<string>) {
    const dirtyCodes: string[] = []

    for (const code of codes) {
      const product = productByCode.get(code)

      if (product && hasRowChanges(product, rowDrafts[code] ?? productToDraft(product))) {
        dirtyCodes.push(code)
      }
    }

    return dirtyCodes
  }

  function resetRowDrafts(codes: string[]) {
    if (codes.length === 0) {
      return
    }

    removeImageDrafts(codes)
    setRowDrafts((prev) => {
      const next = { ...prev }

      codes.forEach((code) => {
        const product = productByCode.get(code)

        if (product) {
          next[code] = productToDraft(product)
        }
      })

      return next
    })
  }

  function endEditMode() {
    if (savingCode) {
      return
    }

    const dirtyCodes = getDirtyCodes(editingCodes)

    if (
      dirtyCodes.length > 0 &&
      !window.confirm(`未保存の変更が${dirtyCodes.length}件あります。破棄して編集モードを終了しますか？`)
    ) {
      return
    }

    resetRowDrafts(Array.from(editingCodes))
    setEditingCodes(new Set())
    setIsEditMode(false)
    setBulkColumnEdit(null)
    setMessage(
      dirtyCodes.length > 0
        ? `編集モードを終了しました。未保存の変更${dirtyCodes.length}件を破棄しました。`
        : '編集モードを終了しました。',
    )
  }

  function setRowsSelected(targetProducts: Product[], selected: boolean) {
    if (targetProducts.length === 0 || savingCode) {
      return
    }

    if (selected) {
      setEditingCodes((prev) => {
        const next = new Set(prev)
        targetProducts.forEach((product) => next.add(product.product_code))
        return next
      })
      setRowDrafts((prev) => {
        const next = { ...prev }

        targetProducts.forEach((product) => {
          next[product.product_code] = next[product.product_code] ?? productToDraft(product)
        })

        return next
      })
      return
    }

    const targetCodes = targetProducts
      .map((product) => product.product_code)
      .filter((code) => editingCodes.has(code))
    const dirtyCodes = getDirtyCodes(targetCodes)

    if (
      dirtyCodes.length > 0 &&
      !window.confirm(`未保存の変更が${dirtyCodes.length}件あります。チェックを外すと変更は破棄されます。よろしいですか？`)
    ) {
      return
    }

    resetRowDrafts(targetCodes)
    setEditingCodes((prev) => {
      const next = new Set(prev)
      targetCodes.forEach((code) => next.delete(code))
      return next
    })
  }

  function toggleAllFilteredSelection() {
    setRowsSelected(filteredProducts, !allFilteredSelected)
  }

  function openBulkColumnEdit(config: BulkColumnEditConfig) {
    if (editingCodes.size === 0) {
      setMessage('一括入力するには、先に商品にチェックを入れてください。')
      return
    }

    setBulkColumnEdit({
      config,
      value: '',
      boolValue: true,
      urlValue: '',
      applyMain: true,
      applyUrl: false,
    })
  }

  function applyBulkColumnEdit() {
    if (!bulkColumnEdit) {
      return
    }

    const { config, value, boolValue, urlValue, applyMain, applyUrl } = bulkColumnEdit
    const shouldApplyUrl = config.kind === 'order_memo' && applyUrl && Boolean(config.urlKey)
    const shouldApplyMain = config.kind !== 'order_memo' || applyMain

    if (!shouldApplyMain && !shouldApplyUrl) {
      return
    }

    const targetCodes = Array.from(editingCodes).filter((code) => productByCode.has(code))

    setRowDrafts((prev) => {
      const next = { ...prev }

      targetCodes.forEach((code) => {
        const product = productByCode.get(code)

        if (!product) {
          return
        }

        const draft: EditableProduct = { ...(next[code] ?? productToDraft(product)) }
        const mutableDraft = draft as Record<EditableProductKey, string | boolean>

        if (shouldApplyMain) {
          mutableDraft[config.key] = config.kind === 'boolean' ? boolValue : value
        }

        if (shouldApplyUrl && config.urlKey) {
          mutableDraft[config.urlKey] = urlValue
        }

        next[code] = draft
      })

      return next
    })

    setBulkColumnEdit(null)
    setMessage(`${targetCodes.length}件の「${config.label}」に一括入力しました。保存するまで確定されません。`)
  }

  function updateDraft(
    productCode: string,
    key: EditableProductKey,
    value: string | boolean,
  ) {
    const product = productByCode.get(productCode)

    if (!product) {
      return
    }

    setRowDrafts((prev) => ({
      ...prev,
      [productCode]: {
        ...(prev[productCode] ?? productToDraft(product)),
        [key]: value,
      },
    }))
  }

  function hasRowChanges(product: Product, draft: EditableProduct) {
    return isDraftDirty(product, draft) || Boolean(imageDrafts[product.product_code])
  }

  function cancelEdit(product: Product) {
    // 編集モード・チェックは維持したまま、この行の変更だけ元に戻す
    resetRowDrafts([product.product_code])
    setMessage(`変更を元に戻しました：${product.product_code}`)
  }

  function cancelAllEdits() {
    if (editingCodes.size === 0 || savingCode) {
      return
    }

    const dirtyCodes = getDirtyCodes(editingCodes)

    if (dirtyCodes.length === 0) {
      setMessage('元に戻す変更はありません。')
      return
    }

    resetRowDrafts(dirtyCodes)
    setMessage(`${dirtyCodes.length}件の変更を元に戻しました。`)
  }

  // 保存済みの値を即座に一覧へ反映し、下書きも保存後の値に揃える（=「編集可能」の色に戻る）
  function applySavedRows(rows: Array<{ product_code: string } & Partial<Product>>) {
    if (rows.length === 0) {
      return
    }

    const rowByCode = new Map(rows.map((row) => [row.product_code, row]))
    const nextProductByCode = new Map<string, Product>()

    products.forEach((product) => {
      const row = rowByCode.get(product.product_code)

      if (row) {
        nextProductByCode.set(product.product_code, { ...product, ...row })
      }
    })

    setProducts((prev) =>
      prev.map((product) => nextProductByCode.get(product.product_code) ?? product),
    )
    setRowDrafts((prev) => {
      const next = { ...prev }

      nextProductByCode.forEach((product, code) => {
        next[code] = productToDraft(product)
      })

      return next
    })
  }

  // 保存した行だけDBから取り直して反映する（全件再取得するとページが1に戻るため）
  async function refreshProductsByCodes(codes: string[]) {
    const refreshed: Product[] = []

    for (let index = 0; index < codes.length; index += 200) {
      const chunk = codes.slice(index, index + 200)
      const { data, error } = await supabase
        .from('products')
        .select('*')
        .in('product_code', chunk)

      if (error) {
        return
      }

      refreshed.push(...((data ?? []) as Product[]))
    }

    if (refreshed.length === 0) {
      return
    }

    const refreshedByCode = new Map(refreshed.map((product) => [product.product_code, product]))

    setProducts((prev) =>
      prev.map((product) => refreshedByCode.get(product.product_code) ?? product),
    )
    setRowDrafts((prev) => {
      const next = { ...prev }

      refreshedByCode.forEach((product, code) => {
        const current = next[code]

        // 再取得中にさらに編集された行は、その入力を優先して残す
        if (!current || !isDraftDirty(product, current)) {
          next[code] = productToDraft(product)
        }
      })

      return next
    })
  }

  async function saveAllEdits() {
    if (editingCodes.size === 0 || savingCode) {
      return
    }

    const dirtyProducts = products.filter(
      (product) =>
        editingCodes.has(product.product_code) &&
        hasRowChanges(product, rowDrafts[product.product_code] ?? productToDraft(product)),
    )

    if (dirtyProducts.length === 0) {
      setMessage('保存する変更はありません。')
      return
    }

    setSavingCode('__bulk_save__')
    setMessage('')

    const now = new Date().toISOString()
    const fieldDirtyProducts = dirtyProducts.filter((product) =>
      isDraftDirty(product, rowDrafts[product.product_code] ?? productToDraft(product)),
    )
    const payload = fieldDirtyProducts.map((product) => ({
      product_code: product.product_code,
      ...normalizeDraft(rowDrafts[product.product_code] ?? productToDraft(product)),
      updated_at: now,
    }))

    if (payload.length > 0) {
      const { error } = await supabase
        .from('products')
        .upsert(payload, { onConflict: 'product_code' })

      if (error) {
        setMessage(`すべて保存失敗: ${error.message}`)
        setSavingCode(null)
        return
      }
    }

    const imageProducts = dirtyProducts.filter((product) => imageDrafts[product.product_code])
    const failedImageCodes = new Set<string>()
    const failedImageNames: string[] = []

    await runWithConcurrency(imageProducts, IMAGE_UPLOAD_CONCURRENCY, async (product) => {
      const imageDraft = imageDrafts[product.product_code]

      if (!imageDraft) {
        return
      }

      try {
        await uploadProductImageFile(product.product_code, imageDraft.file)
      } catch {
        failedImageCodes.add(product.product_code)
        failedImageNames.push(`${product.product_code}（${imageDraft.sourceName}）`)
      }
    })

    const successfulImageCodes = imageProducts
      .map((product) => product.product_code)
      .filter((productCode) => !failedImageCodes.has(productCode))

    if (successfulImageCodes.length > 0) {
      removeImageDrafts(successfulImageCodes)
      setImageCacheVersion(Date.now())
    }

    applySavedRows(payload)

    if (failedImageCodes.size > 0) {
      setMessage(
        `保存しましたが、画像アップロード失敗が${failedImageCodes.size}件あります。失敗した画像は保存待ちのまま残しました。例：${failedImageNames.slice(0, 3).join('、')}`,
      )
    } else {
      setMessage(`${dirtyProducts.length}件保存しました。編集モードは継続中です。`)
    }

    setSavingCode(null)
    await refreshProductsByCodes(payload.map((row) => row.product_code))
  }

  async function createBulkProducts() {
    const targetRows = bulkUpdateOnly
      ? bulkSummary.updateRows
      : bulkShouldUpdateExisting
        ? bulkSummary.uniqueRows
        : bulkSummary.insertRows
    const targetCodeSet = new Set(targetRows.map((row) => row.product_code))

    if (bulkSummary.filledCount === 0) {
      setModalMessage(
        bulkImageDraftCount > 0
          ? '画像を反映するには商品コードを入力してください。'
          : '追加/更新できる商品がありません。',
      )
      return
    }

    if (targetRows.length === 0) {
      setModalMessage(
        bulkUpdateOnly
          ? `更新対象の既存商品がありません。未登録の商品コードは追加せずスキップします。`
          : bulkShouldUpdateExisting
            ? '入力内重複のため追加/更新対象がありません。'
            : 'すべて既存商品コード、または入力内重複のため追加対象がありません。既存も更新する場合はチェックを入れてください。',
      )
      return
    }

    const seenCodes = new Set<string>()
    const targetBulkRows = bulkRows
      .map((row) => {
        const cleanRow: CleanBulkProductRow = {
          product_code: row.product_code.trim(),
          product_name: row.product_name.trim(),
          floor: row.floor.trim(),
          shipping_floor: row.shipping_floor.trim(),
          special_notes: row.special_notes.trim(),
          picking_advice: row.picking_advice.trim(),
          delivery_line_4: row.delivery_line_4.trim(),
          rack_number: row.rack_number.trim(),
          rack_level: row.rack_level.trim(),
          sticker_color: row.sticker_color.trim(),
          order_url_1: row.order_url_1.trim(),
          order_url_2: row.order_url_2.trim(),
          order_url_3: row.order_url_3.trim(),
          order_size: row.order_size.trim(),
          order_color: row.order_color.trim(),
          order_simple_instruction: row.order_simple_instruction.trim(),
          order_detail_instruction: row.order_detail_instruction.trim(),
          order_quantity_condition: row.order_quantity_condition.trim(),
          order_note: row.order_note.trim(),
          order_out: row.order_out,
          no_1688_shop: row.no_1688_shop,
        }

        return { row, cleanRow }
      })
      .filter(({ cleanRow }) => {
        if (!cleanRow.product_code || !targetCodeSet.has(cleanRow.product_code) || seenCodes.has(cleanRow.product_code)) {
          return false
        }

        seenCodes.add(cleanRow.product_code)
        return true
      })

    const imageRows = targetBulkRows.filter(({ row }) => bulkImageDrafts[row.id])

    setLoading(true)
    setModalMessage('')

    const now = new Date().toISOString()
    const payload = targetBulkRows.map(({ row, cleanRow }) => {
      const productPayload: Record<string, string | boolean | null> = {
        product_code: cleanRow.product_code,
        updated_at: now,
      }
      const hasImageOnlyChange = Boolean(bulkImageDrafts[row.id]) && selectedBulkFields.every((key) => {
        return !isBulkBooleanField(key) && !cleanRow[key]
      })

      if (!hasImageOnlyChange) {
        selectedBulkFields.forEach((key) => {
          productPayload[key] = isBulkBooleanField(key)
            ? cleanRow[key]
            : cleanRow[key] || null
        })
      }

      return productPayload
    })

    const { error } = bulkUpdateOnly || bulkShouldUpdateExisting
      ? await supabase
          .from('products')
          .upsert(payload, { onConflict: 'product_code' })
      : await supabase.from('products').insert(payload)

    if (error) {
      setModalMessage(`${bulkUpdateOnly ? '一括更新' : '一括追加/更新'}失敗: ${error.message}`)
      setLoading(false)
      return
    }

    const failedImageRowIds = new Set<string>()
    const failedImageNames: string[] = []

    await runWithConcurrency(imageRows, IMAGE_UPLOAD_CONCURRENCY, async ({ row, cleanRow }) => {
      const imageDraft = bulkImageDrafts[row.id]

      if (!imageDraft) {
        return
      }

      try {
        await uploadProductImageFile(cleanRow.product_code, imageDraft.file)
      } catch {
        failedImageRowIds.add(row.id)
        failedImageNames.push(`${cleanRow.product_code}（${imageDraft.sourceName}）`)
      }
    })

    const successfulImageRowIds = imageRows
      .map(({ row }) => row.id)
      .filter((rowId) => !failedImageRowIds.has(rowId))

    if (successfulImageRowIds.length > 0) {
      clearBulkImageDrafts(successfulImageRowIds)
      setImageCacheVersion(Date.now())
    }

    await fetchProducts()

    if (failedImageRowIds.size > 0) {
      setModalMessage(
        `商品情報は保存しましたが、画像アップロード失敗が${failedImageRowIds.size}件あります。失敗行は残しています。例：${failedImageNames.slice(0, 3).join('、')}`,
      )
      setLoading(false)
      return
    }

    closeCreateModal()
    setMessage(
      bulkUpdateOnly
        ? `${bulkUpdateableCount}件更新しました。未登録商品のスキップ：${bulkInsertableCount}件 / 画像：${imageRows.length}件`
        : bulkShouldUpdateExisting
          ? `${bulkInsertableCount}件追加、${bulkUpdateableCount}件更新しました。画像：${imageRows.length}件`
          : `${bulkInsertableCount}件追加しました。既存商品のスキップ：${bulkExistingCount}件 / 画像：${imageRows.length}件`,
    )
    setLoading(false)
  }

  async function saveRow(product: Product) {
    const draft = rowDrafts[product.product_code]

    if (!draft) {
      setMessage('保存対象が見つかりません。')
      return
    }

    const imageDraft = imageDrafts[product.product_code]

    if (!isDraftDirty(product, draft) && !imageDraft) {
      setMessage('変更はありません。')
      return
    }

    setSavingCode(product.product_code)
    setMessage('')

    let payload: ReturnType<typeof normalizeDraft> & { updated_at: string }

    try {
      payload = {
        ...normalizeDraft(draft),
        updated_at: new Date().toISOString(),
      }
    } catch (error) {
      setMessage(error instanceof Error ? error.message : '入力内容を確認してください。')
      setSavingCode(null)
      return
    }

    const { error } = await supabase
      .from('products')
      .update(payload)
      .eq('product_code', product.product_code)

    if (error) {
      setMessage(`保存失敗: ${error.message}`)
      setSavingCode(null)
      return
    }

    if (imageDraft) {
      try {
        await uploadProductImageFile(product.product_code, imageDraft.file)
        removeImageDrafts([product.product_code])
        setImageCacheVersion(Date.now())
      } catch (uploadError) {
        setMessage(
          `商品情報は保存しましたが、画像アップロードに失敗しました：${uploadError instanceof Error ? uploadError.message : String(uploadError)}`,
        )
        setSavingCode(null)
        return
      }
    }

    setMessage(`保存しました：${product.product_code}`)
    applySavedRows([{ product_code: product.product_code, ...payload }])
    setSavingCode(null)
    await refreshProductsByCodes([product.product_code])
  }

  function renderPaperSortSubCell(product: Product, draft: EditableProduct) {
    const isEditing = editingCodes.has(product.product_code)
    const isSubProduct = Boolean(draft.paper_sort_sub)

    if (!isEditing) {
      return (
        <div className="paper-sort-sub-cell" title="チェック時、単価0円の付属品は伝票の棚ソート判定から除外します">
          <span
            className={`paper-sort-sub-readonly ${isSubProduct ? 'is-checked' : ''}`}
            role="img"
            aria-label={`${product.product_code} は${isSubProduct ? '' : '非'}サブ商品`}
          >
            {isSubProduct ? '✓' : ''}
          </span>
        </div>
      )
    }

    return (
      <div className="paper-sort-sub-cell" title="チェック時、単価0円の付属品は伝票の棚ソート判定から除外します">
        <input
          type="checkbox"
          className="paper-sort-sub-checkbox"
          checked={isSubProduct}
          onChange={(event) =>
            updateDraft(product.product_code, 'paper_sort_sub', event.target.checked)
          }
          aria-label={`${product.product_code} をサブ商品にする`}
        />
      </div>
    )
  }

  function renderOrderExclusionFlagCell(
    product: Product,
    draft: EditableProduct,
    key: 'order_out' | 'no_1688_shop',
    label: string,
  ) {
    const isEditing = editingCodes.has(product.product_code)
    const checked = Boolean(draft[key])

    if (!isEditing) {
      return (
        <div className="paper-sort-sub-cell" title={checked ? `${label}：OrderBoardから除外` : label}>
          <span
            className={`paper-sort-sub-readonly ${checked ? 'is-checked' : ''}`}
            role="img"
            aria-label={`${product.product_code} ${label} ${checked ? 'ON' : 'OFF'}`}
          >
            {checked ? '✓' : ''}
          </span>
        </div>
      )
    }

    return (
      <div className="paper-sort-sub-cell" title={`${label}をONにするとOrderBoardの一覧・発注対象から除外します`}>
        <input
          type="checkbox"
          className="paper-sort-sub-checkbox"
          checked={checked}
          onChange={(event) => updateDraft(product.product_code, key, event.target.checked)}
          aria-label={`${product.product_code} ${label}`}
        />
      </div>
    )
  }

  function renderTextCell(
    product: Product,
    draft: EditableProduct,
    key: EditableTextProductKey,
    options: {
      className?: string
      inputClassName?: string
      multiline?: boolean
      placeholder?: string
    } = {},
  ) {
    const isEditing = editingCodes.has(product.product_code)
    const placeholder = options.placeholder ?? EDIT_FIELD_PLACEHOLDERS[key]

    if (isEditing) {
      if (options.multiline) {
        return (
          <textarea
            className={`table-input table-textarea ${options.inputClassName ?? ''}`}
            value={draft[key]}
            onChange={(event) => updateDraft(product.product_code, key, event.target.value)}
            placeholder={placeholder}
          />
        )
      }

      return (
        <input
          className={`table-input ${options.inputClassName ?? ''}`}
          value={draft[key]}
          onChange={(event) => updateDraft(product.product_code, key, event.target.value)}
          placeholder={placeholder}
        />
      )
    }

    const displayValue = product[key]
    return <DisplayText value={displayValue == null ? null : String(displayValue)} className={options.className} />
  }

  function renderUrlTextCell(
    product: Product,
    draft: EditableProduct,
    key: EditableTextProductKey,
  ) {
    const isEditing = editingCodes.has(product.product_code)

    if (isEditing) {
      return (
        <UrlEditCell
          value={draft[key]}
          onChange={(value) => updateDraft(product.product_code, key, value)}
          placeholder={EDIT_FIELD_PLACEHOLDERS[key]}
        />
      )
    }

    const url = String(product[key] ?? '').trim()

    if (!url) {
      return <DisplayText value={null} className="mono-text" />
    }

    return (
      <a className="order-link mono-text" href={url} target="_blank" rel="noreferrer">
        開く
      </a>
    )
  }

  function renderOrderMemoCell(
    product: Product,
    draft: EditableProduct,
    orderKey: EditableTextProductKey,
    urlKey: EditableTextProductKey,
  ) {
    const isEditing = editingCodes.has(product.product_code)
    const orderLabel = EDIT_FIELD_PLACEHOLDERS[orderKey]
    const rmLabel = EDIT_FIELD_PLACEHOLDERS[urlKey]

    if (isEditing) {
      return (
        <div className="order-edit-stack">
          <input
            className="table-input order-input"
            value={draft[orderKey]}
            onChange={(event) =>
              updateDraft(product.product_code, orderKey, event.target.value)
            }
            placeholder={orderLabel}
          />

          <div className="order-rm-edit-row">
            <span>{rmLabel}</span>
            <UrlEditCell
              value={draft[urlKey]}
              onChange={(value) => updateDraft(product.product_code, urlKey, value)}
              placeholder={rmLabel}
            />
          </div>
        </div>
      )
    }

    const orderValue = String(product[orderKey] ?? '').trim()
    const url = String(product[urlKey] ?? '').trim()

    if (!orderValue) {
      return <DisplayText value={null} className="mono-text" />
    }

    if (!url) {
      return <DisplayText value={orderValue} className="mono-text" />
    }

    return (
      <a className="order-link mono-text" href={url} target="_blank" rel="noreferrer" title="RMを開く">
        {orderValue}
      </a>
    )
  }

  function updateRakumartRecipeDraft(
    updater: (draft: RakumartRecipeDraft) => RakumartRecipeDraft,
  ) {
    setRakumartRecipeModal((prev) => {
      if (!prev) return prev
      return {
        ...prev,
        draft: updater(prev.draft),
      }
    })
  }

  function updateRakumartItem(itemId: string, patch: Partial<RakumartItemDraft>) {
    updateRakumartRecipeDraft((draft) => ({
      ...draft,
      items: draft.items.map((item) =>
        item.id === itemId ? { ...item, ...patch } : item,
      ),
    }))
  }

  function updateRakumartSource(
    itemId: string,
    sourceId: string,
    patch: Partial<RakumartSourceDraft>,
  ) {
    updateRakumartRecipeDraft((draft) => ({
      ...draft,
      items: draft.items.map((item) =>
        item.id === itemId
          ? {
              ...item,
              sources: item.sources.map((source) =>
                source.id === sourceId ? { ...source, ...patch } : source,
              ),
            }
          : item,
      ),
    }))
  }

  function updateRakumartLine(
    itemId: string,
    sourceId: string,
    lineId: string,
    patch: Partial<RakumartLineDraft>,
  ) {
    updateRakumartRecipeDraft((draft) => ({
      ...draft,
      items: draft.items.map((item) =>
        item.id === itemId
          ? {
              ...item,
              sources: item.sources.map((source) =>
                source.id === sourceId
                  ? {
                      ...source,
                      lines: source.lines.map((line) =>
                        line.id === lineId ? { ...line, ...patch } : line,
                      ),
                    }
                  : source,
              ),
            }
          : item,
      ),
    }))
  }

  function updateRakumartOption(
    itemId: string,
    sourceId: string,
    lineId: string,
    optionId: string,
    patch: Partial<RakumartOptionDraft>,
  ) {
    updateRakumartRecipeDraft((draft) => ({
      ...draft,
      items: draft.items.map((item) =>
        item.id === itemId
          ? {
              ...item,
              sources: item.sources.map((source) =>
                source.id === sourceId
                  ? {
                      ...source,
                      lines: source.lines.map((line) =>
                        line.id === lineId
                          ? {
                              ...line,
                              options: line.options.map((option) =>
                                option.id === optionId ? { ...option, ...patch } : option,
                              ),
                            }
                          : line,
                      ),
                    }
                  : source,
              ),
            }
          : item,
      ),
    }))
  }

  function addRakumartItem() {
    updateRakumartRecipeDraft((draft) => ({
      ...draft,
      items: [...draft.items, createRakumartItemDraft()],
    }))
  }

  function removeRakumartItem(itemId: string) {
    updateRakumartRecipeDraft((draft) => ({
      ...draft,
      items: draft.items.filter((item) => item.id !== itemId),
    }))
  }

  function addRakumartSource(itemId: string) {
    updateRakumartRecipeDraft((draft) => ({
      ...draft,
      items: draft.items.map((item) =>
        item.id === itemId
          ? { ...item, sources: [...item.sources, createRakumartSourceDraft()] }
          : item,
      ),
    }))
  }

  function removeRakumartSource(itemId: string, sourceId: string) {
    updateRakumartRecipeDraft((draft) => ({
      ...draft,
      items: draft.items.map((item) =>
        item.id === itemId
          ? { ...item, sources: item.sources.filter((source) => source.id !== sourceId) }
          : item,
      ),
    }))
  }

  function addRakumartLine(itemId: string, sourceId: string) {
    updateRakumartRecipeDraft((draft) => ({
      ...draft,
      items: draft.items.map((item) =>
        item.id === itemId
          ? {
              ...item,
              sources: item.sources.map((source) =>
                source.id === sourceId
                  ? { ...source, lines: [...source.lines, createRakumartLineDraft()] }
                  : source,
              ),
            }
          : item,
      ),
    }))
  }

  function removeRakumartLine(itemId: string, sourceId: string, lineId: string) {
    updateRakumartRecipeDraft((draft) => ({
      ...draft,
      items: draft.items.map((item) =>
        item.id === itemId
          ? {
              ...item,
              sources: item.sources.map((source) =>
                source.id === sourceId
                  ? { ...source, lines: source.lines.filter((line) => line.id !== lineId) }
                  : source,
              ),
            }
          : item,
      ),
    }))
  }

  function addRakumartOption(itemId: string, sourceId: string, lineId: string) {
    updateRakumartRecipeDraft((draft) => ({
      ...draft,
      items: draft.items.map((item) =>
        item.id === itemId
          ? {
              ...item,
              sources: item.sources.map((source) =>
                source.id === sourceId
                  ? {
                      ...source,
                      lines: source.lines.map((line) =>
                        line.id === lineId
                          ? { ...line, options: [...line.options, createRakumartOptionDraft()] }
                          : line,
                      ),
                    }
                  : source,
              ),
            }
          : item,
      ),
    }))
  }

  function removeRakumartOption(
    itemId: string,
    sourceId: string,
    lineId: string,
    optionId: string,
  ) {
    updateRakumartRecipeDraft((draft) => ({
      ...draft,
      items: draft.items.map((item) =>
        item.id === itemId
          ? {
              ...item,
              sources: item.sources.map((source) =>
                source.id === sourceId
                  ? {
                      ...source,
                      lines: source.lines.map((line) =>
                        line.id === lineId
                          ? {
                              ...line,
                              options: line.options.filter((option) => option.id !== optionId),
                            }
                          : line,
                      ),
                    }
                  : source,
              ),
            }
          : item,
      ),
    }))
  }

  async function fetchRakumartRecipe(productCode: string) {
    const { data, error } = await supabase.rpc('get_rakumart_order_recipe', {
      p_product_code: productCode,
    })

    if (error) {
      throw new Error(error.message)
    }

    if (!data) {
      return null
    }

    return data as unknown as RakumartRecipeDbRow
  }

  async function openRakumartRecipe(product: Product) {
    setRakumartRecipeMessage('')
    setRakumartRecipeLoading(true)
    setRakumartRecipeModal({
      product,
      draft: createEmptyRakumartRecipeDraft(),
      exists: false,
      legacySeeded: false,
      legacyRelation: null,
    })

    try {
      const data = await fetchRakumartRecipe(product.product_code)
      const legacyUrls = getRakumartLegacyOrderUrls(product)
      const shouldAutoSeed = !data && legacyUrls.length === 1

      setRakumartRecipeModal({
        product,
        draft: data
          ? rakumartRecipeDbRowToDraft(data)
          : shouldAutoSeed
            ? createRakumartRecipeDraftFromLegacy(product, 'separate')
            : createEmptyRakumartRecipeDraft(),
        exists: Boolean(data),
        legacySeeded: shouldAutoSeed,
        legacyRelation: shouldAutoSeed ? 'separate' : null,
      })

      if (shouldAutoSeed) {
        setRakumartRecipeMessage('既存の発注URL・規格値から、未保存のたたき台を作成しました。内容を確認して保存してください。')
      }
    } catch (error) {
      setRakumartRecipeMessage(
        `読み込み失敗: ${error instanceof Error ? error.message : '不明なエラー'}`,
      )
    } finally {
      setRakumartRecipeLoading(false)
    }
  }

  function applyRakumartLegacySeed(relation: RakumartLegacyUrlRelation) {
    setRakumartRecipeModal((prev) => {
      if (!prev || prev.exists) return prev

      if (relation === 'manual') {
        return {
          ...prev,
          draft: createEmptyRakumartRecipeDraft(),
          legacySeeded: false,
          legacyRelation: 'manual',
        }
      }

      return {
        ...prev,
        draft: createRakumartRecipeDraftFromLegacy(prev.product, relation),
        legacySeeded: true,
        legacyRelation: relation,
      }
    })

    setRakumartRecipeMessage(
      relation === 'manual'
        ? '空のレシピに切り替えました。'
        : '既存の商品DB情報から未保存のたたき台を作成しました。内容を確認して保存してください。',
    )
  }

  function closeRakumartRecipe() {
    if (rakumartRecipeSaving) return
    setRakumartRecipeModal(null)
    setRakumartRecipeMessage('')
    setRakumartRecipeLoading(false)
  }

  async function saveRakumartRecipe() {
    if (!rakumartRecipeModal) return

    let payload: ReturnType<typeof serializeRakumartRecipeDraft>
    try {
      payload = serializeRakumartRecipeDraft(rakumartRecipeModal.draft)
    } catch (error) {
      setRakumartRecipeMessage(error instanceof Error ? error.message : '入力内容を確認してください。')
      return
    }

    setRakumartRecipeSaving(true)
    setRakumartRecipeMessage('')

    const productCode = rakumartRecipeModal.product.product_code
    const { error } = await supabase.rpc('save_rakumart_order_recipe', {
      p_product_code: productCode,
      p_recipe: payload,
    })

    if (error) {
      setRakumartRecipeMessage(`保存失敗: ${error.message}`)
      setRakumartRecipeSaving(false)
      return
    }

    try {
      // 「保存成功」と表示する前にDBから同じレシピを再取得して、永続化を確認する。
      const saved = await fetchRakumartRecipe(productCode)
      if (!saved) {
        throw new Error('保存後のレシピをDBから取得できませんでした。')
      }

      setRakumartRecipeModal((prev) =>
        prev
          ? {
              ...prev,
              draft: rakumartRecipeDbRowToDraft(saved),
              exists: true,
              legacySeeded: false,
              legacyRelation: null,
            }
          : prev,
      )
      setRakumartRecipeMessage('発注レシピを保存しました。')
    } catch (error) {
      setRakumartRecipeMessage(
        `保存後の確認に失敗しました: ${error instanceof Error ? error.message : '不明なエラー'}`,
      )
    } finally {
      setRakumartRecipeSaving(false)
    }
  }

  async function deleteRakumartRecipe() {
    if (!rakumartRecipeModal?.exists || rakumartRecipeSaving) return

    const shouldDelete = window.confirm(
      `${rakumartRecipeModal.product.product_code} の発注レシピを削除しますか？`,
    )
    if (!shouldDelete) return

    setRakumartRecipeSaving(true)
    setRakumartRecipeMessage('')

    const { error } = await supabase
      .from('rakumart_order_recipes')
      .delete()
      .eq('product_code', rakumartRecipeModal.product.product_code)

    if (error) {
      setRakumartRecipeMessage(`削除失敗: ${error.message}`)
      setRakumartRecipeSaving(false)
      return
    }

    setRakumartRecipeSaving(false)
    setRakumartRecipeModal(null)
    setMessage(`発注レシピを削除しました：${rakumartRecipeModal.product.product_code}`)
  }

  function openDeliverySlipPreview(product: Product, draft: EditableProduct) {
    setDeliverySlipPreview({
      productCode: product.product_code,
      productName: draft.product_name,
      specialNotes: draft.special_notes,
      pickingAdvice: draft.picking_advice,
      deliveryLine4: draft.delivery_line_4,
      floor: draft.floor,
      rackNumber: draft.rack_number,
      rackLevel: draft.rack_level,
      stickerColor: draft.sticker_color,
    })
  }

  function renderDeliveryPreviewButton(product: Product, draft: EditableProduct) {
    return (
      <button
        type="button"
        className="small secondary delivery-preview-button"
        onClick={() => openDeliverySlipPreview(product, draft)}
      >
        プレビュー
      </button>
    )
  }

  function handleRowDoubleClick(product: Product, event: ReactMouseEvent<HTMLTableRowElement>) {
    const target = event.target instanceof HTMLElement ? event.target : null
    const isInteractiveTarget = Boolean(target?.closest('button, a, input, textarea, select'))

    if (isInteractiveTarget || savingCode) {
      return
    }

    startEdit(product)
  }

  function toggleSort(column: ColumnSpec) {
    if (!isSortableColumn(column.key)) {
      return
    }

    const sortKey = column.key

    setSortConfig((prev) => {
      if (!prev || prev.key !== sortKey) {
        return { key: sortKey, direction: 'asc' }
      }

      return { key: sortKey, direction: prev.direction === 'asc' ? 'desc' : 'asc' }
    })
  }

  function renderActions(product: Product, draft: EditableProduct) {
    const isEditing = editingCodes.has(product.product_code)
    const dirty = isEditing && hasRowChanges(product, draft)
    const isSaving = savingCode === product.product_code

    if (isEditing) {
      return (
        <div className="row-actions">
          <button
            className="small save-button"
            onClick={() => saveRow(product)}
            disabled={!dirty || isSaving || Boolean(savingCode)}
          >
            {isSaving ? '保存中' : '保存'}
          </button>

          <button
            className="secondary small cancel-button"
            onClick={() => cancelEdit(product)}
            disabled={!dirty || isSaving}
          >
            元に戻す
          </button>

          {tableView === 'purchase' && (
            <button
              type="button"
              className="secondary small recipe-button"
              onClick={() => void openRakumartRecipe(product)}
              disabled={isSaving || rakumartRecipeLoading || rakumartRecipeSaving}
            >
              レシピ
            </button>
          )}
        </div>
      )
    }

    // 通常時の行編集はダブルクリック or 編集モードで行うため、「編集」ボタンは置かない
    if (tableView !== 'purchase') {
      return null
    }

    return (
      <div className="row-actions">
        <button
          type="button"
          className="secondary small recipe-button"
          onClick={() => void openRakumartRecipe(product)}
          disabled={Boolean(savingCode) || rakumartRecipeLoading || rakumartRecipeSaving}
        >
          レシピ
        </button>
      </div>
    )
  }

  const currentColumnSpecs = useMemo(
    () => getViewColumnSpecs(tableView, isEditMode, customColumnKeys),
    [tableView, isEditMode, customColumnKeys],
  )
  const customColumnCandidates = useMemo(() => getCustomColumnCandidateSpecs(), [])
  const showActionsColumn = shouldShowActionsColumn(tableView, isEditMode)
  const actionColumnSpec = showActionsColumn ? currentColumnSpecs[currentColumnSpecs.length - 1] : null
  const dataColumnSpecs = showActionsColumn ? currentColumnSpecs.slice(0, -1) : currentColumnSpecs

  function getRecommendedColumnWidth(column: ColumnSpec) {
    return recommendedColumnWidthsByView[tableView]?.[column.key] ?? column.width
  }

  function getColumnWidth(column: ColumnSpec) {
    return columnWidths[column.key] ?? column.width
  }

  function getRecommendedColumnWidthInputKey(column: ColumnSpec) {
    return `${tableView}:${column.key}`
  }

  function getRecommendedColumnWidthInput(column: ColumnSpec) {
    const inputKey = getRecommendedColumnWidthInputKey(column)
    return recommendedColumnWidthInputs[inputKey] ?? String(getRecommendedColumnWidth(column))
  }

  function resolveRecommendedColumnWidthInput(column: ColumnSpec) {
    const rawValue = recommendedColumnWidthInputs[getRecommendedColumnWidthInputKey(column)]
    if (rawValue === undefined || rawValue.trim() === '') {
      return getRecommendedColumnWidth(column)
    }

    const parsed = Number(rawValue)
    return Number.isFinite(parsed) ? clampColumnWidth(parsed) : getRecommendedColumnWidth(column)
  }

  function updateRecommendedColumnWidthInput(column: ColumnSpec, rawValue: string) {
    // Keep the field as an uncommitted text value while typing. Using a native
    // number input with min/max caused the browser to coerce partial values
    // such as "1" to 64 before the user could finish entering "120".
    const digitsOnly = rawValue.replace(/[^0-9]/g, '')
    setRecommendedColumnWidthInputs((prev) => ({
      ...prev,
      [getRecommendedColumnWidthInputKey(column)]: digitsOnly,
    }))
    setSharedColumnWidthsDirty(true)
  }

  function commitRecommendedColumnWidthInput(column: ColumnSpec) {
    const resolvedWidth = resolveRecommendedColumnWidthInput(column)
    setRecommendedColumnWidthsByView((prev) => ({
      ...prev,
      [tableView]: {
        ...(prev[tableView] ?? {}),
        [column.key]: resolvedWidth,
      },
    }))
    setRecommendedColumnWidthInputs((prev) => ({
      ...prev,
      [getRecommendedColumnWidthInputKey(column)]: String(resolvedWidth),
    }))
  }

  function getCurrentRecommendedWidths() {
    return Object.fromEntries(
      currentColumnSpecs.map((column) => [column.key, resolveRecommendedColumnWidthInput(column)]),
    )
  }

  async function saveSharedRecommendedWidths(widths: ColumnWidthMap, successMessage: string) {
    setSharedColumnWidthsSaving(true)

    const { error } = await supabase
      .from(APP_SETTINGS_TABLE)
      .upsert(
        {
          setting_key: getColumnWidthSettingKey(tableView),
          setting_value: widths,
          updated_at: new Date().toISOString(),
        },
        { onConflict: 'setting_key' },
      )

    if (error) {
      setSharedColumnWidthsSaving(false)
      setMessage(`共有推奨幅の保存失敗: ${error.message}`)
      return false
    }

    setRecommendedColumnWidthsByView((prev) => ({ ...prev, [tableView]: widths }))
    setRecommendedColumnWidthInputs({})
    setSharedColumnWidthsDirty(false)
    setSharedColumnWidthsSaving(false)
    setMessage(successMessage)
    return true
  }

  async function saveEditedRecommendedWidths() {
    await saveSharedRecommendedWidths(
      getCurrentRecommendedWidths(),
      '入力した推奨幅を共有設定へ保存しました',
    )
  }

  async function captureCurrentWidthsAsRecommended() {
    const capturedWidths = Object.fromEntries(
      currentColumnSpecs.map((column) => [column.key, getColumnWidth(column)]),
    )
    setRecommendedColumnWidthsByView((prev) => ({ ...prev, [tableView]: capturedWidths }))
    setRecommendedColumnWidthInputs({})
    await saveSharedRecommendedWidths(
      capturedWidths,
      '現在の列幅を共有推奨幅へ反映しました',
    )
  }

  function applyRecommendedColumnWidths() {
    const widthsToApply = getCurrentRecommendedWidths()
    setColumnWidths((prev) => ({ ...prev, ...widthsToApply }))
    setIsColumnWidthMenuOpen(false)
    setMessage('共有推奨幅を適用しました')
  }

  function startColumnResize(column: ColumnSpec, event: ColumnResizeMouseEvent) {
    event.preventDefault()
    event.stopPropagation()

    const startX = event.clientX
    const startWidth = getColumnWidth(column)

    document.body.classList.add('is-column-resizing')

    const handleMouseMove = (moveEvent: MouseEvent) => {
      const nextWidth = clampColumnWidth(startWidth + moveEvent.clientX - startX)
      setColumnWidths((prev) => ({ ...prev, [column.key]: nextWidth }))
    }

    const handleMouseUp = () => {
      document.body.classList.remove('is-column-resizing')
      window.removeEventListener('mousemove', handleMouseMove)
      window.removeEventListener('mouseup', handleMouseUp)
    }

    window.addEventListener('mousemove', handleMouseMove)
    window.addEventListener('mouseup', handleMouseUp)
  }

  function renderColumnHeader(column: ColumnSpec) {
    const sortable = isSortableColumn(column.key)
    const sorted = sortConfig?.key === column.key
    const sortLabel = sorted ? (sortConfig.direction === 'asc' ? '昇順' : '降順') : '未並び替え'
    const bulkConfig = isEditMode ? getBulkColumnEditConfig(column, tableView) : null
    const className = [
      'resizable-header',
      column.className,
      sortable ? 'is-sortable' : '',
      sorted ? 'is-sorted' : '',
      bulkConfig ? 'has-bulk-trigger' : '',
    ]
      .filter(Boolean)
      .join(' ')

    return (
      <th
        key={column.key}
        className={className}
        aria-sort={sorted ? (sortConfig.direction === 'asc' ? 'ascending' : 'descending') : undefined}
      >
        {sortable ? (
          <button
            type="button"
            className="header-sort-button"
            onClick={() => toggleSort(column)}
            title={`${column.label}を${sorted && sortConfig.direction === 'asc' ? '降順' : '昇順'}に並び替え`}
          >
            <span className="header-label">{column.label}</span>
            <span className="sort-indicator" aria-label={sortLabel}>
              {sorted ? (sortConfig.direction === 'asc' ? '▲' : '▼') : '↕'}
            </span>
          </button>
        ) : (
          <span className="header-label">{column.label}</span>
        )}
        {bulkConfig && (
          <div className="bulk-column-trigger">
            <button
              type="button"
              className="bulk-column-button"
              onClick={() => openBulkColumnEdit(bulkConfig)}
              disabled={editingCodes.size === 0 || Boolean(savingCode)}
              title={`チェック中の商品の「${column.label}」をまとめて入力`}
            >
              一括入力
            </button>
          </div>
        )}
        <button
          type="button"
          className="column-resizer"
          onMouseDown={(event) => startColumnResize(column, event)}
          aria-label={`${column.label}の列幅を調整`}
          title="ドラッグで列幅調整"
        />
      </th>
    )
  }

  const selectColumnWidth = isEditMode ? SELECT_COLUMN_WIDTH : 0
  const tableWidth =
    currentColumnSpecs.reduce((sum, column) => sum + getColumnWidth(column), 0) + selectColumnWidth * 2
  const tableStyle = {
    '--select-column-width': `${selectColumnWidth}px`,
    '--image-column-width': `${getColumnWidth(currentColumnSpecs[0])}px`,
    '--products-table-width': `${tableWidth}px`,
  } as CSSProperties

  function renderNeInfoColumns(product: Product) {
    return (
      <>
        <td><DisplayText value={formatNumericValue(product.free_stock)} className="mono-text number-text" /></td>
        <td><DisplayText value={formatNumericValue(product.reorder_point)} className="mono-text number-text" /></td>
        <td><DisplayText value={formatNumericValue(product.stock_constant)} className="mono-text number-text" /></td>
        <td><MonthlySalesByYear monthlySales={getProductMonthlySales(product)} /></td>
        <td className="centered-table-cell"><DisplayText value={formatClassification(product.orderboard_classification)} className="classification-text centered-cell-text" /></td>
      </>
    )
  }

  function renderNeColumns(product: Product, draft: EditableProduct) {
    return (
      <>
        <td><DisplayText value={product.product_name} className="product-name-text" /></td>
        <td className="centered-table-cell">{renderTextCell(product, draft, 'shipping_floor', { className: 'centered-cell-text', inputClassName: 'small-text-input' })}</td>
        {renderNeInfoColumns(product)}
      </>
    )
  }

  function renderAllColumns(product: Product, draft: EditableProduct) {
    return (
      <>
        <td>{renderTextCell(product, draft, 'product_name', { className: 'product-name-text', inputClassName: 'product-name-input' })}</td>
        {renderNeInfoColumns(product)}
        <td className="centered-table-cell">{renderTextCell(product, draft, 'floor', { className: 'centered-cell-text', inputClassName: 'floor-input' })}</td>
        <td>{renderTextCell(product, draft, 'special_notes', { className: 'note-text', multiline: true, placeholder: '2行目' })}</td>
        <td>{renderTextCell(product, draft, 'picking_advice', { className: 'note-text', multiline: true, placeholder: '3行目' })}</td>
        <td>{renderTextCell(product, draft, 'delivery_line_4', { className: 'note-text', multiline: true, placeholder: '4行目' })}</td>
        <td className="centered-table-cell">{renderTextCell(product, draft, 'rack_number', { className: 'centered-cell-text', inputClassName: 'rack-input' })}</td>
        <td className="centered-table-cell">{renderTextCell(product, draft, 'rack_level', { className: 'centered-cell-text', inputClassName: 'rack-level-input' })}</td>
        <td className="centered-table-cell">{renderTextCell(product, draft, 'sticker_color', { className: 'centered-cell-text', inputClassName: 'sticker-input' })}</td>
        <td className="centered-table-cell">{renderTextCell(product, draft, 'shipping_floor', { className: 'centered-cell-text', inputClassName: 'small-text-input' })}</td>
        <td className="centered-table-cell">{renderPaperSortSubCell(product, draft)}</td>
        <td>{renderDeliveryPreviewButton(product, draft)}</td>
        <td>{renderOrderMemoCell(product, draft, 'order_memo_1', 'rakumart_url_1')}</td>
        <td>{renderOrderMemoCell(product, draft, 'order_memo_2', 'rakumart_url_2')}</td>
        <td>{renderOrderMemoCell(product, draft, 'order_memo_3', 'rakumart_url_3')}</td>
        <td>{renderOrderMemoCell(product, draft, 'order_memo_4', 'rakumart_url_4')}</td>
        <td>{renderOrderMemoCell(product, draft, 'order_memo_5', 'rakumart_url_5')}</td>
        <td>{renderUrlTextCell(product, draft, 'order_url_1')}</td>
        <td>{renderUrlTextCell(product, draft, 'order_url_2')}</td>
        <td>{renderUrlTextCell(product, draft, 'order_url_3')}</td>
        <td>{renderTextCell(product, draft, 'order_size', { inputClassName: 'small-text-input' })}</td>
        <td>{renderTextCell(product, draft, 'order_color', { inputClassName: 'small-text-input' })}</td>
        <td>{renderTextCell(product, draft, 'order_simple_instruction', { className: 'note-text', multiline: true, placeholder: '■簡潔指示' })}</td>
        <td>{renderTextCell(product, draft, 'order_detail_instruction', { className: 'note-text', multiline: true, placeholder: '▲具体指示' })}</td>
        <td>{renderTextCell(product, draft, 'order_quantity_condition', { className: 'note-text', multiline: true, placeholder: '数量条件指定' })}</td>
        <td>{renderTextCell(product, draft, 'order_note', { className: 'note-text', multiline: true, placeholder: '補足情報' })}</td>
        <td className="centered-table-cell">{renderOrderExclusionFlagCell(product, draft, 'order_out', 'out')}</td>
        <td className="centered-table-cell">{renderOrderExclusionFlagCell(product, draft, 'no_1688_shop', '1688ショップなし')}</td>
        <td>{formatDateTime(product.product_info_synced_at)}</td>
        <td>{formatDateTime(product.order_status_synced_at)}</td>
        <td>{formatDateTime(product.updated_at)}</td>
      </>
    )
  }

  function renderPickColumns(product: Product, draft: EditableProduct) {
    return (
      <>
        <td>{renderTextCell(product, draft, 'product_name', { className: 'product-name-text', inputClassName: 'product-name-input' })}</td>
        <td>{renderTextCell(product, draft, 'special_notes', { className: 'note-text', multiline: true, placeholder: '2行目' })}</td>
        <td>{renderTextCell(product, draft, 'picking_advice', { className: 'note-text', multiline: true, placeholder: '3行目' })}</td>
        <td>{renderTextCell(product, draft, 'delivery_line_4', { className: 'note-text', multiline: true, placeholder: '4行目' })}</td>
        <td className="centered-table-cell">{renderTextCell(product, draft, 'floor', { className: 'centered-cell-text', inputClassName: 'floor-input' })}</td>
        <td className="centered-table-cell">{renderTextCell(product, draft, 'rack_number', { className: 'centered-cell-text', inputClassName: 'rack-input' })}</td>
        <td className="centered-table-cell">{renderTextCell(product, draft, 'rack_level', { className: 'centered-cell-text', inputClassName: 'rack-level-input' })}</td>
        <td className="centered-table-cell">{renderTextCell(product, draft, 'sticker_color', { className: 'centered-cell-text', inputClassName: 'sticker-input' })}</td>
        <td className="centered-table-cell">{renderTextCell(product, draft, 'shipping_floor', { className: 'centered-cell-text', inputClassName: 'small-text-input' })}</td>
        <td className="centered-table-cell">{renderPaperSortSubCell(product, draft)}</td>
        <td>{renderDeliveryPreviewButton(product, draft)}</td>
      </>
    )
  }

  function renderOrderColumns(product: Product, draft: EditableProduct) {
    return (
      <>
        <td>{renderTextCell(product, draft, 'product_name', { className: 'product-name-text', inputClassName: 'product-name-input' })}</td>
        <td>{renderOrderMemoCell(product, draft, 'order_memo_1', 'rakumart_url_1')}</td>
        <td>{renderOrderMemoCell(product, draft, 'order_memo_2', 'rakumart_url_2')}</td>
        <td>{renderOrderMemoCell(product, draft, 'order_memo_3', 'rakumart_url_3')}</td>
        <td>{renderOrderMemoCell(product, draft, 'order_memo_4', 'rakumart_url_4')}</td>
        <td>{renderOrderMemoCell(product, draft, 'order_memo_5', 'rakumart_url_5')}</td>
      </>
    )
  }

  function renderPurchaseColumns(product: Product, draft: EditableProduct) {
    return (
      <>
        <td>{renderTextCell(product, draft, 'product_name', { className: 'product-name-text', inputClassName: 'product-name-input' })}</td>
        <td>{renderUrlTextCell(product, draft, 'order_url_1')}</td>
        <td>{renderUrlTextCell(product, draft, 'order_url_2')}</td>
        <td>{renderUrlTextCell(product, draft, 'order_url_3')}</td>
        <td>{renderTextCell(product, draft, 'order_size', { inputClassName: 'small-text-input' })}</td>
        <td>{renderTextCell(product, draft, 'order_color', { inputClassName: 'small-text-input' })}</td>
        <td>{renderTextCell(product, draft, 'order_simple_instruction', { className: 'note-text', multiline: true, placeholder: '■簡潔指示' })}</td>
        <td>{renderTextCell(product, draft, 'order_detail_instruction', { className: 'note-text', multiline: true, placeholder: '▲具体指示' })}</td>
        <td>{renderTextCell(product, draft, 'order_quantity_condition', { className: 'note-text', multiline: true, placeholder: '数量条件指定' })}</td>
        <td>{renderTextCell(product, draft, 'order_note', { className: 'note-text', multiline: true, placeholder: '補足情報' })}</td>
        {/* 発注除外フラグは補足情報の右側に1組だけ表示する。 */}
        <td className="centered-table-cell">{renderOrderExclusionFlagCell(product, draft, 'order_out', 'out')}</td>
        <td className="centered-table-cell">{renderOrderExclusionFlagCell(product, draft, 'no_1688_shop', '1688ショップなし')}</td>
      </>
    )
  }

  // 列キーごとのセル（カスタムビュー用。「すべて」ビューと同じ表示・編集方法）
  function renderCellByKey(key: string, product: Product, draft: EditableProduct) {
    switch (key) {
      case 'product_name':
        return <td key={key}>{renderTextCell(product, draft, 'product_name', { className: 'product-name-text', inputClassName: 'product-name-input' })}</td>
      case 'free_stock':
        return <td key={key}><DisplayText value={formatNumericValue(product.free_stock)} className="mono-text number-text" /></td>
      case 'reorder_point':
        return <td key={key}><DisplayText value={formatNumericValue(product.reorder_point)} className="mono-text number-text" /></td>
      case 'stock_constant':
        return <td key={key}><DisplayText value={formatNumericValue(product.stock_constant)} className="mono-text number-text" /></td>
      case 'monthly_sales':
        return <td key={key}><MonthlySalesByYear monthlySales={getProductMonthlySales(product)} /></td>
      case 'orderboard_classification':
        return <td key={key} className="centered-table-cell"><DisplayText value={formatClassification(product.orderboard_classification)} className="classification-text centered-cell-text" /></td>
      case 'floor':
        return <td key={key} className="centered-table-cell">{renderTextCell(product, draft, 'floor', { className: 'centered-cell-text', inputClassName: 'floor-input' })}</td>
      case 'special_notes':
        return <td key={key}>{renderTextCell(product, draft, 'special_notes', { className: 'note-text', multiline: true, placeholder: '2行目' })}</td>
      case 'picking_advice':
        return <td key={key}>{renderTextCell(product, draft, 'picking_advice', { className: 'note-text', multiline: true, placeholder: '3行目' })}</td>
      case 'delivery_line_4':
        return <td key={key}>{renderTextCell(product, draft, 'delivery_line_4', { className: 'note-text', multiline: true, placeholder: '4行目' })}</td>
      case 'rack_number':
        return <td key={key} className="centered-table-cell">{renderTextCell(product, draft, 'rack_number', { className: 'centered-cell-text', inputClassName: 'rack-input' })}</td>
      case 'rack_level':
        return <td key={key} className="centered-table-cell">{renderTextCell(product, draft, 'rack_level', { className: 'centered-cell-text', inputClassName: 'rack-level-input' })}</td>
      case 'sticker_color':
        return <td key={key} className="centered-table-cell">{renderTextCell(product, draft, 'sticker_color', { className: 'centered-cell-text', inputClassName: 'sticker-input' })}</td>
      case 'shipping_floor':
        return <td key={key} className="centered-table-cell">{renderTextCell(product, draft, 'shipping_floor', { className: 'centered-cell-text', inputClassName: 'small-text-input' })}</td>
      case 'paper_sort_sub':
        return <td key={key} className="centered-table-cell">{renderPaperSortSubCell(product, draft)}</td>
      case 'delivery_preview':
        return <td key={key}>{renderDeliveryPreviewButton(product, draft)}</td>
      case 'order_memo_1':
        return <td key={key}>{renderOrderMemoCell(product, draft, 'order_memo_1', 'rakumart_url_1')}</td>
      case 'order_memo_2':
        return <td key={key}>{renderOrderMemoCell(product, draft, 'order_memo_2', 'rakumart_url_2')}</td>
      case 'order_memo_3':
        return <td key={key}>{renderOrderMemoCell(product, draft, 'order_memo_3', 'rakumart_url_3')}</td>
      case 'order_memo_4':
        return <td key={key}>{renderOrderMemoCell(product, draft, 'order_memo_4', 'rakumart_url_4')}</td>
      case 'order_memo_5':
        return <td key={key}>{renderOrderMemoCell(product, draft, 'order_memo_5', 'rakumart_url_5')}</td>
      case 'order_url_1':
        return <td key={key}>{renderUrlTextCell(product, draft, 'order_url_1')}</td>
      case 'order_url_2':
        return <td key={key}>{renderUrlTextCell(product, draft, 'order_url_2')}</td>
      case 'order_url_3':
        return <td key={key}>{renderUrlTextCell(product, draft, 'order_url_3')}</td>
      case 'order_size':
        return <td key={key}>{renderTextCell(product, draft, 'order_size', { inputClassName: 'small-text-input' })}</td>
      case 'order_color':
        return <td key={key}>{renderTextCell(product, draft, 'order_color', { inputClassName: 'small-text-input' })}</td>
      case 'order_simple_instruction':
        return <td key={key}>{renderTextCell(product, draft, 'order_simple_instruction', { className: 'note-text', multiline: true, placeholder: '■簡潔指示' })}</td>
      case 'order_detail_instruction':
        return <td key={key}>{renderTextCell(product, draft, 'order_detail_instruction', { className: 'note-text', multiline: true, placeholder: '▲具体指示' })}</td>
      case 'order_quantity_condition':
        return <td key={key}>{renderTextCell(product, draft, 'order_quantity_condition', { className: 'note-text', multiline: true, placeholder: '数量条件指定' })}</td>
      case 'order_note':
        return <td key={key}>{renderTextCell(product, draft, 'order_note', { className: 'note-text', multiline: true, placeholder: '補足情報' })}</td>
      case 'order_out':
        return <td key={key} className="centered-table-cell">{renderOrderExclusionFlagCell(product, draft, 'order_out', 'out')}</td>
      case 'no_1688_shop':
        return <td key={key} className="centered-table-cell">{renderOrderExclusionFlagCell(product, draft, 'no_1688_shop', '1688ショップなし')}</td>
      case 'product_info_synced_at':
        return <td key={key}>{formatDateTime(product.product_info_synced_at)}</td>
      case 'order_status_synced_at':
        return <td key={key}>{formatDateTime(product.order_status_synced_at)}</td>
      case 'updated_at':
        return <td key={key}>{formatDateTime(product.updated_at)}</td>
      default:
        return <td key={key} />
    }
  }

  function renderCustomColumns(product: Product, draft: EditableProduct) {
    return <>{customViewColumnSpecs.map((column) => renderCellByKey(column.key, product, draft))}</>
  }

  function toggleCustomColumn(key: string) {
    setCustomColumnKeys((prev) =>
      prev.includes(key) ? prev.filter((item) => item !== key) : [...prev, key],
    )
  }

  const tableColSpan = currentColumnSpecs.length + 1 + (isEditMode ? 2 : 0)
  const customColumnKeySet = new Set(customColumnKeys)
  const customViewColumnSpecs = customColumnCandidates.filter((column) => customColumnKeySet.has(column.key))

  function renderSelectAllCheckbox() {
    return (
      <input
        type="checkbox"
        className="row-select-checkbox"
        ref={(element) => {
          if (element) {
            element.indeterminate = someFilteredSelected
          }
        }}
        checked={allFilteredSelected}
        onChange={toggleAllFilteredSelection}
        disabled={filteredProducts.length === 0 || Boolean(savingCode)}
        title={`表示中の商品（検索結果 全${filteredProducts.length}件）をすべて${allFilteredSelected ? '選択解除' : '選択'}`}
        aria-label="表示中の商品をすべて選択"
      />
    )
  }
  const dirtyEditingCount = useMemo(() => {
    if (!isEditMode) {
      return 0
    }

    let count = 0

    editingCodes.forEach((code) => {
      const product = productByCode.get(code)
      const draft = rowDrafts[code]

      if (product && ((draft && isDraftDirty(product, draft)) || imageDrafts[code])) {
        count += 1
      }
    })

    return count
  }, [isEditMode, editingCodes, productByCode, rowDrafts, imageDrafts])
  const tableClassName = `products-table products-table--${tableView}`

  if (!user) {
    return (
      <main className="login-page">
        <section className="login-card login-card--simple">
          <img src={`${import.meta.env.BASE_URL}login-logo.png`} alt="Shohin DB" className="login-logo" />

          <div className="form-stack login-form-stack">
            <label>
              {authQuestion}
              <input
                type="password"
                value={secretAnswer}
                onChange={(e) => setSecretAnswer(e.target.value)}
                placeholder="回答を入力"
                autoComplete="current-password"
                onKeyDown={(event) => {
                  if (event.key === 'Enter') login()
                }}
              />
            </label>

            <button onClick={login} disabled={loading}>
              {loading ? 'ログイン中...' : 'ログイン'}
            </button>

            {message && <p className="message">{message}</p>}
          </div>
        </section>
      </main>
    )
  }

  return (
    <main className="app-page">
      <header className="topbar">
        <div className="topbar-brand">
          <img
            src={`${import.meta.env.BASE_URL}login-logo.png`}
            alt="商品DB"
            className="topbar-logo"
          />
        </div>

        <div className="topbar-actions">
          <div className="topbar-ne-group">
            <button
              type="button"
              className="topbar-ne-button"
              onClick={() => setIsNeSyncPanelOpen(true)}
              aria-haspopup="dialog"
              aria-expanded={isNeSyncPanelOpen}
            >
              <span className="ne-button-logo-badge" aria-hidden="true">
                <img src={`${import.meta.env.BASE_URL}ne-logo.png`} alt="" />
              </span>
              <span>NE取得</span>
            </button>
            <button
              type="button"
              className="column-settings-button"
              ref={columnWidthMenuButtonRef}
              onClick={() => setIsColumnWidthMenuOpen((open) => !open)}
              aria-haspopup="menu"
              aria-expanded={isColumnWidthMenuOpen}
              aria-label="表示設定（推奨幅・カスタム列）"
              title="表示設定（推奨幅・カスタム列）"
            >
              ⚙
            </button>
            {isColumnWidthMenuOpen && (
              <div
                className="column-settings-menu"
                role="menu"
                aria-label="列幅設定"
                ref={columnWidthMenuRef}
              >
                <div className="column-settings-menu-head">
                  <div className="column-settings-tabs" role="tablist" aria-label="表示設定">
                    <button
                      type="button"
                      role="tab"
                      aria-selected={columnSettingsTab === 'width'}
                      className={columnSettingsTab === 'width' ? 'column-settings-tab active' : 'column-settings-tab'}
                      onClick={() => setColumnSettingsTab('width')}
                    >
                      推奨幅
                    </button>
                    <button
                      type="button"
                      role="tab"
                      aria-selected={columnSettingsTab === 'custom'}
                      className={columnSettingsTab === 'custom' ? 'column-settings-tab active' : 'column-settings-tab'}
                      onClick={() => setColumnSettingsTab('custom')}
                    >
                      カスタム列
                    </button>
                  </div>
                  <button
                    type="button"
                    className="column-settings-close"
                    onClick={() => setIsColumnWidthMenuOpen(false)}
                    aria-label="列幅設定を閉じる"
                  >
                    ×
                  </button>
                </div>

                {columnSettingsTab === 'width' ? (
                  <>
                    <p className="column-settings-description">
                      表示中のビュー（{VIEW_LABELS[tableView]}）の推奨幅。Supabaseで共有します。
                    </p>
                    <div className="column-width-list">
                      <div className="column-width-list-head" aria-hidden="true">
                        <span>列名</span>
                        <span>推奨幅</span>
                        <span>現在</span>
                      </div>
                      {currentColumnSpecs.map((column) => {
                        const recommendedWidthInput = getRecommendedColumnWidthInput(column)
                        const currentWidth = getColumnWidth(column)

                        return (
                          <label className="column-width-row" key={column.key}>
                            <span className="column-width-label" title={column.label}>
                              {column.label}
                            </span>
                            <input
                              type="text"
                              inputMode="numeric"
                              pattern="[0-9]*"
                              value={recommendedWidthInput}
                              onChange={(event) => updateRecommendedColumnWidthInput(column, event.target.value)}
                              onBlur={() => commitRecommendedColumnWidthInput(column)}
                              onKeyDown={(event) => {
                                if (event.key === 'Enter') {
                                  event.currentTarget.blur()
                                }
                              }}
                              disabled={sharedColumnWidthsLoading || sharedColumnWidthsSaving}
                              aria-label={`${column.label}の推奨幅`}
                            />
                            <span className="column-width-current">{currentWidth}px</span>
                          </label>
                        )
                      })}
                    </div>

                    <div className="column-settings-actions">
                      <button
                        type="button"
                        className="secondary"
                        onClick={captureCurrentWidthsAsRecommended}
                        disabled={sharedColumnWidthsLoading || sharedColumnWidthsSaving}
                        role="menuitem"
                      >
                        現在の幅を共有へ反映
                      </button>
                      <button
                        type="button"
                        className="secondary"
                        onClick={saveEditedRecommendedWidths}
                        disabled={sharedColumnWidthsLoading || sharedColumnWidthsSaving || !sharedColumnWidthsDirty}
                        role="menuitem"
                      >
                        {sharedColumnWidthsSaving ? '共有保存中' : '数値を共有保存'}
                      </button>
                      <button
                        type="button"
                        onClick={applyRecommendedColumnWidths}
                        disabled={sharedColumnWidthsLoading || sharedColumnWidthsSaving}
                        role="menuitem"
                      >
                        共有推奨幅を適用
                      </button>
                    </div>
                    <small>
                      {sharedColumnWidthsLoading
                        ? '共有推奨幅を取得しています…'
                        : `入力中は補正しません。確定時に${MIN_COLUMN_WIDTH}〜${MAX_COLUMN_WIDTH}pxへ補正します。現在幅はこのPCに保存されます。`}
                    </small>
                  </>
                ) : (
                  <>
                    <p className="column-settings-description">
                      「カスタム」ビューに出す列を選びます（画像・商品コードは固定）。このPCに保存されます。
                    </p>
                    <div className="custom-column-list">
                      {customColumnCandidates.map((column) => (
                        <label className="custom-column-row" key={column.key}>
                          <input
                            type="checkbox"
                            checked={customColumnKeySet.has(column.key)}
                            onChange={() => toggleCustomColumn(column.key)}
                          />
                          <span>{column.label}</span>
                        </label>
                      ))}
                    </div>
                    <div className="column-settings-actions">
                      <button
                        type="button"
                        className="secondary"
                        onClick={() => setCustomColumnKeys(customColumnCandidates.map((column) => column.key))}
                      >
                        すべて選択
                      </button>
                      <button type="button" className="secondary" onClick={() => setCustomColumnKeys([])}>
                        すべて解除
                      </button>
                      <button type="button" className="secondary" onClick={() => setCustomColumnKeys(DEFAULT_CUSTOM_COLUMN_KEYS)}>
                        初期値に戻す
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setTableView('custom')
                          setIsColumnWidthMenuOpen(false)
                        }}
                      >
                        カスタムを表示
                      </button>
                    </div>
                    <small>選択中 {customViewColumnSpecs.length} / {customColumnCandidates.length} 列。並び順は「すべて」ビューと同じです。</small>
                  </>
                )}
              </div>
            )}
          </div>
          <span>{user.email}</span>
          <button className="secondary" onClick={logout}>
            ログアウト
          </button>
        </div>
      </header>

      <section className="toolbar">
        <div className="search-group">
          <div className="search-box">
            <input
              value={keyword}
              onChange={(e) => setKeyword(e.target.value)}
              placeholder="商品コード・商品名・2行目・3行目・棚番号で検索"
            />
            <button
              type="button"
              className="search-clear-button"
              onClick={() => {
                setKeyword('')
                setDebouncedKeyword('')
              }}
              disabled={!keyword}
            >
              クリア
            </button>
          </div>

          <div className="search-box search-box--suffix">
            <input
              value={suffixKeyword}
              onChange={(e) => setSuffixKeyword(e.target.value)}
              placeholder="商品コード・商品名でさらに絞り込み（例：20mm）"
              title="商品コードまたは商品名に含まれる文字で絞り込みます。左の検索と組み合わせるとAND条件になります。"
            />
            <button
              type="button"
              className="search-clear-button"
              onClick={() => {
                setSuffixKeyword('')
                setDebouncedSuffixKeyword('')
              }}
              disabled={!suffixKeyword}
            >
              クリア
            </button>
          </div>
        </div>

        <button className="utility-button" onClick={fetchProducts} disabled={loading || Boolean(savingCode)}>
          再読み込み
        </button>

        <button className="secondary utility-button" onClick={openImageImportModal}>画像インポート</button>

        <button className="primary-action-button" onClick={openCreateModal}>一括追加/更新</button>
      </section>

      {isNeSyncPanelOpen && (
        <div
          className="ne-sync-modal-backdrop"
          role="presentation"
          onDoubleClick={closeOnBackdropDoubleClick(() => setIsNeSyncPanelOpen(false))}
        >
          <aside className="ne-sync-modal" role="dialog" aria-modal="true" aria-label="NE取得">
            <div className="ne-sync-modal-header">
              <div>
                <strong>NE取得</strong>
                <span>取得項目・対象年月を選んでNEからSupabaseへ反映</span>
              </div>
              <button type="button" className="secondary small" onClick={() => setIsNeSyncPanelOpen(false)}>
                閉じる
              </button>
            </div>

            <div className="ne-sync-modal-body">
              <div className="ne-sync-auth-note ne-sync-auth-note--modal">
                Supabase Authのログイン状態でNE取得します。ADMIN_TOKENの入力は不要です。
              </div>

              <div className="ne-sync-actions ne-sync-actions--modal">
                <button type="button" className="secondary small" onClick={fetchNeUsage} disabled={neSyncLoading}>
                  利用回数
                </button>
                <button type="button" className="secondary small" onClick={() => syncNeOperationalFields(true)} disabled={neSyncLoading}>
                  dry-run
                </button>
                <button
                  type="button"
                  className="small ne-sync-primary-button"
                  onClick={() => syncNeOperationalFields(false)}
                  disabled={neSyncLoading}
                >
                  <span className="ne-button-logo-badge ne-button-logo-badge--small" aria-hidden="true">
                    <img src={`${import.meta.env.BASE_URL}ne-logo.png`} alt="" />
                  </span>
                  <span>NE取得</span>
                </button>
              </div>

              {(neSyncMessage || neUsage || neSyncResult || neMonthlyResult) && (
                <div className="ne-sync-status ne-sync-status--modal">
                  {neSyncMessage && <strong>{neSyncMessage}</strong>}
                  {neUsage && (
                    <span>利用：{neUsage.callCount ?? 0}回 / 残り{neUsage.remainingCalls ?? '-'}回 / {neUsage.estimatedGb ?? 0}GB</span>
                  )}
                  {neSyncResult && (
                    <span>NE情報：在庫{neSyncResult.stockFetched ?? 0}件・商品{neSyncResult.goodsFetched ?? 0}件 / 一致{neSyncResult.matched ?? 0}件 / 更新{neSyncResult.updated ?? 0}件</span>
                  )}
                  {neMonthlyResult && (
                    <span>月別受注数：{neMonthlyResult.months?.join('・') || '-'} / 明細{neMonthlyResult.rowFetched ?? 0}行 / 一致{neMonthlyResult.matched ?? 0}件 / 更新{neMonthlyResult.updated ?? 0}件</span>
                  )}
                </div>
              )}

              <div className="ne-sync-detail-grid">
                <div className="ne-sync-field-box">
                  <strong>取得項目</strong>
                  <div className="ne-sync-checks">
                    <label>
                      <input
                        type="checkbox"
                        checked={neSyncFields.freeStock}
                        onChange={(event) => updateNeSyncField('freeStock', event.target.checked)}
                      />
                      フリー在庫
                    </label>
                    <label>
                      <input
                        type="checkbox"
                        checked={neSyncFields.reorderPoint}
                        onChange={(event) => updateNeSyncField('reorderPoint', event.target.checked)}
                      />
                      発注点
                    </label>
                    <label>
                      <input
                        type="checkbox"
                        checked={neSyncFields.stockConstant}
                        onChange={(event) => updateNeSyncField('stockConstant', event.target.checked)}
                      />
                      在庫定数
                    </label>
                    <label>
                      <input
                        type="checkbox"
                        checked={neSyncFields.monthlySales}
                        onChange={(event) => updateNeSyncField('monthlySales', event.target.checked)}
                      />
                      月別受注数
                    </label>
                  </div>
                </div>

                {neSyncFields.monthlySales && (
                  <div className="ne-sync-month-box">
                    <div className="ne-sync-month-toolbar">
                      <strong>月別受注数の対象年月</strong>
                      <button type="button" className="secondary small" onClick={() => selectRecentNeMonths(1)} disabled={neSyncLoading}>
                        今月
                      </button>
                      <button type="button" className="secondary small" onClick={() => selectRecentNeMonths(3)} disabled={neSyncLoading}>
                        直近3か月
                      </button>
                      <button type="button" className="secondary small" onClick={() => selectRecentNeMonths(12)} disabled={neSyncLoading}>
                        直近12か月
                      </button>
                      <button type="button" className="secondary small" onClick={() => setSelectedNeMonths([])} disabled={neSyncLoading}>
                        クリア
                      </button>
                    </div>

                    <div className="ne-sync-month-groups">
                      {neMonthGroups.map((group) => (
                        <div key={group.year} className="ne-sync-month-group">
                          <span>{group.year}</span>
                          {group.months.map((key) => {
                            const month = key.slice(5, 7)
                            return (
                              <label key={key}>
                                <input
                                  type="checkbox"
                                  checked={selectedNeMonths.includes(key)}
                                  onChange={(event) => toggleNeSyncMonth(key, event.target.checked)}
                                />
                                {month}月
                              </label>
                            )
                          })}
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </aside>
        </div>
      )}

      {message && (
        <div className="toast-message" role="status" aria-live="polite">
          {message}
        </div>
      )}

      <section className="layout layout--full">
        <div className="table-card">
          <div className="table-header">
            <div className="table-title">
              <strong>商品一覧</strong>
            </div>

            <div className="view-switch" aria-label="表示用途切り替え">
              <ViewButton active={tableView === 'order'} onClick={() => setTableView('order')}>
                オーダー状況
              </ViewButton>
              <ViewButton active={tableView === 'purchase'} onClick={() => setTableView('purchase')}>
                オーダー用
              </ViewButton>
              <ViewButton active={tableView === 'pick'} onClick={() => setTableView('pick')}>
                紙出し用
              </ViewButton>
              <ViewButton active={tableView === 'ne'} onClick={() => setTableView('ne')}>
                NE情報
              </ViewButton>
              <ViewButton active={tableView === 'custom'} onClick={() => setTableView('custom')}>
                カスタム
              </ViewButton>
              <ViewButton active={tableView === 'all'} onClick={() => setTableView('all')}>
                すべて
              </ViewButton>
            </div>

            <div className="table-pager" aria-label="商品一覧ページ送り">
              <button
                type="button"
                className="pager-button"
                onClick={() => setCurrentPage(1)}
                disabled={currentPageNumber <= 1}
              >
                最初
              </button>
              <button
                type="button"
                className="pager-button"
                onClick={() => setCurrentPage((page) => Math.max(1, page - 1))}
                disabled={currentPageNumber <= 1}
              >
                前へ
              </button>
              <span className="pager-status">
                {currentPageNumber} / {totalPages}
              </span>
              <button
                type="button"
                className="pager-button"
                onClick={() => setCurrentPage((page) => Math.min(totalPages, page + 1))}
                disabled={currentPageNumber >= totalPages}
              >
                次へ
              </button>
              <button
                type="button"
                className="pager-button"
                onClick={() => setCurrentPage(totalPages)}
                disabled={currentPageNumber >= totalPages}
              >
                最後
              </button>
              <span className="pager-range">
                {pagerRangeText}
              </span>
            </div>

            <div className="table-actions">
              {isEditMode && (
                <span className="edit-mode-status">
                  選択 {editingCodes.size}件 / 未保存 {dirtyEditingCount}件
                </span>
              )}
              <button
                type="button"
                className={`small bulk-edit-button ${isEditMode ? 'secondary end-edit-button' : 'edit-button'}`}
                onClick={isEditMode ? endEditMode : enterEditMode}
                disabled={Boolean(savingCode) || (!isEditMode && products.length === 0)}
              >
                {isEditMode ? '編集終了' : '編集モード'}
              </button>
              <button
                type="button"
                className="small edit-button select-all-edit-button"
                onClick={startBulkEdit}
                disabled={
                  Boolean(savingCode) ||
                  filteredProducts.length === 0 ||
                  (isEditMode && allFilteredSelected)
                }
                title="検索結果をすべて選択した状態で編集モードにします"
              >
                一括編集
              </button>
              {isEditMode && (
                <>
                  <button
                    type="button"
                    className="small save-button save-all-button"
                    onClick={saveAllEdits}
                    disabled={dirtyEditingCount === 0 || Boolean(savingCode)}
                  >
                    {savingCode === '__bulk_save__' ? '保存中' : 'すべて保存'}
                  </button>
                  <button
                    type="button"
                    className="secondary small cancel-button cancel-all-button"
                    onClick={cancelAllEdits}
                    disabled={dirtyEditingCount === 0 || Boolean(savingCode)}
                  >
                    すべて元に戻す
                  </button>
                </>
              )}
            </div>

          </div>

          <div className="table-wrap">
            <table className={tableClassName} style={tableStyle}>
              <colgroup>
                {isEditMode && <col key="__select__" style={{ width: `${SELECT_COLUMN_WIDTH}px` }} />}
                {dataColumnSpecs.map((column) => (
                  <col key={column.key} style={{ width: `${getColumnWidth(column)}px` }} />
                ))}
                {actionColumnSpec && (
                  <col key={actionColumnSpec.key} style={{ width: `${getColumnWidth(actionColumnSpec)}px` }} />
                )}
                {isEditMode && <col key="__select_right__" style={{ width: `${SELECT_COLUMN_WIDTH}px` }} />}
                {/* 列幅の合計が画面幅より狭いとき、表の一番右で余白を埋めるだけの列 */}
                <col key="__filler__" className="filler-col" />
              </colgroup>
              <thead>
                <tr>
                  {isEditMode && (
                    <th className="select-cell sticky-select-cell">{renderSelectAllCheckbox()}</th>
                  )}
                  {dataColumnSpecs.map((column) => renderColumnHeader(column))}
                  {actionColumnSpec && renderColumnHeader(actionColumnSpec)}
                  {isEditMode && (
                    <th className="select-cell sticky-select-cell-right">{renderSelectAllCheckbox()}</th>
                  )}
                  <th className="filler-cell" aria-hidden="true" />
                </tr>
              </thead>

              <tbody>
                {pagedProducts.map((product) => {
                  const draft = rowDrafts[product.product_code] ?? productToDraft(product)
                  const isEditing = editingCodes.has(product.product_code)
                  const dirty = isEditing && hasRowChanges(product, draft)

                  return (
                    <tr
                      key={product.product_code}
                      className={`${isEditing ? 'is-editing' : ''} ${dirty ? 'is-dirty' : ''}`}
                      onDoubleClick={(event) => handleRowDoubleClick(product, event)}
                    >
                      {isEditMode && (
                        <td className="select-cell sticky-select-cell">
                          <input
                            type="checkbox"
                            className="row-select-checkbox"
                            checked={isEditing}
                            onChange={(event) => setRowsSelected([product], event.target.checked)}
                            disabled={Boolean(savingCode)}
                            aria-label={`${product.product_code} を編集対象にする`}
                          />
                        </td>
                      )}
                      <td className="image-cell sticky-image-cell">
                        <ProductImageCell
                          product={product}
                          version={imageCacheVersion}
                          isEditing={isEditing}
                          draftImage={imageDrafts[product.product_code]}
                          onPreview={setImagePreview}
                          onImageFilesDrop={setRowImageDraft}
                        />
                      </td>

                      <td className="code sticky-code-cell">
                        <button
                          type="button"
                          className="code-copy"
                          onClick={() => copyProductCode(product.product_code)}
                          title="商品コードをコピー"
                        >
                          {product.product_code}
                        </button>
                      </td>

                      {tableView === 'all' && renderAllColumns(product, draft)}
                      {tableView === 'pick' && renderPickColumns(product, draft)}
                      {tableView === 'order' && renderOrderColumns(product, draft)}
                      {tableView === 'purchase' && renderPurchaseColumns(product, draft)}
                      {tableView === 'ne' && renderNeColumns(product, draft)}
                      {tableView === 'custom' && renderCustomColumns(product, draft)}

                      {showActionsColumn && (
                        <td className="sticky-actions-cell">{renderActions(product, draft)}</td>
                      )}
                      {isEditMode && (
                        <td className="select-cell sticky-select-cell-right">
                          <input
                            type="checkbox"
                            className="row-select-checkbox"
                            checked={isEditing}
                            onChange={(event) => setRowsSelected([product], event.target.checked)}
                            disabled={Boolean(savingCode)}
                            aria-label={`${product.product_code} を編集対象にする`}
                          />
                        </td>
                      )}
                      <td className="filler-cell" aria-hidden="true" />
                    </tr>
                  )
                })}

                {filteredProducts.length === 0 && (
                  <tr>
                    <td colSpan={tableColSpan} className="empty">
                      商品がありません。
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </section>


      {bulkColumnEdit && (
        <div className="modal-backdrop" onDoubleClick={closeOnBackdropDoubleClick(() => setBulkColumnEdit(null))}>
          <section
            className="modal-card bulk-column-modal"
            role="dialog"
            aria-modal="true"
            aria-label={`${bulkColumnEdit.config.label}を一括入力`}
            onClick={(event) => event.stopPropagation()}
            onKeyDown={(event) => {
              if (event.key === 'Escape') {
                setBulkColumnEdit(null)
              }
            }}
          >
            <h2>「{bulkColumnEdit.config.label}」を一括入力</h2>
            <p className="bulk-column-target">
              チェック中の <strong>{editingCodes.size}件</strong> に適用します
              {editingCodes.size > filteredSelectedCount && (
                <span className="bulk-column-warning">
                  （うち{editingCodes.size - filteredSelectedCount}件は現在の検索結果に表示されていません）
                </span>
              )}
            </p>

            {bulkColumnEdit.config.kind === 'boolean' ? (
              <div className="bulk-column-bool">
                <label>
                  <input
                    type="radio"
                    name="bulk-column-bool"
                    checked={bulkColumnEdit.boolValue}
                    onChange={() => setBulkColumnEdit({ ...bulkColumnEdit, boolValue: true })}
                  />
                  ON（チェックあり）
                </label>
                <label>
                  <input
                    type="radio"
                    name="bulk-column-bool"
                    checked={!bulkColumnEdit.boolValue}
                    onChange={() => setBulkColumnEdit({ ...bulkColumnEdit, boolValue: false })}
                  />
                  OFF（チェックなし）
                </label>
              </div>
            ) : (
              <div className="bulk-column-fields">
                {bulkColumnEdit.config.kind === 'order_memo' && (
                  <label className="bulk-column-apply">
                    <input
                      type="checkbox"
                      checked={bulkColumnEdit.applyMain}
                      onChange={(event) =>
                        setBulkColumnEdit({ ...bulkColumnEdit, applyMain: event.target.checked })
                      }
                    />
                    {bulkColumnEdit.config.label}を上書きする
                  </label>
                )}
                {bulkColumnEdit.config.kind === 'multiline' ? (
                  <textarea
                    className="bulk-column-input"
                    value={bulkColumnEdit.value}
                    autoFocus
                    rows={4}
                    onChange={(event) => setBulkColumnEdit({ ...bulkColumnEdit, value: event.target.value })}
                    placeholder="入力する値（空欄のまま適用すると空になります）"
                  />
                ) : (
                  <input
                    className="bulk-column-input"
                    value={bulkColumnEdit.value}
                    autoFocus
                    disabled={bulkColumnEdit.config.kind === 'order_memo' && !bulkColumnEdit.applyMain}
                    onChange={(event) => setBulkColumnEdit({ ...bulkColumnEdit, value: event.target.value })}
                    onKeyDown={(event) => {
                      if (event.key === 'Enter' && !event.nativeEvent.isComposing) {
                        event.preventDefault()
                        applyBulkColumnEdit()
                      }
                    }}
                    placeholder="入力する値（空欄のまま適用すると空になります）"
                  />
                )}

                {bulkColumnEdit.config.kind === 'order_memo' && bulkColumnEdit.config.urlKey && (
                  <>
                    <label className="bulk-column-apply">
                      <input
                        type="checkbox"
                        checked={bulkColumnEdit.applyUrl}
                        onChange={(event) =>
                          setBulkColumnEdit({ ...bulkColumnEdit, applyUrl: event.target.checked })
                        }
                      />
                      {EDIT_FIELD_PLACEHOLDERS[bulkColumnEdit.config.urlKey]}も上書きする
                    </label>
                    <input
                      className="bulk-column-input"
                      value={bulkColumnEdit.urlValue}
                      disabled={!bulkColumnEdit.applyUrl}
                      onChange={(event) => setBulkColumnEdit({ ...bulkColumnEdit, urlValue: event.target.value })}
                      placeholder="URL（空欄のまま適用すると空になります）"
                    />
                  </>
                )}
              </div>
            )}

            <div className="bulk-column-actions">
              <button type="button" className="secondary" onClick={() => setBulkColumnEdit(null)}>
                キャンセル
              </button>
              <button
                type="button"
                className="save-button"
                onClick={applyBulkColumnEdit}
                disabled={
                  bulkColumnEdit.config.kind === 'order_memo' &&
                  !bulkColumnEdit.applyMain &&
                  !bulkColumnEdit.applyUrl
                }
              >
                {editingCodes.size}件に適用
              </button>
            </div>
          </section>
        </div>
      )}

      {isImageImportModalOpen && (
        <div className="modal-backdrop" onDoubleClick={closeOnBackdropDoubleClick(closeImageImportModal)}>
          <section
            className="modal-card image-import-modal"
            role="dialog"
            aria-modal="true"
            aria-label="商品画像インポート"
            onClick={(event) => event.stopPropagation()}
          >
            <div className="modal-head">
              <div>
                <p className="eyebrow">Product Images</p>
                <h2>商品画像インポート</h2>
              </div>

              <button className="secondary small" onClick={closeImageImportModal} disabled={imageImporting}>
                閉じる
              </button>
            </div>

            <div className="modal-body">
              <div
                className={isImageDragOver ? 'image-import-drop is-drag-over' : 'image-import-drop'}
                onDragOver={handleImageDragOver}
                onDragLeave={handleImageDragLeave}
                onDrop={handleImageDrop}
              >
                <div>
                  <strong>商品コード付き画像をまとめて取り込み</strong>
                  <span>ファイル名から商品コードを判定し、jpg / png / webp をWebPへ変換して product-images に上書きアップロードします。</span>
                </div>

                <label className="csv-upload-button">
                  画像を選択
                  <input
                    type="file"
                    accept={PRODUCT_IMAGE_ACCEPT}
                    multiple
                    onChange={handleImageFileSelect}
                  />
                </label>
              </div>

              <div className="image-import-summary">
                <span>選択中：{imageFiles.length}件</span>
                <span>保存先：{PRODUCT_IMAGE_BUCKET}</span>
                <span>保存形式：商品コード.webp</span>
              </div>

              {imageImportMessage && <p className="modal-message">{imageImportMessage}</p>}

              <div className="modal-actions">
                <button className="save-button" onClick={uploadProductImages} disabled={imageImporting || imageFiles.length === 0}>
                  {imageImporting ? 'アップロード中...' : `${imageFiles.length}件をアップロード`}
                </button>

                <button className="secondary" onClick={closeImageImportModal} disabled={imageImporting}>
                  キャンセル
                </button>
              </div>
            </div>
          </section>
        </div>
      )}

      {imagePreview && (
        <div className="modal-backdrop" onDoubleClick={closeOnBackdropDoubleClick(() => setImagePreview(null))}>
          <section
            className="image-preview-card"
            role="dialog"
            aria-modal="true"
            aria-label="商品画像プレビュー"
            onClick={(event) => event.stopPropagation()}
          >
            <div className="image-preview-head">
              <div>
                <strong>{imagePreview.productCode}</strong>
                <span>{imagePreview.productName || '商品名なし'}</span>
              </div>

              <button className="secondary small" onClick={() => setImagePreview(null)}>
                閉じる
              </button>
            </div>

            <img src={imagePreview.url} alt={imagePreview.productName || imagePreview.productCode} />
          </section>
        </div>
      )}

      {deliverySlipPreview && (
        <div className="modal-backdrop" onDoubleClick={closeOnBackdropDoubleClick(() => setDeliverySlipPreview(null))}>
          <section
            className="modal-card delivery-preview-modal"
            role="dialog"
            aria-modal="true"
            aria-label="納品書プレビュー"
            onClick={(event) => event.stopPropagation()}
          >
            <div className="modal-head delivery-preview-head">
              <div>
                <p className="eyebrow">Builder Preview</p>
                <h2>納品書プレビュー</h2>
                <span>{deliverySlipPreview.productCode}</span>
              </div>

              <button className="secondary small" onClick={() => setDeliverySlipPreview(null)}>
                閉じる
              </button>
            </div>


            <DeliverySlipPreview preview={deliverySlipPreview} />
          </section>
        </div>
      )}

      {rakumartRecipeModal && (
        <div className="modal-backdrop" onDoubleClick={closeOnBackdropDoubleClick(closeRakumartRecipe)}>
          <section
            className="modal-card rakumart-recipe-modal"
            role="dialog"
            aria-modal="true"
            aria-label="発注レシピ"
            onClick={(event) => event.stopPropagation()}
          >
            <div className="modal-head rakumart-recipe-head">
              <div>
                <p className="eyebrow">Rakumart Order Recipe</p>
                <h2>発注レシピ</h2>
                <div className="rakumart-recipe-product-ident">
                  <strong>{rakumartRecipeModal.product.product_code}</strong>
                  <span>{rakumartRecipeModal.product.product_name || '商品名なし'}</span>
                </div>
              </div>

              <button
                type="button"
                className="secondary small"
                onClick={closeRakumartRecipe}
                disabled={rakumartRecipeSaving}
              >
                閉じる
              </button>
            </div>

            {rakumartRecipeLoading ? (
              <div className="rakumart-recipe-loading">発注レシピを読み込んでいます...</div>
            ) : (
              <div className="rakumart-recipe-body">
                <section className="rakumart-legacy-reference">
                  <div className="rakumart-section-head">
                    <div>
                      <strong>既存の発注情報</strong>
                      <span>参照用です。この欄の値は発注レシピ保存では変更しません。</span>
                    </div>
                  </div>

                  <div className="rakumart-legacy-grid">
                    <div className="rakumart-legacy-links">
                      <span className="rakumart-field-label">発注URL</span>
                      {[rakumartRecipeModal.product.order_url_1, rakumartRecipeModal.product.order_url_2, rakumartRecipeModal.product.order_url_3]
                        .map((url, index) => ({ url: String(url ?? '').trim(), index }))
                        .filter((row) => row.url)
                        .map((row) => (
                          <a key={row.index} href={row.url} target="_blank" rel="noreferrer">
                            発注URL{row.index + 1} ↗
                          </a>
                        ))}
                      {!rakumartRecipeModal.product.order_url_1 &&
                        !rakumartRecipeModal.product.order_url_2 &&
                        !rakumartRecipeModal.product.order_url_3 && <span className="muted">なし</span>}
                    </div>

                    <div>
                      <span className="rakumart-field-label">サイズ</span>
                      <p>{rakumartRecipeModal.product.order_size || '—'}</p>
                    </div>

                    <div>
                      <span className="rakumart-field-label">カラー</span>
                      <p>{rakumartRecipeModal.product.order_color || '—'}</p>
                    </div>

                    <div className="rakumart-legacy-instructions">
                      <span className="rakumart-field-label">発注指示</span>
                      {rakumartRecipeModal.product.order_simple_instruction && (
                        <p>{rakumartRecipeModal.product.order_simple_instruction}</p>
                      )}
                      {rakumartRecipeModal.product.order_detail_instruction && (
                        <p>{rakumartRecipeModal.product.order_detail_instruction}</p>
                      )}
                      {rakumartRecipeModal.product.order_quantity_condition && (
                        <p>{rakumartRecipeModal.product.order_quantity_condition}</p>
                      )}
                      {rakumartRecipeModal.product.order_note && (
                        <p>{rakumartRecipeModal.product.order_note}</p>
                      )}
                      {!rakumartRecipeModal.product.order_simple_instruction &&
                        !rakumartRecipeModal.product.order_detail_instruction &&
                        !rakumartRecipeModal.product.order_quantity_condition &&
                        !rakumartRecipeModal.product.order_note && <p>—</p>}
                    </div>
                  </div>
                </section>

                {!rakumartRecipeModal.exists && (
                  <section className="rakumart-recipe-settings">
                    <div className="rakumart-section-head">
                      <div>
                        <strong>初回レシピ作成</strong>
                        <span>既存の商品DB情報から、初回だけたたき台を作れます。自動保存はしません。</span>
                      </div>
                    </div>

                    {getRakumartLegacyOrderUrls(rakumartRecipeModal.product).length === 0 ? (
                      <p className="muted">発注URL1〜3が未登録のため、手動でレシピを作成してください。</p>
                    ) : getRakumartLegacyOrderUrls(rakumartRecipeModal.product).length === 1 ? (
                      <div className="rakumart-recipe-actions">
                        <span className="muted">発注URLが1件なので、本体1件としてたたき台を生成します。</span>
                        <button
                          type="button"
                          className="secondary small"
                          onClick={() => applyRakumartLegacySeed('separate')}
                        >
                          既存情報から再生成
                        </button>
                      </div>
                    ) : (
                      <div>
                        <p className="muted">
                          発注URLが複数あります。URL同士の関係だけ選ぶと、構成品・仕入先を自動で組みます。
                        </p>
                        <div className="rakumart-recipe-actions">
                          <button
                            type="button"
                            className={rakumartRecipeModal.legacyRelation === 'separate' ? 'small' : 'secondary small'}
                            onClick={() => applyRakumartLegacySeed('separate')}
                          >
                            全部発注する
                          </button>
                          <button
                            type="button"
                            className={rakumartRecipeModal.legacyRelation === 'alternatives' ? 'small' : 'secondary small'}
                            onClick={() => applyRakumartLegacySeed('alternatives')}
                          >
                            代替仕入先
                          </button>
                          <button
                            type="button"
                            className={rakumartRecipeModal.legacyRelation === 'manual' ? 'small' : 'secondary small'}
                            onClick={() => applyRakumartLegacySeed('manual')}
                          >
                            手動で作る
                          </button>
                        </div>
                      </div>
                    )}
                  </section>
                )}

                <section className="rakumart-recipe-settings">
                  <div className="rakumart-section-head">
                    <div>
                      <strong>実行設定</strong>
                      <span>Playwright側が参照するレシピ全体の設定です。</span>
                    </div>
                  </div>

                  <div className="rakumart-settings-grid">
                    <label className="rakumart-checkbox-card">
                      <input
                        type="checkbox"
                        checked={rakumartRecipeModal.draft.enabled}
                        onChange={(event) =>
                          updateRakumartRecipeDraft((draft) => ({ ...draft, enabled: event.target.checked }))
                        }
                      />
                      <span>
                        <strong>自動発注を有効</strong>
                        <small>OFFならレシピを残したまま実行対象から外せます。</small>
                      </span>
                    </label>

                    <label className="rakumart-checkbox-card">
                      <input
                        type="checkbox"
                        checked={rakumartRecipeModal.draft.stopBeforeSubmit}
                        onChange={(event) =>
                          updateRakumartRecipeDraft((draft) => ({ ...draft, stopBeforeSubmit: event.target.checked }))
                        }
                      />
                      <span>
                        <strong>提出直前で停止</strong>
                        <small>初期運用ではON推奨。最終提出は人が行います。</small>
                      </span>
                    </label>

                    <label className="rakumart-setting-field">
                      <span>備考</span>
                      <select
                        value={rakumartRecipeModal.draft.remarkMode}
                        onChange={(event) =>
                          updateRakumartRecipeDraft((draft) => ({
                            ...draft,
                            remarkMode: event.target.value as RakumartRemarkMode,
                          }))
                        }
                      >
                        <option value="manual">手動入力</option>
                        <option value="template">テンプレート</option>
                        <option value="none">備考なし</option>
                      </select>
                    </label>
                  </div>

                  {rakumartRecipeModal.draft.remarkMode === 'template' && (
                    <label className="rakumart-template-field">
                      <span>備考テンプレート</span>
                      <textarea
                        value={rakumartRecipeModal.draft.remarkTemplate}
                        onChange={(event) =>
                          updateRakumartRecipeDraft((draft) => ({ ...draft, remarkTemplate: event.target.value }))
                        }
                        placeholder="将来、相対番号を取得して自動生成する備考テンプレートを入力"
                      />
                    </label>
                  )}
                </section>

                <section className="rakumart-items-section">
                  <div className="rakumart-section-head rakumart-section-head--actions">
                    <div>
                      <strong>発注構成品</strong>
                      <span>本体＋袋なら2件。同じ商品の代替ショップは同じ構成品内に追加します。</span>
                    </div>
                    <button type="button" className="secondary small recipe-add-button" onClick={addRakumartItem}>
                      ＋ 構成品を追加
                    </button>
                  </div>

                  <div className="rakumart-items-list">
                    {rakumartRecipeModal.draft.items.map((item, itemIndex) => (
                      <article key={item.id} className="rakumart-item-card">
                        <div className="rakumart-item-head">
                          <div className="rakumart-number-title">
                            <span>{itemIndex + 1}</span>
                            <strong>構成品</strong>
                          </div>
                          <button
                            type="button"
                            className="secondary small danger-button"
                            onClick={() => removeRakumartItem(item.id)}
                          >
                            構成品を削除
                          </button>
                        </div>

                        <div className="rakumart-item-fields">
                          <label className="rakumart-grow-field">
                            <span>構成品名</span>
                            <input
                              value={item.itemName}
                              onChange={(event) => updateRakumartItem(item.id, { itemName: event.target.value })}
                              placeholder="例：スカーフ本体 / ジッパー袋"
                            />
                          </label>

                          <label className="rakumart-inline-check">
                            <input
                              type="checkbox"
                              checked={item.required}
                              onChange={(event) => updateRakumartItem(item.id, { required: event.target.checked })}
                            />
                            必須
                          </label>

                          <label className="rakumart-grow-field">
                            <span>構成品メモ</span>
                            <input
                              value={item.memo}
                              onChange={(event) => updateRakumartItem(item.id, { memo: event.target.value })}
                              placeholder="任意"
                            />
                          </label>
                        </div>

                        <div className="rakumart-sources-list">
                          {item.sources.map((source, sourceIndex) => (
                            <section key={source.id} className="rakumart-source-card">
                              <div className="rakumart-source-head">
                                <div>
                                  <strong>
                                    {sourceIndex === 0 ? '仕入先 1（優先）' : `代替仕入先 ${sourceIndex + 1}`}
                                  </strong>
                                  <span>上から優先順。Playwrightは有効な仕入先を優先順位順に使用します。</span>
                                </div>
                                <button
                                  type="button"
                                  className="secondary small danger-button"
                                  onClick={() => removeRakumartSource(item.id, source.id)}
                                >
                                  仕入先を削除
                                </button>
                              </div>

                              <div className="rakumart-source-fields">
                                <label>
                                  <span>仕入先名</span>
                                  <input
                                    value={source.sourceName}
                                    onChange={(event) =>
                                      updateRakumartSource(item.id, source.id, { sourceName: event.target.value })
                                    }
                                    placeholder="任意：メイン / 予備ショップなど"
                                  />
                                </label>

                                <label className="rakumart-source-url-field">
                                  <span>ラクマート商品URL</span>
                                  <input
                                    value={source.url}
                                    onChange={(event) =>
                                      updateRakumartSource(item.id, source.id, { url: event.target.value })
                                    }
                                    placeholder="https://www.rakumart.com/ProductDetails?..."
                                  />
                                </label>

                                <label className="rakumart-inline-check">
                                  <input
                                    type="checkbox"
                                    checked={source.enabled}
                                    onChange={(event) =>
                                      updateRakumartSource(item.id, source.id, { enabled: event.target.checked })
                                    }
                                  />
                                  有効
                                </label>
                              </div>

                              <label className="rakumart-source-memo-field">
                                <span>仕入先メモ</span>
                                <input
                                  value={source.memo}
                                  onChange={(event) =>
                                    updateRakumartSource(item.id, source.id, { memo: event.target.value })
                                  }
                                  placeholder="ショップ固有の注意など（任意）"
                                />
                              </label>

                              <div className="rakumart-lines-wrap">
                                <div className="rakumart-lines-head">
                                  <div>
                                    <strong>発注明細</strong>
                                    <span>1明細 = 1つの規格組み合わせ。規格軸は任意で、数量は「発注予定数 × 数量倍率」です。</span>
                                  </div>
                                  <button
                                    type="button"
                                    className="secondary small recipe-add-button"
                                    onClick={() => addRakumartLine(item.id, source.id)}
                                  >
                                    ＋ 明細を追加
                                  </button>
                                </div>

                                <div className="rakumart-lines-list">
                                  {source.lines.map((line, lineIndex) => (
                                    <div key={line.id} className="rakumart-line-card">
                                      <div className="rakumart-line-head">
                                        <strong>明細 {lineIndex + 1}</strong>
                                        <button
                                          type="button"
                                          className="secondary small danger-button"
                                          onClick={() => removeRakumartLine(item.id, source.id, line.id)}
                                        >
                                          削除
                                        </button>
                                      </div>

                                      <div className="rakumart-options-block">
                                        <div className="rakumart-options-head">
                                          <span>規格</span>
                                          <button
                                            type="button"
                                            className="secondary small recipe-mini-add-button"
                                            onClick={() => addRakumartOption(item.id, source.id, line.id)}
                                          >
                                            ＋ 規格を追加
                                          </button>
                                        </div>

                                        <p className="rakumart-no-options">
                                          規格値だけでOK。Playwrightはまず規格値で探し、同じ値が複数ある場合だけ規格軸で絞り込みます。
                                        </p>

                                        {line.options.length === 0 && (
                                          <p className="rakumart-no-options">規格指定なし</p>
                                        )}

                                        {line.options.map((option) => (
                                          <div key={option.id} className="rakumart-option-row">
                                            <input
                                              value={option.value}
                                              onChange={(event) =>
                                                updateRakumartOption(item.id, source.id, line.id, option.id, {
                                                  value: event.target.value,
                                                })
                                              }
                                              placeholder="規格値 例：白色"
                                            />
                                            <span>/</span>
                                            <input
                                              value={option.group}
                                              onChange={(event) =>
                                                updateRakumartOption(item.id, source.id, line.id, option.id, {
                                                  group: event.target.value,
                                                })
                                              }
                                              placeholder="規格軸（任意）例：颜色"
                                            />
                                            <button
                                              type="button"
                                              className="secondary small danger-button rakumart-option-remove"
                                              onClick={() =>
                                                removeRakumartOption(item.id, source.id, line.id, option.id)
                                              }
                                            >
                                              ×
                                            </button>
                                          </div>
                                        ))}
                                      </div>

                                      <div className="rakumart-line-bottom">
                                        <label className="rakumart-quantity-field">
                                          <span>数量倍率</span>
                                          <input
                                            type="number"
                                            min="0.0001"
                                            step="0.0001"
                                            value={line.quantityMultiplier}
                                            onChange={(event) =>
                                              updateRakumartLine(item.id, source.id, line.id, {
                                                quantityMultiplier: event.target.value,
                                              })
                                            }
                                          />
                                          <small>発注予定数 × {line.quantityMultiplier || '?'}</small>
                                        </label>

                                        <label className="rakumart-grow-field">
                                          <span>明細メモ</span>
                                          <input
                                            value={line.memo}
                                            onChange={(event) =>
                                              updateRakumartLine(item.id, source.id, line.id, { memo: event.target.value })
                                            }
                                            placeholder="任意"
                                          />
                                        </label>
                                      </div>
                                    </div>
                                  ))}
                                </div>
                              </div>
                            </section>
                          ))}

                          <button
                            type="button"
                            className="secondary recipe-add-source-button"
                            onClick={() => addRakumartSource(item.id)}
                          >
                            ＋ 代替仕入先を追加
                          </button>
                        </div>
                      </article>
                    ))}
                  </div>
                </section>

                {rakumartRecipeMessage && (
                  <p className="modal-message rakumart-recipe-message">{rakumartRecipeMessage}</p>
                )}

                <div className="rakumart-recipe-footer">
                  <div>
                    {rakumartRecipeModal.exists && (
                      <button
                        type="button"
                        className="secondary danger-button"
                        onClick={() => void deleteRakumartRecipe()}
                        disabled={rakumartRecipeSaving}
                      >
                        レシピを削除
                      </button>
                    )}
                  </div>

                  <div className="rakumart-recipe-footer-actions">
                    <button
                      type="button"
                      className="save-button"
                      onClick={() => void saveRakumartRecipe()}
                      disabled={rakumartRecipeSaving}
                    >
                      {rakumartRecipeSaving ? '保存中...' : 'レシピを保存'}
                    </button>
                    <button
                      type="button"
                      className="secondary"
                      onClick={closeRakumartRecipe}
                      disabled={rakumartRecipeSaving}
                    >
                      閉じる
                    </button>
                  </div>
                </div>
              </div>
            )}
          </section>
        </div>
      )}

      {isCreateModalOpen && (
        <div className="modal-backdrop" onDoubleClick={closeOnBackdropDoubleClick(closeCreateModal)}>
          <section
            className="modal-card bulk-create-modal"
            role="dialog"
            aria-modal="true"
            aria-label="一括追加/更新"
            onClick={(event) => event.stopPropagation()}
          >
            <div className="bulk-modal-head">
              <h2>一括追加/更新</h2>

              <div className="bulk-mode-switch" role="radiogroup" aria-label="反映方法">
                {BULK_MODE_OPTIONS.map((option) => {
                  const active = (bulkUpdateOnly ? 'update' : bulkShouldUpdateExisting ? 'upsert' : 'insert') === option.value

                  return (
                    <button
                      key={option.value}
                      type="button"
                      role="radio"
                      aria-checked={active}
                      className={active ? 'bulk-mode-button active' : 'bulk-mode-button'}
                      onClick={() => setBulkMode(option.value)}
                      title={option.hint}
                    >
                      {option.label}
                    </button>
                  )
                })}
              </div>

              <span className="bulk-mode-hint">
                {BULK_MODE_OPTIONS.find((option) => option.value === (bulkUpdateOnly ? 'update' : bulkShouldUpdateExisting ? 'upsert' : 'insert'))?.hint}
              </span>

              <button type="button" className="secondary small bulk-modal-close" onClick={closeCreateModal}>
                閉じる
              </button>
            </div>

            <div
              className={isCsvDragOver ? 'bulk-modal-body is-csv-drag-over' : 'bulk-modal-body'}
              onDragOver={handleCsvDragOver}
              onDragLeave={handleCsvDragLeave}
              onDrop={handleCsvDrop}
            >
              <div className="bulk-modal-toolbar">
                <button
                  type="button"
                  className={isBulkFieldPanelOpen ? 'bulk-toolbar-button active' : 'bulk-toolbar-button'}
                  onClick={() => setIsBulkFieldPanelOpen((open) => !open)}
                  aria-expanded={isBulkFieldPanelOpen}
                >
                  対象列 {selectedBulkFields.length}/{BULK_FIELD_COLUMNS.length}
                  <span className="bulk-toolbar-caret">{isBulkFieldPanelOpen ? '▲' : '▼'}</span>
                </button>

                <label className="bulk-toolbar-button" title="CSVを選択、またはこの画面にドロップ">
                  CSV読み込み
                  <input
                    type="file"
                    accept=".csv,text/csv"
                    onChange={handleBulkCsvImport}
                  />
                </label>
                <span className="bulk-toolbar-note">CSVは画面にドロップでもOK</span>

                <div className="bulk-row-actions">
                  <button type="button" className="bulk-toolbar-button" onClick={() => addBulkRows(5)}>
                    ＋5行
                  </button>
                  <button type="button" className="bulk-toolbar-button is-danger" onClick={clearBulkRows}>
                    クリア
                  </button>
                </div>
              </div>

              {isBulkFieldPanelOpen && (
                <div className="bulk-field-panel">
                  <div className="bulk-field-buttons">
                    {BULK_FIELD_COLUMNS.map((column) => {
                      const selected = selectedBulkFields.includes(column.key)
                      const locked = selected && selectedBulkFields.length === 1

                      return (
                        <button
                          key={column.key}
                          type="button"
                          className={selected ? 'bulk-field-button active' : 'bulk-field-button'}
                          onClick={() => toggleBulkField(column.key)}
                          disabled={locked}
                          title={locked ? '対象列は最低1列必要です' : undefined}
                        >
                          {column.label}
                        </button>
                      )
                    })}
                  </div>
                  <small>商品コードは固定。外した列は入力欄から消え、既存データも上書きしません。</small>
                </div>
              )}

              {csvColumnMapping && (
                <div className="csv-mapping-panel">
                  <div className="csv-mapping-head">
                    <div>
                      <strong>CSV列の手動割り当て</strong>
                      <span>{csvColumnMapping.filename}</span>
                    </div>
                    <button
                      type="button"
                      className="secondary small"
                      onClick={() => setCsvColumnMapping(null)}
                    >
                      割り当てを閉じる
                    </button>
                  </div>

                  <div className="csv-mapping-help">
                    CSVの全列を表示しています。必要な列は取り込み先を選び、不要な列は「取り込まない」のままでOKです。
                  </div>

                  <div className="csv-mapping-grid csv-mapping-grid--source">
                    {csvColumnMapping.headers.map((header, index) => {
                      const assignedKey = getCsvColumnAssignment(csvColumnMapping, index)
                      const isUnassigned = !assignedKey && (header.trim() || csvColumnHasData(csvColumnMapping.dataRows, index))

                      return (
                        <label
                          key={`${header}-${index}`}
                          className={isUnassigned ? 'is-unassigned' : undefined}
                        >
                          <span>
                            {index + 1}列目：{header || '(列名なし)'}
                            {isUnassigned ? <small>未識別</small> : null}
                          </span>
                          <select
                            value={assignedKey}
                            onChange={(event) =>
                              updateCsvSourceColumnMapping(index, event.target.value)
                            }
                          >
                            <option value="">取り込まない</option>
                            <option value="product_code">商品コード</option>
                            {BULK_FIELD_COLUMNS.map((column) => (
                              <option key={column.key} value={column.key}>
                                {column.label}
                              </option>
                            ))}
                          </select>
                        </label>
                      )
                    })}
                  </div>

                  <div className="csv-mapping-actions">
                    <button type="button" className="save-button" onClick={applyManualCsvMapping}>
                      この割り当てでCSVを反映
                    </button>
                  </div>
                </div>
              )}

              <div className="bulk-table-wrap">
                <table className="bulk-input-table bulk-input-table--wide">
                  <thead>
                    <tr>
                      <th>#</th>
                      <th>画像</th>
                      <th>商品コード</th>
                      {selectedBulkColumns.map((column) => (
                        <th key={column.key}>{column.label}</th>
                      ))}
                      <th></th>
                    </tr>
                  </thead>

                  <tbody>
                    {bulkRows.map((row, index) => (
                      <tr key={row.id}>
                        <td className="bulk-row-number">{index + 1}</td>

                        <td className="bulk-image-cell">
                          <div
                            className={
                              bulkImageDrafts[row.id]
                                ? 'bulk-image-drop is-pending'
                                : 'bulk-image-drop'
                            }
                            onDragOver={handleBulkImageDragOver}
                            onDrop={(event) => handleBulkImageDrop(event, row.id)}
                            title="クリックまたはドロップで、この行の商品コード.webpとして保存する画像を選択します"
                          >
                            {bulkImageDrafts[row.id] ? (
                              <img
                                src={bulkImageDrafts[row.id].previewUrl}
                                alt={row.product_code || '追加予定画像'}
                              />
                            ) : (
                              <span>画像</span>
                            )}

                            <input
                              className="bulk-image-file-input"
                              type="file"
                              accept={PRODUCT_IMAGE_ACCEPT}
                              onChange={(event) => handleBulkImageFileSelect(event, row.id)}
                              aria-label="画像を選択"
                            />

                            {bulkImageDrafts[row.id] && (
                              <button
                                type="button"
                                className="bulk-image-remove-button"
                                onClick={(event) => {
                                  event.stopPropagation()
                                  clearBulkImageDrafts([row.id])
                                }}
                                aria-label="画像を削除"
                              >
                                ×
                              </button>
                            )}
                          </div>
                        </td>

                        <td>
                          <input
                            value={row.product_code}
                            onChange={(e) =>
                              updateBulkRow(row.id, 'product_code', e.target.value)
                            }
                            onPaste={(e) => handleBulkPaste(e, index)}
                            placeholder="商品コード"
                          />
                        </td>

                        {selectedBulkColumns.map((column) => (
                          <td
                            key={column.key}
                            className={`bulk-col-${column.key} ${column.inputType === 'checkbox' ? 'bulk-checkbox-cell' : ''}`}
                          >
                            {column.inputType === 'checkbox' ? (
                              <input
                                type="checkbox"
                                className="bulk-checkbox-input"
                                checked={Boolean(row[column.key])}
                                onChange={(e) =>
                                  updateBulkRow(row.id, column.key, e.target.checked)
                                }
                                aria-label={`${row.product_code || `行${index + 1}`} ${column.label}`}
                              />
                            ) : (
                              <input
                                value={String(row[column.key] ?? '')}
                                onChange={(e) =>
                                  updateBulkRow(row.id, column.key, e.target.value)
                                }
                                placeholder={column.placeholder}
                              />
                            )}
                          </td>
                        ))}

                        <td className="bulk-row-remove-cell">
                          <button
                            type="button"
                            className="bulk-row-remove-button"
                            onClick={() => removeBulkRow(row.id)}
                            title="この行を削除"
                            aria-label={`${index + 1}行目を削除`}
                          >
                            ×
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {isCsvDragOver && (
                <div className="bulk-csv-drop-overlay" aria-hidden="true">
                  CSVをドロップして読み込み
                </div>
              )}
            </div>

            <div className="bulk-modal-footer">
              <div className="bulk-preview">
                <span>入力 {bulkSummary.filledCount}</span>
                {!bulkUpdateOnly && <span className="is-add">追加 {bulkInsertableCount}</span>}
                {(bulkUpdateOnly || bulkShouldUpdateExisting) && (
                  <span className="is-update">更新 {bulkUpdateableCount}</span>
                )}
                {!bulkUpdateOnly && !bulkShouldUpdateExisting && bulkExistingCount > 0 && (
                  <span className="is-skip">既存スキップ {bulkExistingCount}</span>
                )}
                {bulkUpdateOnly && bulkInsertableCount > 0 && (
                  <span className="is-skip">未登録スキップ {bulkInsertableCount}</span>
                )}
                {bulkImageDraftCount > 0 && <span>画像 {bulkImageDraftCount}</span>}
                {bulkSummary.duplicateCodes.length > 0 && (
                  <span className="is-warn">重複 {bulkSummary.duplicateCodes.length}</span>
                )}
              </div>

              {modalMessage && <p className="modal-message bulk-modal-message">{modalMessage}</p>}

              <div className="bulk-footer-actions">
                <button type="button" className="secondary" onClick={closeCreateModal}>
                  キャンセル
                </button>
                <button
                  type="button"
                  className="save-button"
                  onClick={createBulkProducts}
                  disabled={loading || bulkActionableCount === 0}
                >
                  {loading
                    ? bulkUpdateOnly ? '一括更新中...' : '一括追加/更新中...'
                    : bulkUpdateOnly
                      ? `${bulkUpdateableCount}件を更新`
                      : bulkShouldUpdateExisting
                        ? `${bulkInsertableCount}件追加 / ${bulkUpdateableCount}件更新`
                        : `${bulkInsertableCount}件を追加`}
                </button>
              </div>
            </div>
          </section>
        </div>
      )}
    </main>
  )
}

export default App
